package com.a525team.weekbrowser;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class MonetActivity extends Activity {
	
	private ScrollView vscroll1;
	private LinearLayout linear14;
	private TextView name;
	private TextView textview2;
	private CheckBox checkbox1;
	private TextView textview3;
	private TextView textview5;
	private TextView textview6;
	private TextView textview9;
	private TextView textview8;
	private TextView textview10;
	private TextView textview11;
	private TextView textview12;
	private TextView textview7;
	private TextView textview14;
	private TextView textview15;
	private LinearLayout linear13;
	private LinearLayout linear1;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private LinearLayout linear11;
	private LinearLayout linear12;
	private Button add;
	private Button n110;
	private Button n210;
	private Button a110;
	private Button a210;
	private Button a310;
	private Button n150;
	private Button n250;
	private Button a150;
	private Button a250;
	private Button a350;
	private Button n1100;
	private Button n2100;
	private Button a1100;
	private Button a2100;
	private Button a3100;
	private Button n1200;
	private Button n2200;
	private Button a1200;
	private Button a2200;
	private Button a3200;
	private Button n1300;
	private Button n2300;
	private Button a1300;
	private Button a2300;
	private Button a3300;
	private Button n1400;
	private Button n2400;
	private Button a1400;
	private Button a2400;
	private Button a3400;
	private Button n1500;
	private Button n2500;
	private Button a1500;
	private Button a2500;
	private Button a3500;
	private Button n1600;
	private Button n2600;
	private Button a1600;
	private Button a2600;
	private Button a3600;
	private Button n1700;
	private Button n2700;
	private Button a1700;
	private Button a2700;
	private Button a3700;
	private Button n1800;
	private Button n2800;
	private Button a1800;
	private Button a2800;
	private Button a3800;
	private Button n1900;
	private Button n2900;
	private Button a1900;
	private Button a2900;
	private Button a3900;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.monet);
		initialize(_savedInstanceState);
		
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			||checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
			} else {
				initializeLogic();
			}
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		if(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt"))==0)
		{if ( Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {setTheme(android.R.style.Theme_Holo_Light);}else {setTheme(android.R.style.Theme_Black);}}
		
		else if(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt"))==1||Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt"))==2)
		{if ( Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {setTheme(android.R.style.Theme_Holo);}else {setTheme(android.R.style.Theme_Black);}
		} else{String filePath = "/storage/emulated/0/WeekBrowser/CustomTheme/style.txt";
				        String themeValue = FileUtil.readFile(filePath);
				
				        if (themeValue.equals("1") || (themeValue.equals("3") || themeValue.equals("5")) && Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB) {
						            setTheme(android.R.style.Theme_Black);
						        } else if (themeValue.equals("2") || (themeValue.equals("4") || themeValue.equals("6")) && Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB) {
						            setTheme(android.R.style.Theme_Light);
						        } else if (themeValue.equals("3") || (themeValue.equals("5")) && Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
						            setTheme(android.R.style.Theme_Holo);
						        } else if (themeValue.equals("4") || (themeValue.equals("6")) && Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
						            setTheme(android.R.style.Theme_Holo_Light);
						        } else if (themeValue.equals("5")) {
						            setTheme(android.R.style.Theme_Material);
						        } else if (themeValue.equals("6")) {
						            setTheme(android.R.style.Theme_Material_Light);
						        }}
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.monet);
		vscroll1 = findViewById(R.id.vscroll1);
		linear14 = findViewById(R.id.linear14);
		name = findViewById(R.id.name);
		textview2 = findViewById(R.id.textview2);
		checkbox1 = findViewById(R.id.checkbox1);
		textview3 = findViewById(R.id.textview3);
		textview5 = findViewById(R.id.textview5);
		textview6 = findViewById(R.id.textview6);
		textview9 = findViewById(R.id.textview9);
		textview8 = findViewById(R.id.textview8);
		textview10 = findViewById(R.id.textview10);
		textview11 = findViewById(R.id.textview11);
		textview12 = findViewById(R.id.textview12);
		textview7 = findViewById(R.id.textview7);
		textview14 = findViewById(R.id.textview14);
		textview15 = findViewById(R.id.textview15);
		linear13 = findViewById(R.id.linear13);
		linear1 = findViewById(R.id.linear1);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		linear7 = findViewById(R.id.linear7);
		linear8 = findViewById(R.id.linear8);
		linear9 = findViewById(R.id.linear9);
		linear10 = findViewById(R.id.linear10);
		linear11 = findViewById(R.id.linear11);
		linear12 = findViewById(R.id.linear12);
		add = findViewById(R.id.add);
		n110 = findViewById(R.id.n110);
		n210 = findViewById(R.id.n210);
		a110 = findViewById(R.id.a110);
		a210 = findViewById(R.id.a210);
		a310 = findViewById(R.id.a310);
		n150 = findViewById(R.id.n150);
		n250 = findViewById(R.id.n250);
		a150 = findViewById(R.id.a150);
		a250 = findViewById(R.id.a250);
		a350 = findViewById(R.id.a350);
		n1100 = findViewById(R.id.n1100);
		n2100 = findViewById(R.id.n2100);
		a1100 = findViewById(R.id.a1100);
		a2100 = findViewById(R.id.a2100);
		a3100 = findViewById(R.id.a3100);
		n1200 = findViewById(R.id.n1200);
		n2200 = findViewById(R.id.n2200);
		a1200 = findViewById(R.id.a1200);
		a2200 = findViewById(R.id.a2200);
		a3200 = findViewById(R.id.a3200);
		n1300 = findViewById(R.id.n1300);
		n2300 = findViewById(R.id.n2300);
		a1300 = findViewById(R.id.a1300);
		a2300 = findViewById(R.id.a2300);
		a3300 = findViewById(R.id.a3300);
		n1400 = findViewById(R.id.n1400);
		n2400 = findViewById(R.id.n2400);
		a1400 = findViewById(R.id.a1400);
		a2400 = findViewById(R.id.a2400);
		a3400 = findViewById(R.id.a3400);
		n1500 = findViewById(R.id.n1500);
		n2500 = findViewById(R.id.n2500);
		a1500 = findViewById(R.id.a1500);
		a2500 = findViewById(R.id.a2500);
		a3500 = findViewById(R.id.a3500);
		n1600 = findViewById(R.id.n1600);
		n2600 = findViewById(R.id.n2600);
		a1600 = findViewById(R.id.a1600);
		a2600 = findViewById(R.id.a2600);
		a3600 = findViewById(R.id.a3600);
		n1700 = findViewById(R.id.n1700);
		n2700 = findViewById(R.id.n2700);
		a1700 = findViewById(R.id.a1700);
		a2700 = findViewById(R.id.a2700);
		a3700 = findViewById(R.id.a3700);
		n1800 = findViewById(R.id.n1800);
		n2800 = findViewById(R.id.n2800);
		a1800 = findViewById(R.id.a1800);
		a2800 = findViewById(R.id.a2800);
		a3800 = findViewById(R.id.a3800);
		n1900 = findViewById(R.id.n1900);
		n2900 = findViewById(R.id.n2900);
		a1900 = findViewById(R.id.a1900);
		a2900 = findViewById(R.id.a2900);
		a3900 = findViewById(R.id.a3900);
		
		checkbox1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/monet/on.txt", ((checkbox1.isChecked()) ? ("1") : ("0")));
			}
		});
		
		n150.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		n250.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
	}
	
	private void initializeLogic() {
	}
	
	@Override
	public void onResume() {
		super.onResume();
		n110.setBackgroundColor(getResources().getColor(android.R.color.system_neutral1_10));
		n150.setBackgroundColor(getResources().getColor(android.R.color.system_neutral1_50));
		n1100.setBackgroundColor(getResources().getColor(android.R.color.system_neutral1_100));
		n1200.setBackgroundColor(getResources().getColor(android.R.color.system_neutral1_200));
		n1300.setBackgroundColor(getResources().getColor(android.R.color.system_neutral1_300));
		n1400.setBackgroundColor(getResources().getColor(android.R.color.system_neutral1_400));
		n1500.setBackgroundColor(getResources().getColor(android.R.color.system_neutral1_500));
		n1600.setBackgroundColor(getResources().getColor(android.R.color.system_neutral1_600));
		n1700.setBackgroundColor(getResources().getColor(android.R.color.system_neutral1_700));
		n1800.setBackgroundColor(getResources().getColor(android.R.color.system_neutral1_800));
		n1900.setBackgroundColor(getResources().getColor(android.R.color.system_neutral1_900));
		
		n210.setBackgroundColor(getResources().getColor(android.R.color.system_neutral2_10));
		n250.setBackgroundColor(getResources().getColor(android.R.color.system_neutral2_50));
		n2100.setBackgroundColor(getResources().getColor(android.R.color.system_neutral2_100));
		n2200.setBackgroundColor(getResources().getColor(android.R.color.system_neutral2_200));
		n2300.setBackgroundColor(getResources().getColor(android.R.color.system_neutral2_300));
		n2400.setBackgroundColor(getResources().getColor(android.R.color.system_neutral2_400));
		n2500.setBackgroundColor(getResources().getColor(android.R.color.system_neutral2_500));
		n2600.setBackgroundColor(getResources().getColor(android.R.color.system_neutral2_600));
		n2700.setBackgroundColor(getResources().getColor(android.R.color.system_neutral2_700));
		n2800.setBackgroundColor(getResources().getColor(android.R.color.system_neutral2_800));
		n2900.setBackgroundColor(getResources().getColor(android.R.color.system_neutral2_900));
		
		a110.setBackgroundColor(getResources().getColor(android.R.color.system_accent1_10));
		a150.setBackgroundColor(getResources().getColor(android.R.color.system_accent1_50));
		a1100.setBackgroundColor(getResources().getColor(android.R.color.system_accent1_100));
		a1200.setBackgroundColor(getResources().getColor(android.R.color.system_accent1_200));
		a1300.setBackgroundColor(getResources().getColor(android.R.color.system_accent1_300));
		a1400.setBackgroundColor(getResources().getColor(android.R.color.system_accent1_400));
		a1500.setBackgroundColor(getResources().getColor(android.R.color.system_accent1_500));
		a1600.setBackgroundColor(getResources().getColor(android.R.color.system_accent1_600));
		a1700.setBackgroundColor(getResources().getColor(android.R.color.system_accent1_700));
		a1800.setBackgroundColor(getResources().getColor(android.R.color.system_accent1_800));
		a1900.setBackgroundColor(getResources().getColor(android.R.color.system_accent1_900));
		
		a210.setBackgroundColor(getResources().getColor(android.R.color.system_accent1_10));
		a250.setBackgroundColor(getResources().getColor(android.R.color.system_accent1_50));
		a2100.setBackgroundColor(getResources().getColor(android.R.color.system_accent1_100));
		a2200.setBackgroundColor(getResources().getColor(android.R.color.system_accent1_200));
		a2300.setBackgroundColor(getResources().getColor(android.R.color.system_accent1_300));
		a2400.setBackgroundColor(getResources().getColor(android.R.color.system_accent1_400));
		a2500.setBackgroundColor(getResources().getColor(android.R.color.system_accent1_500));
		a2600.setBackgroundColor(getResources().getColor(android.R.color.system_accent1_600));
		a2700.setBackgroundColor(getResources().getColor(android.R.color.system_accent1_700));
		a2800.setBackgroundColor(getResources().getColor(android.R.color.system_accent1_800));
		a2900.setBackgroundColor(getResources().getColor(android.R.color.system_accent1_900));
		
		a210.setBackgroundColor(getResources().getColor(android.R.color.system_accent2_10));
		a250.setBackgroundColor(getResources().getColor(android.R.color.system_accent2_50));
		a2100.setBackgroundColor(getResources().getColor(android.R.color.system_accent2_100));
		a2200.setBackgroundColor(getResources().getColor(android.R.color.system_accent2_200));
		a2300.setBackgroundColor(getResources().getColor(android.R.color.system_accent2_300));
		a2400.setBackgroundColor(getResources().getColor(android.R.color.system_accent2_400));
		a2500.setBackgroundColor(getResources().getColor(android.R.color.system_accent2_500));
		a2600.setBackgroundColor(getResources().getColor(android.R.color.system_accent2_600));
		a2700.setBackgroundColor(getResources().getColor(android.R.color.system_accent2_700));
		a2800.setBackgroundColor(getResources().getColor(android.R.color.system_accent2_800));
		a2900.setBackgroundColor(getResources().getColor(android.R.color.system_accent2_900));
		
		a310.setBackgroundColor(getResources().getColor(android.R.color.system_accent3_10));
		a350.setBackgroundColor(getResources().getColor(android.R.color.system_accent3_50));
		a3100.setBackgroundColor(getResources().getColor(android.R.color.system_accent3_100));
		a3200.setBackgroundColor(getResources().getColor(android.R.color.system_accent3_200));
		a3300.setBackgroundColor(getResources().getColor(android.R.color.system_accent3_300));
		a3400.setBackgroundColor(getResources().getColor(android.R.color.system_accent3_400));
		a3500.setBackgroundColor(getResources().getColor(android.R.color.system_accent3_500));
		a3600.setBackgroundColor(getResources().getColor(android.R.color.system_accent3_600));
		a3700.setBackgroundColor(getResources().getColor(android.R.color.system_accent3_700));
		a3800.setBackgroundColor(getResources().getColor(android.R.color.system_accent3_800));
		a3900.setBackgroundColor(getResources().getColor(android.R.color.system_accent3_900));
		
		
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}