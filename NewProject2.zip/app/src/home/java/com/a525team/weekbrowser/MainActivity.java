package com.a525team.weekbrowser;

import android.Manifest;
import android.animation.*;
import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.webkit.*;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.*;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.io.IOException;
import android.webkit.URLUtil;
import android.os.Bundle;
import android.app.Activity;
import android.webkit.ValueCallback;
//import android.webkit.WebViewClient;
import android.content.pm.ActivityInfo;
import android.view.inputmethod.EditorInfo;
import java.net.URL;
import java.net.HttpURLConnection;
import java.net.URLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import android.view.inputmethod.InputMethodManager;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;

public class MainActivity extends Activity {
	
	public final int REQ_CD_FP = 101;
	
	private Timer _timer = new Timer();
	
	private String URL = "";
	private String info = "";
	private double i = 0;
	private String imageUrl = "";
	private double not = 0;
	private boolean cookie = false;
	private double minsiz = 0;
	private boolean PC = false;
	private double theme = 0;
	private double buttonId = 0;
	private boolean cache = false;
	private boolean Internet = false;
	private String content = "";
	private String filePath = "";
	private double curnum = 0;
	private double allnum = 0;
	private String searchText = "";
	private double prevY = 0;
	private boolean isSuper = false;
	private String temp = "";
	private String clip = "";
	private double notemptytab = 0;
	private String previntent = "";
	private boolean focused = false;
	private boolean selected = false;
	private String url = "";
	private double width1 = 0;
	private double height1 = 0;
	private boolean is1window = false;
	private double width2 = 0;
	private double height2 = 0;
	private double width3 = 0;
	private double height3 = 0;
	private double width4 = 0;
	private double height4 = 0;
	private double width5 = 0;
	private double height5 = 0;
	private double width6 = 0;
	private double height6 = 0;
	private double th1 = 0;
	private double th2 = 0;
	private double th3 = 0;
	private double th4 = 0;
	private double th5 = 0;
	private double th6 = 0;
	private boolean is1touch = false;
	private boolean is2touch = false;
	private boolean is3touch = false;
	private boolean is4touch = false;
	private boolean is5touch = false;
	private boolean is6touch = false;
	private double ti1 = 0;
	private double ti2 = 0;
	private double ti3 = 0;
	private double ti4 = 0;
	private double ti5 = 0;
	private double ti6 = 0;
	private boolean issu = false;
	private String tempurl = "";
	private String copy = "";
	private boolean ibml1 = false;
	private boolean ibml21 = false;
	private boolean ibml31 = false;
	private boolean ibml41 = false;
	private boolean ibml51 = false;
	private boolean ibml61 = false;
	private boolean statush = false;
	private boolean srhinit = false;
	private boolean wininit = false;
	private boolean kbd = false;
	private boolean isshowpan = false;
	private boolean ismovedpanels = false;
	private boolean isshowed = false;
	private boolean swipetorefresh = false;
	private boolean local1 = false;
	private boolean local2 = false;
	private boolean ALLOWSWIPE = false;
	private boolean isnotchfullscreen = false;
	private double buttoncolors = 0;
	private boolean isredrawbuttons = false;
	private String designbmlcache = "";
	private String fffff = "";
	private boolean adbl = false;
	private boolean adbl2 = false;
	private boolean adbl3 = false;
	private boolean adbl4 = false;
	private boolean adbl5 = false;
	private boolean adbl6 = false;
	private double adsblockedd = 0;
	
	private ArrayList<HashMap<String, Object>> history = new ArrayList<>();
	private ArrayList<String> skin = new ArrayList<>();
	private ArrayList<String> srcsug = new ArrayList<>();
	private ArrayList<String> languag = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> tab = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> sitepermis = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> windowpos = new ArrayList<>();
	
	private LinearLayout linear2;
	private LinearLayout windowsmanager;
	private TextView textview1;
	private LinearLayout tabscontainer;
	private ScrollView settingspanel;
	private HorizontalScrollView nav;
	private LinearLayout searchpan;
	private LinearLayout linear1;
	private LinearLayout tablayout;
	private LinearLayout linear9;
	private Button widthm1;
	private Button widthp1;
	private Button heightm1;
	private Button heightp1;
	private LinearLayout linwebview1;
	private LinearLayout linwebview2;
	private LinearLayout linwebview3;
	private LinearLayout linwebview4;
	private LinearLayout linwebview5;
	private LinearLayout linwebview6;
	private WebView webview1;
	private WebView webview2;
	private WebView webview3;
	private WebView webview4;
	private WebView webview5;
	private WebView webview6;
	private LinearLayout linear3;
	private LinearLayout linear12;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private CheckBox iframe;
	private CheckBox swipetore;
	private LinearLayout linear11;
	private TextView textview3;
	private SeekBar font;
	private TextView textview2;
	private SeekBar seekbar1;
	private TextView textview5;
	private SeekBar dp;
	private TextView title;
	private Button copyallurl;
	private Button multilink;
	private Button addshortcut;
	private Button share;
	private Button otherapp;
	private CheckBox supermenu;
	private CheckBox themepage;
	private CheckBox pc;
	private CheckBox js;
	private CheckBox incognito;
	private CheckBox image;
	private CheckBox blockad;
	private Button bml1;
	private Button bml2;
	private Button bml3;
	private Button bml4;
	private Button bml5;
	private LinearLayout linear5;
	private Button back;
	private Button forward;
	private Button pgup;
	private Button pgdn;
	private Button bookmarks;
	private Button home;
	private Button histori;
	private Button tabs;
	private Button dual;
	private Button skipvideo;
	private Button pagesearch;
	private Button coordinates;
	private AutoCompleteTextView search;
	private Button sup;
	private TextView num;
	private Button sdown;
	private AutoCompleteTextView autocomplete1;
	private Button hide;
	private Button refresh;
	private Button button1;
	private Button openpanel;
	private Button button3;
	private Button tab1;
	private Button tab2;
	private Button tab3;
	private Button tab4;
	private Button tab5;
	private Button tab6;
	private Button pos1;
	private Button pos2;
	private Button pos3;
	
	private TimerTask timer;
	private AlertDialog.Builder dlg;
	private Intent intent = new Intent();
	private Calendar dnt = Calendar.getInstance();
	private Intent intent2 = new Intent();
	private Intent thema = new Intent();
	private ObjectAnimator anim = new ObjectAnimator();
	private ObjectAnimator position = new ObjectAnimator();
	private ObjectAnimator tabanim = new ObjectAnimator();
	private AlertDialog.Builder dial;
	private ObjectAnimator anim2 = new ObjectAnimator();
	private Intent fp = new Intent(Intent.ACTION_GET_CONTENT);
	private ObjectAnimator srhanim = new ObjectAnimator();
	private AlertDialog.Builder shareurl;
	private Intent shareurll = new Intent();
	private AlertDialog.Builder iframecatcher;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			||checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
			} else {
				initializeLogic();
			}
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		if (_ispermission()) {
				intent.setClass(getApplicationContext(), GrantActivity.class);
				startActivity(intent);
				finish();
		}
		try{
				if(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt"))==0)
				{if ( Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {setTheme(android.R.style.Theme_Holo_Light);}else {setTheme(android.R.style.Theme_Black);}}
				
				else if(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt"))==1||Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt"))==2)
				{if ( Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {setTheme(android.R.style.Theme_Holo);}else {setTheme(android.R.style.Theme_Black);}
				} else{String filePath = "/storage/emulated/0/WeekBrowser/CustomTheme/style.txt";
						        String themeValue = FileUtil.readFile(filePath);
						
						        if (themeValue.equals("1") || (themeValue.equals("3") || themeValue.equals("5")) && Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB) {
								            setTheme(android.R.style.Theme_Black);
								        } else if (themeValue.equals("2") || (themeValue.equals("4") || themeValue.equals("6")) && Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB) {
								            setTheme(android.R.style.Theme_Light);
								        } else if (themeValue.equals("3") || (themeValue.equals("5")) && Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
								            setTheme(android.R.style.Theme_Holo);
								        } else if (themeValue.equals("4") || (themeValue.equals("6")) && Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
								            setTheme(android.R.style.Theme_Holo_Light);
								        } else if (themeValue.equals("5")) {
								            setTheme(android.R.style.Theme_Material);
								        } else if (themeValue.equals("6")) {
								            setTheme(android.R.style.Theme_Material_Light);
								        }}
				super.onCreate(_savedInstanceState);
				setContentView(R.layout.main);
		}catch(Exception e){
				 
		}
		linear2 = findViewById(R.id.linear2);
		windowsmanager = findViewById(R.id.windowsmanager);
		textview1 = findViewById(R.id.textview1);
		tabscontainer = findViewById(R.id.tabscontainer);
		settingspanel = findViewById(R.id.settingspanel);
		nav = findViewById(R.id.nav);
		searchpan = findViewById(R.id.searchpan);
		linear1 = findViewById(R.id.linear1);
		tablayout = findViewById(R.id.tablayout);
		linear9 = findViewById(R.id.linear9);
		widthm1 = findViewById(R.id.widthm1);
		widthp1 = findViewById(R.id.widthp1);
		heightm1 = findViewById(R.id.heightm1);
		heightp1 = findViewById(R.id.heightp1);
		linwebview1 = findViewById(R.id.linwebview1);
		linwebview2 = findViewById(R.id.linwebview2);
		linwebview3 = findViewById(R.id.linwebview3);
		linwebview4 = findViewById(R.id.linwebview4);
		linwebview5 = findViewById(R.id.linwebview5);
		linwebview6 = findViewById(R.id.linwebview6);
		webview1 = findViewById(R.id.webview1);
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.getSettings().setSupportZoom(true);
		webview2 = findViewById(R.id.webview2);
		webview2.getSettings().setJavaScriptEnabled(true);
		webview2.getSettings().setSupportZoom(true);
		webview3 = findViewById(R.id.webview3);
		webview3.getSettings().setJavaScriptEnabled(true);
		webview3.getSettings().setSupportZoom(true);
		webview4 = findViewById(R.id.webview4);
		webview4.getSettings().setJavaScriptEnabled(true);
		webview4.getSettings().setSupportZoom(true);
		webview5 = findViewById(R.id.webview5);
		webview5.getSettings().setJavaScriptEnabled(true);
		webview5.getSettings().setSupportZoom(true);
		webview6 = findViewById(R.id.webview6);
		webview6.getSettings().setJavaScriptEnabled(true);
		webview6.getSettings().setSupportZoom(true);
		linear3 = findViewById(R.id.linear3);
		linear12 = findViewById(R.id.linear12);
		linear6 = findViewById(R.id.linear6);
		linear7 = findViewById(R.id.linear7);
		iframe = findViewById(R.id.iframe);
		swipetore = findViewById(R.id.swipetore);
		linear11 = findViewById(R.id.linear11);
		textview3 = findViewById(R.id.textview3);
		font = findViewById(R.id.font);
		textview2 = findViewById(R.id.textview2);
		seekbar1 = findViewById(R.id.seekbar1);
		textview5 = findViewById(R.id.textview5);
		dp = findViewById(R.id.dp);
		title = findViewById(R.id.title);
		copyallurl = findViewById(R.id.copyallurl);
		multilink = findViewById(R.id.multilink);
		addshortcut = findViewById(R.id.addshortcut);
		share = findViewById(R.id.share);
		otherapp = findViewById(R.id.otherapp);
		supermenu = findViewById(R.id.supermenu);
		themepage = findViewById(R.id.themepage);
		pc = findViewById(R.id.pc);
		js = findViewById(R.id.js);
		incognito = findViewById(R.id.incognito);
		image = findViewById(R.id.image);
		blockad = findViewById(R.id.blockad);
		bml1 = findViewById(R.id.bml1);
		bml2 = findViewById(R.id.bml2);
		bml3 = findViewById(R.id.bml3);
		bml4 = findViewById(R.id.bml4);
		bml5 = findViewById(R.id.bml5);
		linear5 = findViewById(R.id.linear5);
		back = findViewById(R.id.back);
		forward = findViewById(R.id.forward);
		pgup = findViewById(R.id.pgup);
		pgdn = findViewById(R.id.pgdn);
		bookmarks = findViewById(R.id.bookmarks);
		home = findViewById(R.id.home);
		histori = findViewById(R.id.histori);
		tabs = findViewById(R.id.tabs);
		dual = findViewById(R.id.dual);
		skipvideo = findViewById(R.id.skipvideo);
		pagesearch = findViewById(R.id.pagesearch);
		coordinates = findViewById(R.id.coordinates);
		search = findViewById(R.id.search);
		sup = findViewById(R.id.sup);
		num = findViewById(R.id.num);
		sdown = findViewById(R.id.sdown);
		autocomplete1 = findViewById(R.id.autocomplete1);
		hide = findViewById(R.id.hide);
		refresh = findViewById(R.id.refresh);
		button1 = findViewById(R.id.button1);
		openpanel = findViewById(R.id.openpanel);
		button3 = findViewById(R.id.button3);
		tab1 = findViewById(R.id.tab1);
		tab2 = findViewById(R.id.tab2);
		tab3 = findViewById(R.id.tab3);
		tab4 = findViewById(R.id.tab4);
		tab5 = findViewById(R.id.tab5);
		tab6 = findViewById(R.id.tab6);
		pos1 = findViewById(R.id.pos1);
		pos2 = findViewById(R.id.pos2);
		pos3 = findViewById(R.id.pos3);
		dlg = new AlertDialog.Builder(this);
		dial = new AlertDialog.Builder(this);
		fp.setType("*/*");
		fp.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		shareurl = new AlertDialog.Builder(this);
		iframecatcher = new AlertDialog.Builder(this);
		
		widthm1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						if((int)width1>1){
							width1--;
							linwebview1.getLayoutParams().width = (int)(width1*(tabscontainer.getWidth()/4));
							linwebview1.requestLayout();}
						break;
					}
					case "1": {
						if((int)width2>1){
							width2--;
							linwebview2.getLayoutParams().width = (int)(width2*(tabscontainer.getWidth()/4));
							linwebview2.requestLayout();}
						break;
					}
					case "2": {
						if((int)width3>1){
							width3--;
							linwebview3.getLayoutParams().width = (int)(width3*(tabscontainer.getWidth()/4));
							linwebview3.requestLayout();}
						break;
					}
					case "3": {
						if((int)width4>1){width4--;
							linwebview4.getLayoutParams().width = (int)(width4*(tabscontainer.getWidth()/4));
							linwebview4.requestLayout();}
						break;
					}
					case "4": {
						if((int)width5>1){width5--;linwebview5.getLayoutParams().width = (int)(width5*(tabscontainer.getWidth()/4));
							linwebview5.requestLayout();}
						break;
					}
					case "5": {
						if((int)width6>1){width6--;linwebview6.getLayoutParams().width = (int)(width6*(tabscontainer.getWidth()/4));
							linwebview6.requestLayout();}
						break;
					}
				}
				_savewindowparam();
			}
		});
		
		widthp1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						if((int)width1<4){
							width1++;
							linwebview1.getLayoutParams().width = (int)(width1*(tabscontainer.getWidth()/4));
							linwebview1.requestLayout();}
						break;
					}
					case "1": {
						if((int)width2<4){
							width2++;
							linwebview2.getLayoutParams().width = (int)(width2*(tabscontainer.getWidth()/4));
							linwebview2.requestLayout();}
						break;
					}
					case "2": {
						if((int)width3<4){
							width3++;
							linwebview3.getLayoutParams().width = (int)(width3*(tabscontainer.getWidth()/4));
							linwebview3.requestLayout();}
						break;
					}
					case "3": {
						if((int)width4<4){
							width4++;
							linwebview4.getLayoutParams().width = (int)(width4*(tabscontainer.getWidth()/4));
							linwebview4.requestLayout();}
						break;
					}
					case "4": {
						if((int)width5<4){
							width5++;
							linwebview5.getLayoutParams().width = (int)(width5*(tabscontainer.getWidth()/4));
							linwebview5.requestLayout();}
						break;
					}
					case "5": {
						if((int)width6<4){
							width6++;
							linwebview6.getLayoutParams().width = (int)(width6*(tabscontainer.getWidth()/4));
							linwebview6.requestLayout();}
						break;
					}
				}
				_savewindowparam();
			}
		});
		
		heightm1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						if((int)height1>1){linwebview1.getLayoutParams().height = (int)(height1*(tabscontainer.getHeight()/4));
							height1--;
							linwebview1.requestLayout();}
						break;
					}
					case "1": {
						if((int)height2>1){linwebview2.getLayoutParams().height = (int)(height2*(tabscontainer.getHeight()/4));
							height2--;
							linwebview2.requestLayout();}
						break;
					}
					case "2": {
						if((int)height3>1){linwebview3.getLayoutParams().height = (int)(height3*(tabscontainer.getHeight()/4));
							height3--;
							linwebview3.requestLayout();}
						break;
					}
					case "3": {
						if((int)height4>1){linwebview4.getLayoutParams().height = (int)(height4*(tabscontainer.getHeight()/4));
							height4--;
							linwebview4.requestLayout();}
						break;
					}
					case "4": {
						if((int)height5>1){linwebview5.getLayoutParams().height = (int)(height5*(tabscontainer.getHeight()/4));
							height5--;
							linwebview5.requestLayout();}
						break;
					}
					case "5": {
						if((int)height6>1){linwebview6.getLayoutParams().height = (int)(height6*(tabscontainer.getHeight()/4));
							height6--;
							linwebview6.requestLayout();}
						break;
					}
				}
				_savewindowparam();
			}
		});
		
		heightp1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						if((int)height1<4){linwebview1.getLayoutParams().height = (int)(height1*(tabscontainer.getHeight()/4));
							height1++;
							linwebview1.requestLayout();}
						break;
					}
					case "1": {
						if((int)height2<4){linwebview2.getLayoutParams().height = (int)(height2*(tabscontainer.getHeight()/4));
							height2++;
							linwebview2.requestLayout();}
						break;
					}
					case "2": {
						if((int)height3<4){linwebview3.getLayoutParams().height = (int)(height3*(tabscontainer.getHeight()/4));
							height3++;
							linwebview3.requestLayout();}
						break;
					}
					case "3": {
						if((int)height4<4){linwebview4.getLayoutParams().height = (int)(height4*(tabscontainer.getHeight()/4));
							height4++;
							linwebview4.requestLayout();}
						break;
					}
					case "4": {
						if((int)height5<4){linwebview5.getLayoutParams().height = (int)(height5*(tabscontainer.getHeight()/4));
							height5++;
							linwebview5.requestLayout();}
						break;
					}
					case "5": {
						if((int)height6<4){linwebview6.getLayoutParams().height = (int)(height6*(tabscontainer.getHeight()/4));
							height6++;
							linwebview6.requestLayout();}
						break;
					}
				}
				_savewindowparam();
			}
		});
		
		//webviewOnProgressChanged
		webview1.setWebChromeClient(new WebChromeClient() {
				@Override public void onProgressChanged(WebView view, int _newProgress) {
					
				}
		});
		
		//OnDownloadStarted
		webview1.setDownloadListener(new DownloadListener() {
			public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
				DownloadManager.Request webview1a = new DownloadManager.Request(Uri.parse(url));
				String webview1b = CookieManager.getInstance().getCookie(url);
				webview1a.addRequestHeader("cookie", webview1b);
				webview1a.addRequestHeader("User-Agent", userAgent);
				webview1a.setDescription("Downloading file...");
				webview1a.setTitle(URLUtil.guessFileName(url, contentDisposition, mimetype));
				webview1a.allowScanningByMediaScanner(); webview1a.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED); webview1a.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimetype));
				
				DownloadManager webview1c = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
				webview1c.enqueue(webview1a);
				showMessage("Downloading File....");
				BroadcastReceiver onComplete = new BroadcastReceiver() {
					public void onReceive(Context ctxt, Intent intent) {
						showMessage("Download Complete!");
						unregisterReceiver(this);
						
					}};
				registerReceiver(onComplete, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
			}
		});
		
		webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		//webviewOnProgressChanged
		webview2.setWebChromeClient(new WebChromeClient() {
				@Override public void onProgressChanged(WebView view, int _newProgress) {
					
				}
		});
		
		//OnDownloadStarted
		webview2.setDownloadListener(new DownloadListener() {
			public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
				DownloadManager.Request webview2a = new DownloadManager.Request(Uri.parse(url));
				String webview2b = CookieManager.getInstance().getCookie(url);
				webview2a.addRequestHeader("cookie", webview2b);
				webview2a.addRequestHeader("User-Agent", userAgent);
				webview2a.setDescription("Downloading file...");
				webview2a.setTitle(URLUtil.guessFileName(url, contentDisposition, mimetype));
				webview2a.allowScanningByMediaScanner(); webview2a.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED); webview2a.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimetype));
				
				DownloadManager webview2c = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
				webview2c.enqueue(webview2a);
				showMessage("Downloading File....");
				BroadcastReceiver onComplete = new BroadcastReceiver() {
					public void onReceive(Context ctxt, Intent intent) {
						showMessage("Download Complete!");
						unregisterReceiver(this);
						
					}};
				registerReceiver(onComplete, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
			}
		});
		
		webview2.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		//webviewOnProgressChanged
		webview3.setWebChromeClient(new WebChromeClient() {
				@Override public void onProgressChanged(WebView view, int _newProgress) {
					
				}
		});
		
		//OnDownloadStarted
		webview3.setDownloadListener(new DownloadListener() {
			public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
				DownloadManager.Request webview3a = new DownloadManager.Request(Uri.parse(url));
				String webview3b = CookieManager.getInstance().getCookie(url);
				webview3a.addRequestHeader("cookie", webview3b);
				webview3a.addRequestHeader("User-Agent", userAgent);
				webview3a.setDescription("Downloading file...");
				webview3a.setTitle(URLUtil.guessFileName(url, contentDisposition, mimetype));
				webview3a.allowScanningByMediaScanner(); webview3a.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED); webview3a.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimetype));
				
				DownloadManager webview3c = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
				webview3c.enqueue(webview3a);
				showMessage("Downloading File....");
				BroadcastReceiver onComplete = new BroadcastReceiver() {
					public void onReceive(Context ctxt, Intent intent) {
						showMessage("Download Complete!");
						unregisterReceiver(this);
						
					}};
				registerReceiver(onComplete, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
			}
		});
		
		webview3.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		//webviewOnProgressChanged
		webview4.setWebChromeClient(new WebChromeClient() {
				@Override public void onProgressChanged(WebView view, int _newProgress) {
					
				}
		});
		
		//OnDownloadStarted
		webview4.setDownloadListener(new DownloadListener() {
			public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
				DownloadManager.Request webview4a = new DownloadManager.Request(Uri.parse(url));
				String webview4b = CookieManager.getInstance().getCookie(url);
				webview4a.addRequestHeader("cookie", webview4b);
				webview4a.addRequestHeader("User-Agent", userAgent);
				webview4a.setDescription("Downloading file...");
				webview4a.setTitle(URLUtil.guessFileName(url, contentDisposition, mimetype));
				webview4a.allowScanningByMediaScanner(); webview4a.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED); webview4a.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimetype));
				
				DownloadManager webview4c = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
				webview4c.enqueue(webview4a);
				showMessage("Downloading File....");
				BroadcastReceiver onComplete = new BroadcastReceiver() {
					public void onReceive(Context ctxt, Intent intent) {
						showMessage("Download Complete!");
						unregisterReceiver(this);
						
					}};
				registerReceiver(onComplete, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
			}
		});
		
		webview4.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		//webviewOnProgressChanged
		webview5.setWebChromeClient(new WebChromeClient() {
				@Override public void onProgressChanged(WebView view, int _newProgress) {
					
				}
		});
		
		//OnDownloadStarted
		webview5.setDownloadListener(new DownloadListener() {
			public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
				DownloadManager.Request webview5a = new DownloadManager.Request(Uri.parse(url));
				String webview5b = CookieManager.getInstance().getCookie(url);
				webview5a.addRequestHeader("cookie", webview5b);
				webview5a.addRequestHeader("User-Agent", userAgent);
				webview5a.setDescription("Downloading file...");
				webview5a.setTitle(URLUtil.guessFileName(url, contentDisposition, mimetype));
				webview5a.allowScanningByMediaScanner(); webview5a.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED); webview5a.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimetype));
				
				DownloadManager webview5c = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
				webview5c.enqueue(webview5a);
				showMessage("Downloading File....");
				BroadcastReceiver onComplete = new BroadcastReceiver() {
					public void onReceive(Context ctxt, Intent intent) {
						showMessage("Download Complete!");
						unregisterReceiver(this);
						
					}};
				registerReceiver(onComplete, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
			}
		});
		
		webview5.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		//webviewOnProgressChanged
		webview6.setWebChromeClient(new WebChromeClient() {
				@Override public void onProgressChanged(WebView view, int _newProgress) {
					
				}
		});
		
		//OnDownloadStarted
		webview6.setDownloadListener(new DownloadListener() {
			public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
				DownloadManager.Request webview6a = new DownloadManager.Request(Uri.parse(url));
				String webview6b = CookieManager.getInstance().getCookie(url);
				webview6a.addRequestHeader("cookie", webview6b);
				webview6a.addRequestHeader("User-Agent", userAgent);
				webview6a.setDescription("Downloading file...");
				webview6a.setTitle(URLUtil.guessFileName(url, contentDisposition, mimetype));
				webview6a.allowScanningByMediaScanner(); webview6a.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED); webview6a.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimetype));
				
				DownloadManager webview6c = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
				webview6c.enqueue(webview6a);
				showMessage("Downloading File....");
				BroadcastReceiver onComplete = new BroadcastReceiver() {
					public void onReceive(Context ctxt, Intent intent) {
						showMessage("Download Complete!");
						unregisterReceiver(this);
						
					}};
				registerReceiver(onComplete, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
			}
		});
		
		webview6.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		iframe.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				dlg.setTitle("ВИНЯТОК");
				dlg.setMessage("Що примусово робити з блокуванням \"сайтів у сайті\" на цьому сайті?");
				dlg.setPositiveButton("Вмикати", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						for (int i = 0; i < (int)(sitepermis.size()); i++) {
							if (sitepermis.get((int)i).get("url").toString().equals(_geturl())) {
								sitepermis.get((int)i).put("if", "1");
								issu = true;
								break;
							}
						}
						if (!issu) {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("url", _geturl());
								sitepermis.add(_item);
							}
							
							sitepermis.get((int)sitepermis.size() - 1).put("if", "1");
						}
						issu = false;
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SitePermission.json", new Gson().toJson(sitepermis));
						_setcolofuttons();
					}
				});
				dlg.setNegativeButton("Вимикати", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						for (int i = 0; i < (int)(sitepermis.size()); i++) {
							if (sitepermis.get((int)i).get("url").toString().equals(_geturl())) {
								sitepermis.get((int)i).put("if", "0");
								issu = true;
								break;
							}
						}
						if (!issu) {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("url", _geturl());
								sitepermis.add(_item);
							}
							
							sitepermis.get((int)sitepermis.size() - 1).put("if", "0");
						}
						issu = false;
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SitePermission.json", new Gson().toJson(sitepermis));
						_setcolofuttons();
					}
				});
				dlg.setNeutralButton("Не визначати", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						for (int i = 0; i < (int)(sitepermis.size()); i++) {
							if (sitepermis.get((int)i).get("url").toString().equals(_geturl())) {
								sitepermis.get((int)i).put("if", "2");
								issu = true;
								break;
							}
						}
						if (!issu) {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("url", _geturl());
								sitepermis.add(_item);
							}
							
							sitepermis.get((int)sitepermis.size() - 1).put("if", "2");
						}
						issu = false;
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SitePermission.json", new Gson().toJson(sitepermis));
						_setcolofuttons();
					}
				});
				dlg.create().show();
				return true;
			}
		});
		
		iframe.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/IfameBlock.txt")) == 0) {
					iframe.setChecked(true);
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/IfameBlock.txt", "1");
				}
				else {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/IfameBlock.txt", "0");
				}
			}
		});
		
		swipetore.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				dlg.setTitle("ВИНЯТОК");
				dlg.setMessage("Чи дозволити оновлення перетягуванням на цьому сайті?");
				dlg.setPositiveButton("Вмикати", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						for (int i = 0; i < (int)(sitepermis.size()); i++) {
							if (sitepermis.get((int)i).get("url").toString().equals(_geturl())) {
								sitepermis.get((int)i).put("sr", "1");
								issu = true;
								break;
							}
						}
						if (!issu) {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("url", _geturl());
								sitepermis.add(_item);
							}
							
							sitepermis.get((int)sitepermis.size() - 1).put("sr", "1");
						}
						issu = false;
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SitePermission.json", new Gson().toJson(sitepermis));
						_swipeset();
						_setcolofuttons();
					}
				});
				dlg.setNegativeButton("Вимикати", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						for (int i = 0; i < (int)(sitepermis.size()); i++) {
							if (sitepermis.get((int)i).get("url").toString().equals(_geturl())) {
								sitepermis.get((int)i).put("sr", "0");
								issu = true;
								break;
							}
						}
						if (!issu) {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("url", _geturl());
								sitepermis.add(_item);
							}
							
							sitepermis.get((int)sitepermis.size() - 1).put("sr", "0");
						}
						issu = false;
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SitePermission.json", new Gson().toJson(sitepermis));
						_swipeset();
						_setcolofuttons();
					}
				});
				dlg.setNeutralButton("Не визначати", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						for (int i = 0; i < (int)(sitepermis.size()); i++) {
							if (sitepermis.get((int)i).get("url").toString().equals(_geturl())) {
								sitepermis.get((int)i).put("sr", "2");
								issu = true;
								break;
							}
						}
						if (!issu) {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("url", _geturl());
								sitepermis.add(_item);
							}
							
							sitepermis.get((int)sitepermis.size() - 1).put("sr", "2");
						}
						issu = false;
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SitePermission.json", new Gson().toJson(sitepermis));
						_swipeset();
						_setcolofuttons();
					}
				});
				dlg.create().show();
				return true;
			}
		});
		
		swipetore.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Swipetorefresh.txt")) == 0) {
					swipetore.setChecked(true);
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Swipetorefresh.txt", "1");
				}
				else {
					swipetore.setChecked(false);
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Swipetorefresh.txt", "0");
				}
				_swipeset();
			}
		});
		
		font.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged(SeekBar _param1, int _param2, boolean _param3) {
				final int _progressValue = _param2;
				try{
					textview3.setText(languag.get((int)(7)).concat(String.valueOf((long)(_progressValue * 10)).concat("%)")));
				}catch(Exception e){
					if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
						textview3.setText("General font size (".concat(String.valueOf((long)(_progressValue * 10)).concat("%)")));
					}
					else {
						textview3.setText("Загальний розмір шрифту (".concat(String.valueOf((long)(_progressValue * 10)).concat("%)")));
					}
				}
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Sizes/fontsize.txt", String.valueOf((long)(_progressValue)));
				webview1.getSettings().setTextZoom(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/fontsize.txt"))*10);
				webview2.getSettings().setTextZoom(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/fontsize.txt"))*10);
				webview3.getSettings().setTextZoom(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/fontsize.txt"))*10);
				webview4.getSettings().setTextZoom(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/fontsize.txt"))*10);
				webview5.getSettings().setTextZoom(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/fontsize.txt"))*10);
				webview6.getSettings().setTextZoom(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/fontsize.txt"))*10);
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar _param1) {
				
			}
			
			@Override
			public void onStopTrackingTouch(SeekBar _param2) {
				
			}
		});
		
		seekbar1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged(SeekBar _param1, int _param2, boolean _param3) {
				final int _progressValue = _param2;
				try{
					textview2.setText(languag.get((int)(8)).concat(String.valueOf((long)(_progressValue)).concat(")")));
				}catch(Exception e){
					if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
						textview2.setText("Minimal font size (".concat(String.valueOf((long)(_progressValue)).concat(")")));
					}
					else {
						textview2.setText("Мінімальний розмір шрифту (".concat(String.valueOf((long)(_progressValue)).concat(")")));
					}
				}
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Sizes/minfont.txt", String.valueOf((long)(_progressValue)));
				webview1.getSettings().setMinimumFontSize(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/minfont.txt")));
				webview2.getSettings().setMinimumFontSize(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/minfont.txt")));
				webview3.getSettings().setMinimumFontSize(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/minfont.txt")));
				webview4.getSettings().setMinimumFontSize(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/minfont.txt")));
				webview5.getSettings().setMinimumFontSize(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/minfont.txt")));
				webview6.getSettings().setMinimumFontSize(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/minfont.txt")));
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar _param1) {
				
			}
			
			@Override
			public void onStopTrackingTouch(SeekBar _param2) {
				
			}
		});
		
		dp.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged(SeekBar _param1, int _param2, boolean _param3) {
				final int _progressValue = _param2;
				try{
					textview5.setText(languag.get((int)(9)).concat(String.valueOf((long)(dp.getProgress() * 10)).concat(")")));
				}catch(Exception e){
					if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
						textview5.setText("GUI size (".concat(String.valueOf((long)(dp.getProgress() * 10)).concat(")")));
					}
					else {
						textview5.setText("Розмір Інтерфейсу (".concat(String.valueOf((long)(dp.getProgress() * 10)).concat(")")));
					}
				}
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt", String.valueOf((long)(_progressValue)));
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/PC.txt")) == 1) {
					webview1.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*5);webview1.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/current.txt"));
					webview2.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*5);webview2.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/current.txt"));
					webview3.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*5);webview3.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/current.txt"));
					webview4.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*5);webview4.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/current.txt"));
					webview5.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*5);webview5.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/current.txt"));
					webview6.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*5);webview6.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/current.txt"));
				}
				else {
					webview1.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*10);webview1.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/current.txt"));
					webview2.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*10);webview2.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/current.txt"));
					webview3.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*10);webview3.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/current.txt"));
					webview4.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*10);webview4.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/current.txt"));
					webview5.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*10);webview5.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/current.txt"));
					webview6.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*10);webview6.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/current.txt"));
				}
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar _param1) {
				
			}
			
			@Override
			public void onStopTrackingTouch(SeekBar _param2) {
				
			}
		});
		
		title.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", title.getText().toString()));
			}
		});
		
		copyallurl.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (!webview1.getUrl().equals("about:blank")) {
					copy = copy.concat("\n════════\n".concat(webview1.getUrl()));
				}
				if (!webview2.getUrl().equals("about:blank")) {
					copy = copy.concat("\n════════\n".concat(webview2.getUrl()));
				}
				if (!webview3.getUrl().equals("about:blank")) {
					copy = copy.concat("\n════════\n".concat(webview3.getUrl()));
				}
				if (!webview4.getUrl().equals("about:blank")) {
					copy = copy.concat("\n════════\n".concat(webview4.getUrl()));
				}
				if (!webview5.getUrl().equals("about:blank")) {
					copy = copy.concat("\n════════\n".concat(webview5.getUrl()));
				}
				if (!webview6.getUrl().equals("about:blank")) {
					copy = copy.concat("\n════════\n".concat(webview6.getUrl()));
				}
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", copy));
				copy = "";
			}
		});
		
		multilink.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (is1window) {
					((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", "https://multilink.weekbrowser.com/".concat("%%%%%".concat(webview1.getUrl().concat("%%%%%").concat(webview2.getUrl().concat("%%%%%").concat(webview3.getUrl().concat("%%%%%").concat(webview4.getUrl().concat("%%%%%").concat(webview5.getUrl().concat("%%%%%").concat(webview6.getUrl().concat("%%%%%".concat(_getwindowpos())))))))))));
				}
				else {
					((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", "https://multilink.weekbrowser.com/".concat("%%%%%".concat(webview1.getUrl().concat("%%%%%")).concat(webview2.getUrl().concat("%%%%%").concat(webview3.getUrl().concat("%%%%%").concat(webview4.getUrl().concat("%%%%%").concat(webview5.getUrl().concat("%%%%%").concat(webview6.getUrl()))))))));
				}
			}
		});
		
		addshortcut.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), ShortcutActivity.class);
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						intent.putExtra("name", webview1.getTitle());
						intent.putExtra("url", webview1.getUrl());
						break;
					}
					case "1": {
						intent.putExtra("name", webview2.getTitle());
						intent.putExtra("url", webview2.getUrl());
						break;
					}
					case "2": {
						intent.putExtra("name", webview3.getTitle());
						intent.putExtra("url", webview3.getUrl());
						break;
					}
					case "3": {
						intent.putExtra("name", webview4.getTitle());
						intent.putExtra("url", webview4.getUrl());
						break;
					}
					case "4": {
						intent.putExtra("name", webview5.getTitle());
						intent.putExtra("url", webview5.getUrl());
						break;
					}
					case "5": {
						intent.putExtra("name", webview6.getTitle());
						intent.putExtra("url", webview6.getUrl());
						break;
					}
				}
				if (is1window) {
					intent.putExtra("m", "https://multilink.weekbrowser.com/".concat("%%%%%".concat(webview1.getUrl().concat("%%%%%").concat(webview2.getUrl().concat("%%%%%").concat(webview3.getUrl().concat("%%%%%").concat(webview4.getUrl().concat("%%%%%").concat(webview5.getUrl().concat("%%%%%").concat(webview6.getUrl().concat("%%%%%".concat(_getwindowpos()))))))))));
				}
				else {
					intent.putExtra("m", "https://multilink.weekbrowser.com/".concat("%%%%%".concat(webview1.getUrl().concat("%%%%%")).concat(webview2.getUrl().concat("%%%%%").concat(webview3.getUrl().concat("%%%%%").concat(webview4.getUrl().concat("%%%%%").concat(webview5.getUrl().concat("%%%%%").concat(webview6.getUrl())))))));
				}
				startActivity(intent);
			}
		});
		
		share.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				shareurll.setAction(Intent.ACTION_SEND);
				shareurll.setType("text/plain");
				shareurl.setTitle("ПОДІЛИТИСЯ");
				shareurl.setMessage("Чим саме Ви хочете поділитися?\n(Мультипосилання можливо відкрити лише через WeekBrowser)");
				shareurl.setPositiveButton("Звичайним посиланням", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
							case "0": {
								shareurll.putExtra(Intent.EXTRA_TEXT, webview1.getUrl());
								break;
							}
							case "1": {
								shareurll.putExtra(Intent.EXTRA_TEXT, webview2.getUrl());
								break;
							}
							case "2": {
								shareurll.putExtra(Intent.EXTRA_TEXT, webview3.getUrl());
								break;
							}
							case "3": {
								shareurll.putExtra(Intent.EXTRA_TEXT, webview4.getUrl());
								break;
							}
							case "4": {
								shareurll.putExtra(Intent.EXTRA_TEXT, webview5.getUrl());
								break;
							}
							case "5": {
								shareurll.putExtra(Intent.EXTRA_TEXT, webview6.getUrl());
								break;
							}
						}
						try{
							startActivity(shareurll);
						}catch(Exception e){
							SketchwareUtil.showMessage(getApplicationContext(), "Немає доступних програм, з якими можна поділитися посиланням");
						}
					}
				});
				shareurl.setNegativeButton("Мультипосиланням", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						if (is1window) {
							shareurll.putExtra(Intent.EXTRA_TEXT, "https://multilink.weekbrowser.com/".concat("%%%%%".concat(webview1.getUrl().concat("%%%%%").concat(webview2.getUrl().concat("%%%%%").concat(webview3.getUrl().concat("%%%%%").concat(webview4.getUrl().concat("%%%%%").concat(webview5.getUrl().concat("%%%%%").concat(webview6.getUrl().concat("%%%%%".concat(_getwindowpos()))))))))));
						}
						else {
							shareurll.putExtra(Intent.EXTRA_TEXT, "https://multilink.weekbrowser.com/".concat("%%%%%".concat(webview1.getUrl().concat("%%%%%")).concat(webview2.getUrl().concat("%%%%%").concat(webview3.getUrl().concat("%%%%%").concat(webview4.getUrl().concat("%%%%%").concat(webview5.getUrl().concat("%%%%%").concat(webview6.getUrl())))))));
						}
						try{
							startActivity(shareurll);
						}catch(Exception e){
							SketchwareUtil.showMessage(getApplicationContext(), "Немає доступних програм, з якими можна поділитися посиланням");
						}
					}
				});
				shareurl.setNeutralButton("Нічим", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				shareurl.create().show();
			}
		});
		
		otherapp.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						openInOtherApps(webview1.getUrl());
						break;
					}
					case "1": {
						openInOtherApps(webview2.getUrl());
						break;
					}
					case "2": {
						openInOtherApps(webview3.getUrl());
						break;
					}
					case "3": {
						openInOtherApps(webview4.getUrl());
						break;
					}
					case "4": {
						openInOtherApps(webview5.getUrl());
						break;
					}
					case "5": {
						openInOtherApps(webview6.getUrl());
						break;
					}
				}
				
			}
		});
		
		supermenu.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				iframecatcher.setTitle("ОБВЕСТИ САЙТИ У САЙТІ В ЧЕРВОНІ РАМКИ?");
				iframecatcher.setMessage("Це допоможе ловити код сайтів у сайті для подальшої обробки в суперменю.\n\nОБОВ'ЯЗКОВО ВИМКНІТЬ ОПЦІЮ \"ЗМІН. КОЛІР САЙТУ\" І ПЕРЕЗАВАНТАЖТЕ СТОРІНКУ, ЯКЩО СТИЛЬ САЙТУ ЗМІНЮВАВСЯ ЗАСОБАМИ БРАУЗЕРА, ІНАКШЕ РАМКИ НЕ БУДЕ!\n\nЩоб отримати сайт у сайті в суперменю, затискайте саму червону рамку, а не те, що всередині неї!");
				iframecatcher.setPositiveButton("Так", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
							case "0": {
								webview1.loadUrl("javascript:(function() {\n    var iframes = document.getElementsByTagName('iframe');\n    for (var i = 0; i < iframes.length; i++) {\n        iframes[i].style.border = '20px solid red';\n    }\n})();\n");
								break;
							}
							case "1": {
								webview2.loadUrl("javascript:(function() {\n    var iframes = document.getElementsByTagName('iframe');\n    for (var i = 0; i < iframes.length; i++) {\n        iframes[i].style.border = '20px solid red';\n    }\n})();\n");
								break;
							}
							case "2": {
								webview3.loadUrl("javascript:(function() {\n    var iframes = document.getElementsByTagName('iframe');\n    for (var i = 0; i < iframes.length; i++) {\n        iframes[i].style.border = '20px solid red';\n    }\n})();\n");
								break;
							}
							case "3": {
								webview4.loadUrl("javascript:(function() {\n    var iframes = document.getElementsByTagName('iframe');\n    for (var i = 0; i < iframes.length; i++) {\n        iframes[i].style.border = '20px solid red';\n    }\n})();\n");
								break;
							}
							case "4": {
								webview5.loadUrl("javascript:(function() {\n    var iframes = document.getElementsByTagName('iframe');\n    for (var i = 0; i < iframes.length; i++) {\n        iframes[i].style.border = '20px solid red';\n    }\n})();\n");
								break;
							}
							case "5": {
								webview6.loadUrl("javascript:(function() {\n    var iframes = document.getElementsByTagName('iframe');\n    for (var i = 0; i < iframes.length; i++) {\n        iframes[i].style.border = '20px solid red';\n    }\n})();\n");
								break;
							}
						}
					}
				});
				iframecatcher.setNegativeButton("Ні", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				iframecatcher.create().show();
				return true;
			}
		});
		
		supermenu.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Supermenu.txt")) == 0) {
					supermenu.setChecked(true);
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Supermenu.txt", "1");
				}
				else {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Supermenu.txt", "0");
				}
			}
		});
		
		themepage.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				dlg.setTitle("ВИНЯТОК");
				dlg.setMessage("Що примусово робити з оформленням на цьому сайті?");
				dlg.setPositiveButton("Змінювати", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						for (int i = 0; i < (int)(sitepermis.size()); i++) {
							if (sitepermis.get((int)i).get("url").toString().equals(_geturl())) {
								sitepermis.get((int)i).put("th", "1");
								issu = true;
								break;
							}
						}
						if (!issu) {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("url", _geturl());
								sitepermis.add(_item);
							}
							
							sitepermis.get((int)sitepermis.size() - 1).put("th", "1");
						}
						issu = false;
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SitePermission.json", new Gson().toJson(sitepermis));
						_setcolofuttons();
					}
				});
				dlg.setNegativeButton("Не змінювати", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						for (int i = 0; i < (int)(sitepermis.size()); i++) {
							if (sitepermis.get((int)i).get("url").toString().equals(_geturl())) {
								sitepermis.get((int)i).put("th", "0");
								issu = true;
								break;
							}
						}
						if (!issu) {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("url", _geturl());
								sitepermis.add(_item);
							}
							
							sitepermis.get((int)sitepermis.size() - 1).put("th", "0");
						}
						issu = false;
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SitePermission.json", new Gson().toJson(sitepermis));
						_setcolofuttons();
					}
				});
				dlg.setNeutralButton("Не визначати", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						for (int i = 0; i < (int)(sitepermis.size()); i++) {
							if (sitepermis.get((int)i).get("url").toString().equals(_geturl())) {
								sitepermis.get((int)i).put("th", "2");
								issu = true;
								break;
							}
						}
						if (!issu) {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("url", _geturl());
								sitepermis.add(_item);
							}
							
							sitepermis.get((int)sitepermis.size() - 1).put("th", "2");
						}
						issu = false;
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SitePermission.json", new Gson().toJson(sitepermis));
						_setcolofuttons();
					}
				});
				dlg.create().show();
				return true;
			}
		});
		
		themepage.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/themepage.txt")) == 0) {
					themepage.setChecked(true);
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/themepage.txt", "1");
				}
				else {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/themepage.txt", "0");
				}
			}
		});
		
		pc.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/PC.txt")) == 0) {
					pc.setChecked(true);
					webview1.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*5);webview1.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/currentpc.txt"));
					webview2.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*5);webview2.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/currentpc.txt"));
					webview3.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*5);webview3.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/currentpc.txt"));
					webview4.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*5);webview4.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/currentpc.txt"));
					webview5.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*5);webview5.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/currentpc.txt"));
					webview6.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*5);webview6.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/currentpc.txt"));
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/PC.txt", "1");
				}
				else {
					webview1.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*10);webview1.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/current.txt"));
					webview2.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*10);webview2.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/current.txt"));
					webview3.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*10);webview3.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/current.txt"));
					webview4.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*10);webview4.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/current.txt"));
					webview5.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*10);webview5.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/current.txt"));
					webview6.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*10);webview6.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/current.txt"));
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/PC.txt", "0");
				}
			}
		});
		
		js.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				dlg.setTitle("ВИНЯТОК");
				dlg.setMessage("Що примусово робити з JavaScript на цьому сайті?");
				dlg.setPositiveButton("Вмикати", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						for (int i = 0; i < (int)(sitepermis.size()); i++) {
							if (sitepermis.get((int)i).get("url").toString().equals(_geturl())) {
								sitepermis.get((int)i).put("js", "1");
								issu = true;
								break;
							}
						}
						if (!issu) {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("url", _geturl());
								sitepermis.add(_item);
							}
							
							sitepermis.get((int)sitepermis.size() - 1).put("js", "1");
						}
						issu = false;
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SitePermission.json", new Gson().toJson(sitepermis));
						_setcolofuttons();
					}
				});
				dlg.setNegativeButton("Вимикати", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						for (int i = 0; i < (int)(sitepermis.size()); i++) {
							if (sitepermis.get((int)i).get("url").toString().equals(_geturl())) {
								sitepermis.get((int)i).put("js", "0");
								issu = true;
								break;
							}
						}
						if (!issu) {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("url", _geturl());
								sitepermis.add(_item);
							}
							
							sitepermis.get((int)sitepermis.size() - 1).put("js", "0");
						}
						issu = false;
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SitePermission.json", new Gson().toJson(sitepermis));
						_setcolofuttons();
					}
				});
				dlg.setNeutralButton("Не визначати", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						for (int i = 0; i < (int)(sitepermis.size()); i++) {
							if (sitepermis.get((int)i).get("url").toString().equals(_geturl())) {
								sitepermis.get((int)i).put("js", "2");
								issu = true;
								break;
							}
						}
						if (!issu) {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("url", _geturl());
								sitepermis.add(_item);
							}
							
							sitepermis.get((int)sitepermis.size() - 1).put("js", "2");
						}
						issu = false;
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SitePermission.json", new Gson().toJson(sitepermis));
						_setcolofuttons();
					}
				});
				dlg.create().show();
				return true;
			}
		});
		
		js.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/js.txt")) == 0) {
					webview1.getSettings().setJavaScriptEnabled(true);
					webview1.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
					if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
						    webview1.getSettings().setAllowFileAccessFromFileURLs(true);
						    webview1.getSettings().setAllowUniversalAccessFromFileURLs(true);
					}
					webview2.getSettings().setJavaScriptEnabled(true);
					webview2.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
					if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
						    webview2.getSettings().setAllowFileAccessFromFileURLs(true);
						    webview2.getSettings().setAllowUniversalAccessFromFileURLs(true);
					}
					webview3.getSettings().setJavaScriptEnabled(true);
					webview3.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
					if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
						    webview3.getSettings().setAllowFileAccessFromFileURLs(true);
						    webview3.getSettings().setAllowUniversalAccessFromFileURLs(true);
					}
					webview4.getSettings().setJavaScriptEnabled(true);
					webview4.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
					if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
						    webview4.getSettings().setAllowFileAccessFromFileURLs(true);
						    webview4.getSettings().setAllowUniversalAccessFromFileURLs(true);
					}
					webview5.getSettings().setJavaScriptEnabled(true);
					webview5.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
					if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
						    webview5.getSettings().setAllowFileAccessFromFileURLs(true);
						    webview5.getSettings().setAllowUniversalAccessFromFileURLs(true);
					}
					webview6.getSettings().setJavaScriptEnabled(true);
					webview6.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
					if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
						    webview6.getSettings().setAllowFileAccessFromFileURLs(true);
						    webview6.getSettings().setAllowUniversalAccessFromFileURLs(true);
					}
					js.setChecked(true);
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/js.txt", "1");
				}
				else {
					webview1.getSettings().setJavaScriptEnabled(false);
					webview1.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
					if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
						    webview1.getSettings().setAllowFileAccessFromFileURLs(true);
						    webview1.getSettings().setAllowUniversalAccessFromFileURLs(true);
					}
					webview2.getSettings().setJavaScriptEnabled(false);
					webview2.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
					if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
						    webview2.getSettings().setAllowFileAccessFromFileURLs(true);
						    webview2.getSettings().setAllowUniversalAccessFromFileURLs(true);
					}
					webview3.getSettings().setJavaScriptEnabled(false);
					webview3.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
					if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
						    webview3.getSettings().setAllowFileAccessFromFileURLs(true);
						    webview3.getSettings().setAllowUniversalAccessFromFileURLs(true);
					}
					webview4.getSettings().setJavaScriptEnabled(false);
					webview4.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
					if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
						    webview4.getSettings().setAllowFileAccessFromFileURLs(true);
						    webview4.getSettings().setAllowUniversalAccessFromFileURLs(true);
					}
					webview5.getSettings().setJavaScriptEnabled(false);
					webview5.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
					if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
						    webview5.getSettings().setAllowFileAccessFromFileURLs(true);
						    webview5.getSettings().setAllowUniversalAccessFromFileURLs(true);
					}
					webview6.getSettings().setJavaScriptEnabled(false);
					webview6.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
					if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
						    webview6.getSettings().setAllowFileAccessFromFileURLs(true);
						    webview6.getSettings().setAllowUniversalAccessFromFileURLs(true);
					}
					js.setChecked(false);
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/js.txt", "0");
				}
				_jsset();
			}
		});
		
		incognito.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/incognito.txt")) == 1) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/incognito.txt", "0");
					getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
				}
				else {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/incognito.txt", "1");
					if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/NoScreen.txt").equals("1")) {
						getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
					}
				}
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/incognito.txt")) == 1) {
					if (android.os.Build.VERSION.SDK_INT >= 21) { CookieManager.getInstance().setAcceptThirdPartyCookies(webview1, false); } else { CookieManager.getInstance().setAcceptCookie(false); }
					incognito.setChecked(true);
					openpanel.setText("👀");
					
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 0) {
						webview1.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 1) {
							webview1.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 2) {
								webview1.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
							}
							else {
								webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
							}
						}
					}
					if (android.os.Build.VERSION.SDK_INT >= 21) { CookieManager.getInstance().setAcceptThirdPartyCookies(webview2, false); } else { CookieManager.getInstance().setAcceptCookie(false); }
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 0) {
						webview2.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 1) {
							webview2.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 2) {
								webview2.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
							}
							else {
								webview2.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
							}
						}
					}
					if (android.os.Build.VERSION.SDK_INT >= 21) { CookieManager.getInstance().setAcceptThirdPartyCookies(webview3, false); } else { CookieManager.getInstance().setAcceptCookie(false); }
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 0) {
						webview3.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 1) {
							webview3.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 2) {
								webview3.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
							}
							else {
								webview3.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
							}
						}
					}
					if (android.os.Build.VERSION.SDK_INT >= 21) { CookieManager.getInstance().setAcceptThirdPartyCookies(webview4, false); } else { CookieManager.getInstance().setAcceptCookie(false); }
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 0) {
						webview4.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 1) {
							webview4.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 2) {
								webview4.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
							}
							else {
								webview4.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
							}
						}
					}
					if (android.os.Build.VERSION.SDK_INT >= 21) { CookieManager.getInstance().setAcceptThirdPartyCookies(webview5, false); } else { CookieManager.getInstance().setAcceptCookie(false); }
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 0) {
						webview5.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 1) {
							webview5.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 2) {
								webview5.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
							}
							else {
								webview5.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
							}
						}
					}
					if (android.os.Build.VERSION.SDK_INT >= 21) { CookieManager.getInstance().setAcceptThirdPartyCookies(webview6, false); } else { CookieManager.getInstance().setAcceptCookie(false); }
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 0) {
						webview6.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 1) {
							webview6.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 2) {
								webview6.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
							}
							else {
								webview6.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
							}
						}
					}
				}
				else {
					if (android.os.Build.VERSION.SDK_INT >= 21) { CookieManager.getInstance().setAcceptThirdPartyCookies(webview1, true); } else { CookieManager.getInstance().setAcceptCookie(true); }
					openpanel.setText("");
					
					incognito.setChecked(false);
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 0) {
						webview1.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 1) {
							webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 2) {
								webview1.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
							}
							else {
								webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
							}
						}
					}
					webview1.clearHistory();
					if (android.os.Build.VERSION.SDK_INT >= 21) { CookieManager.getInstance().setAcceptThirdPartyCookies(webview2, true); } else { CookieManager.getInstance().setAcceptCookie(true); }
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 0) {
						webview2.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 1) {
							webview2.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 2) {
								webview2.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
							}
							else {
								webview2.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
							}
						}
					}
					webview2.clearHistory();
					if (android.os.Build.VERSION.SDK_INT >= 21) { CookieManager.getInstance().setAcceptThirdPartyCookies(webview3, true); } else { CookieManager.getInstance().setAcceptCookie(true); }
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 0) {
						webview3.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 1) {
							webview3.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 2) {
								webview3.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
							}
							else {
								webview3.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
							}
						}
					}
					webview3.clearHistory();
					if (android.os.Build.VERSION.SDK_INT >= 21) { CookieManager.getInstance().setAcceptThirdPartyCookies(webview4, true); } else { CookieManager.getInstance().setAcceptCookie(true); }
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 0) {
						webview4.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 1) {
							webview4.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 2) {
								webview4.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
							}
							else {
								webview4.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
							}
						}
					}
					webview4.clearHistory();
					if (android.os.Build.VERSION.SDK_INT >= 21) { CookieManager.getInstance().setAcceptThirdPartyCookies(webview5, true); } else { CookieManager.getInstance().setAcceptCookie(true); }
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 0) {
						webview5.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 1) {
							webview5.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 2) {
								webview5.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
							}
							else {
								webview5.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
							}
						}
					}
					webview5.clearHistory();
					if (android.os.Build.VERSION.SDK_INT >= 21) { CookieManager.getInstance().setAcceptThirdPartyCookies(webview6, true); } else { CookieManager.getInstance().setAcceptCookie(true); }
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 0) {
						webview6.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 1) {
							webview6.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 2) {
								webview6.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
							}
							else {
								webview6.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
							}
						}
					}
					webview6.clearHistory();
				}
			}
		});
		
		image.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/LoadImages.txt")) == 0) {
					image.setChecked(true);
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/LoadImages.txt", "1");
					webview1.getSettings().setBlockNetworkImage(false);
					webview1.getSettings().setLoadsImagesAutomatically(true);
					webview2.getSettings().setBlockNetworkImage(false);
					webview2.getSettings().setLoadsImagesAutomatically(true);
					webview3.getSettings().setBlockNetworkImage(false);
					webview3.getSettings().setLoadsImagesAutomatically(true);
					webview4.getSettings().setBlockNetworkImage(false);
					webview4.getSettings().setLoadsImagesAutomatically(true);
					webview5.getSettings().setBlockNetworkImage(false);
					webview5.getSettings().setLoadsImagesAutomatically(true);
					webview6.getSettings().setBlockNetworkImage(false);
					webview6.getSettings().setLoadsImagesAutomatically(true);
				}
				else {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/LoadImages.txt", "0");
					webview1.getSettings().setBlockNetworkImage(true);webview1.getSettings().setLoadsImagesAutomatically(false);
					webview2.getSettings().setBlockNetworkImage(true);webview1.getSettings().setLoadsImagesAutomatically(false);
					webview3.getSettings().setBlockNetworkImage(true);webview1.getSettings().setLoadsImagesAutomatically(false);
					webview4.getSettings().setBlockNetworkImage(true);webview1.getSettings().setLoadsImagesAutomatically(false);
					webview5.getSettings().setBlockNetworkImage(true);webview1.getSettings().setLoadsImagesAutomatically(false);
					webview6.getSettings().setBlockNetworkImage(true);webview1.getSettings().setLoadsImagesAutomatically(false);
				}
			}
		});
		
		blockad.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				dlg.setTitle("ВИНЯТОК");
				dlg.setMessage("Що примусово робити з блокуванням реклами на цьому сайті?\nЗа цей сеанс заблоковано ".concat(String.valueOf((long)(adsblockedd)).concat(" реклам")));
				dlg.setPositiveButton("Вмикати", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						for (int i = 0; i < (int)(sitepermis.size()); i++) {
							if (sitepermis.get((int)i).get("url").toString().equals(_geturl())) {
								sitepermis.get((int)i).put("ad", "1");
								issu = true;
								break;
							}
						}
						if (!issu) {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("url", _geturl());
								sitepermis.add(_item);
							}
							
							sitepermis.get((int)sitepermis.size() - 1).put("ad", "1");
						}
						issu = false;
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SitePermission.json", new Gson().toJson(sitepermis));
						_setcolofuttons();
					}
				});
				dlg.setNegativeButton("Вимикати", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						for (int i = 0; i < (int)(sitepermis.size()); i++) {
							if (sitepermis.get((int)i).get("url").toString().equals(_geturl())) {
								sitepermis.get((int)i).put("ad", "0");
								issu = true;
								break;
							}
						}
						if (!issu) {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("url", _geturl());
								sitepermis.add(_item);
							}
							
							sitepermis.get((int)sitepermis.size() - 1).put("ad", "0");
						}
						issu = false;
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SitePermission.json", new Gson().toJson(sitepermis));
						_setcolofuttons();
					}
				});
				dlg.setNeutralButton("Не визначати", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						for (int i = 0; i < (int)(sitepermis.size()); i++) {
							if (sitepermis.get((int)i).get("url").toString().equals(_geturl())) {
								sitepermis.get((int)i).put("ad", "2");
								issu = true;
								break;
							}
						}
						if (!issu) {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("url", _geturl());
								sitepermis.add(_item);
							}
							
							sitepermis.get((int)sitepermis.size() - 1).put("ad", "2");
						}
						issu = false;
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SitePermission.json", new Gson().toJson(sitepermis));
						_setcolofuttons();
					}
				});
				dlg.create().show();
				return true;
			}
		});
		
		blockad.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/BlockAd.txt")) == 0) {
					blockad.setChecked(true);
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/BlockAd.txt", "1");
				}
				else {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/BlockAd.txt", "0");
				}
			}
		});
		
		bml1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						webview1.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20001.txt")));
						break;
					}
					case "1": {
						webview2.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20001.txt")));
						break;
					}
					case "2": {
						webview3.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20001.txt")));
						break;
					}
					case "3": {
						webview4.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20001.txt")));
						break;
					}
					case "4": {
						webview5.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20001.txt")));
						break;
					}
					case "5": {
						webview6.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20001.txt")));
						break;
					}
				}
			}
		});
		
		bml2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						webview1.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20002.txt")));
						break;
					}
					case "1": {
						webview2.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20002.txt")));
						break;
					}
					case "2": {
						webview3.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20002.txt")));
						break;
					}
					case "3": {
						webview4.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20002.txt")));
						break;
					}
					case "4": {
						webview5.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20002.txt")));
						break;
					}
					case "5": {
						webview6.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20002.txt")));
						break;
					}
				}
			}
		});
		
		bml3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						webview1.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20003.txt")));
						break;
					}
					case "1": {
						webview2.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20003.txt")));
						break;
					}
					case "2": {
						webview3.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20003.txt")));
						break;
					}
					case "3": {
						webview4.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20003.txt")));
						break;
					}
					case "4": {
						webview5.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20003.txt")));
						break;
					}
					case "5": {
						webview6.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20003.txt")));
						break;
					}
				}
			}
		});
		
		bml4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						webview1.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20004.txt")));
						break;
					}
					case "1": {
						webview2.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20004.txt")));
						break;
					}
					case "2": {
						webview3.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20004.txt")));
						break;
					}
					case "3": {
						webview4.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20004.txt")));
						break;
					}
					case "4": {
						webview5.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20004.txt")));
						break;
					}
					case "5": {
						webview6.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20004.txt")));
						break;
					}
				}
			}
		});
		
		bml5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						webview1.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20005.txt")));
						break;
					}
					case "1": {
						webview2.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20005.txt")));
						break;
					}
					case "2": {
						webview3.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20005.txt")));
						break;
					}
					case "3": {
						webview4.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20005.txt")));
						break;
					}
					case "4": {
						webview5.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20005.txt")));
						break;
					}
					case "5": {
						webview6.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20005.txt")));
						break;
					}
				}
			}
		});
		
		back.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						webview1.goBack();
						break;
					}
					case "1": {
						webview2.goBack();
						break;
					}
					case "2": {
						webview3.goBack();
						break;
					}
					case "3": {
						webview4.goBack();
						break;
					}
					case "4": {
						webview5.goBack();
						break;
					}
					case "5": {
						webview6.goBack();
						break;
					}
				}
			}
		});
		
		forward.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				
				return true;
			}
		});
		
		forward.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						webview1.goForward();
						break;
					}
					case "1": {
						webview2.goForward();
						break;
					}
					case "2": {
						webview3.goForward();
						break;
					}
					case "3": {
						webview4.goForward();
						break;
					}
					case "4": {
						webview5.goForward();
						break;
					}
					case "5": {
						webview6.goForward();
						break;
					}
				}
			}
		});
		
		pgup.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						webview1.scrollTo(webview1.getScrollX(),0);
						break;
					}
					case "1": {
						webview2.scrollTo(webview2.getScrollX(),0);
						break;
					}
					case "2": {
						webview3.scrollTo(webview3.getScrollX(),0);
						break;
					}
					case "3": {
						webview4.scrollTo(webview4.getScrollX(),0);
						break;
					}
					case "4": {
						webview5.scrollTo(webview5.getScrollX(),0);
						break;
					}
					case "5": {
						webview6.scrollTo(webview6.getScrollX(),0);
						break;
					}
				}
			}
		});
		
		pgdn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						webview1.scrollTo(webview1.getScrollX(),2147483647);
						break;
					}
					case "1": {
						webview2.scrollTo(webview2.getScrollX(),2147483647);
						break;
					}
					case "2": {
						webview3.scrollTo(webview3.getScrollX(),2147483647);
						break;
					}
					case "3": {
						webview4.scrollTo(webview4.getScrollX(),2147483647);
						break;
					}
					case "4": {
						webview5.scrollTo(webview5.getScrollX(),2147483647);
						break;
					}
					case "5": {
						webview6.scrollTo(webview6.getScrollX(),2147483647);
						break;
					}
				}
			}
		});
		
		bookmarks.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				dial.setTitle("ВИХІД");
				dial.setMessage("Ви дійсно хочете вийти?");
				dial.setPositiveButton("Так", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						finish();
					}
				});
				dial.setNegativeButton("Ні", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dial.create().show();
				return true;
			}
		});
		
		bookmarks.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), BookmarksActivity.class);
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						intent.setData(Uri.parse(webview1.getUrl()));
						intent.putExtra("n", webview1.getTitle());
						break;
					}
					case "1": {
						intent.setData(Uri.parse(webview2.getUrl()));
						intent.putExtra("n", webview2.getTitle());
						break;
					}
					case "2": {
						intent.setData(Uri.parse(webview3.getUrl()));
						intent.putExtra("n", webview3.getTitle());
						break;
					}
					case "3": {
						intent.setData(Uri.parse(webview4.getUrl()));
						intent.putExtra("n", webview4.getTitle());
						break;
					}
					case "4": {
						intent.setData(Uri.parse(webview5.getUrl()));
						intent.putExtra("n", webview5.getTitle());
						break;
					}
					case "5": {
						intent.setData(Uri.parse(webview6.getUrl()));
						intent.putExtra("n", webview6.getTitle());
						break;
					}
				}
				if (is1window) {
					intent.putExtra("m", "https://multilink.weekbrowser.com/".concat("%%%%%".concat(webview1.getUrl().concat("%%%%%").concat(webview2.getUrl().concat("%%%%%").concat(webview3.getUrl().concat("%%%%%").concat(webview4.getUrl().concat("%%%%%").concat(webview5.getUrl().concat("%%%%%").concat(webview6.getUrl().concat("%%%%%".concat(_getwindowpos()))))))))));
				}
				else {
					intent.putExtra("m", "https://multilink.weekbrowser.com/".concat("%%%%%".concat(webview1.getUrl().concat("%%%%%")).concat(webview2.getUrl().concat("%%%%%").concat(webview3.getUrl().concat("%%%%%").concat(webview4.getUrl().concat("%%%%%").concat(webview5.getUrl().concat("%%%%%").concat(webview6.getUrl())))))));
				}
				startActivity(intent);
			}
		});
		
		home.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				webview1.loadUrl("/storage/emulated/0/WeekBrowser/bookmark.html");
				return true;
			}
		});
		
		home.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/autofirstpage.txt").equals("0")) {
							webview1.loadUrl(FileUtil.readFile("/storage/emulated/0/WeekBrowser/firstpage.txt"));
						}
						else {
							webview1.loadUrl("file:///storage/emulated/0/WeekBrowser/bookmark.html");
						}
						break;
					}
					case "1": {
						if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/autofirstpage.txt").equals("0")) {
							webview2.loadUrl(FileUtil.readFile("/storage/emulated/0/WeekBrowser/firstpage.txt"));
						}
						else {
							webview2.loadUrl("file:///storage/emulated/0/WeekBrowser/bookmark.html");
						}
						break;
					}
					case "2": {
						if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/autofirstpage.txt").equals("0")) {
							webview3.loadUrl(FileUtil.readFile("/storage/emulated/0/WeekBrowser/firstpage.txt"));
						}
						else {
							webview3.loadUrl("file:///storage/emulated/0/WeekBrowser/bookmark.html");
						}
						break;
					}
					case "3": {
						if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/autofirstpage.txt").equals("0")) {
							webview4.loadUrl(FileUtil.readFile("/storage/emulated/0/WeekBrowser/firstpage.txt"));
						}
						else {
							webview4.loadUrl("file:///storage/emulated/0/WeekBrowser/bookmark.html");
						}
						break;
					}
					case "4": {
						if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/autofirstpage.txt").equals("0")) {
							webview5.loadUrl(FileUtil.readFile("/storage/emulated/0/WeekBrowser/firstpage.txt"));
						}
						else {
							webview5.loadUrl("file:///storage/emulated/0/WeekBrowser/bookmark.html");
						}
						break;
					}
					case "5": {
						if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/autofirstpage.txt").equals("0")) {
							webview6.loadUrl(FileUtil.readFile("/storage/emulated/0/WeekBrowser/firstpage.txt"));
						}
						else {
							webview6.loadUrl("file:///storage/emulated/0/WeekBrowser/bookmark.html");
						}
						break;
					}
				}
			}
		});
		
		histori.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), HistoryActivity.class);
				startActivity(intent);
			}
		});
		
		tabs.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (tablayout.getVisibility() == View.VISIBLE) {
					tablayout.setVisibility(View.GONE);
				}
				else {
					tablayout.setVisibility(View.VISIBLE);
					tabanim.setTarget(tablayout);
					tabanim.setPropertyName("alpha");
					tabanim.setFloatValues((float)(0), (float)(1));
					tabanim.setDuration((int)(500));
					tabanim.start();
				}
			}
		});
		
		dual.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						linwebview1.setVisibility(View.GONE);
						break;
					}
					case "1": {
						linwebview2.setVisibility(View.GONE);
						break;
					}
					case "2": {
						linwebview3.setVisibility(View.GONE);
						break;
					}
					case "3": {
						linwebview4.setVisibility(View.GONE);
						break;
					}
					case "4": {
						linwebview5.setVisibility(View.GONE);
						break;
					}
					case "5": {
						linwebview6.setVisibility(View.GONE);
						break;
					}
				}
				return true;
			}
		});
		
		dual.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (!wininit) {
					linwebview1.setOnTouchListener(new OnTouchListener() {
						    PointF DownPT = new PointF();
						    PointF StartPT = new PointF();
						
						    @Override
						    public boolean onTouch(View v, MotionEvent event) {
							        int eid = event.getAction();
							        switch (eid) {
								            case MotionEvent.ACTION_MOVE:
								                PointF mv = new PointF(event.getX() - DownPT.x, event.getY() - DownPT.y);
								                linwebview1.setX((int) (StartPT.x + mv.x));
								                linwebview1.setY((int) (StartPT.y + mv.y));
								                StartPT = new PointF(linwebview1.getX(), linwebview1.getY());
								                break;
								            case MotionEvent.ACTION_DOWN:
								                DownPT.x = event.getX();
								                DownPT.y = event.getY();
								                StartPT = new PointF(linwebview1.getX(), linwebview1.getY());
								                is1touch = true;// При дотику встановлюємо is1touch в true
								                break;
								            case MotionEvent.ACTION_UP:
								                is1touch = false; tab1.performClick();_savewindowparam();// При відпусканні встановлюємо is1touch в false
								                break;
								            default:
								                break;
								        }
							        return true;
							    }
					});
					
					// Повторіть блок коду для кожного linwebviewN від 2 до 6, замінюючи номери
					// Наприклад, код для linwebview2:
					
					linwebview2.setOnTouchListener(new OnTouchListener() {
						    PointF DownPT = new PointF();
						    PointF StartPT = new PointF();
						
						    @Override
						    public boolean onTouch(View v, MotionEvent event) {
							        int eid = event.getAction();
							        switch (eid) {
								            case MotionEvent.ACTION_MOVE:
								                PointF mv = new PointF(event.getX() - DownPT.x, event.getY() - DownPT.y);
								                linwebview2.setX((int) (StartPT.x + mv.x));
								                linwebview2.setY((int) (StartPT.y + mv.y));
								                StartPT = new PointF(linwebview2.getX(), linwebview2.getY());
								                break;
								            case MotionEvent.ACTION_DOWN:
								                DownPT.x = event.getX();
								                DownPT.y = event.getY();
								                StartPT = new PointF(linwebview2.getX(), linwebview2.getY());
								                is2touch = true;// При дотику встановлюємо is2touch в true
								                break;
								            case MotionEvent.ACTION_UP:
								                is2touch = false;tab2.performClick();_savewindowparam(); // При відпусканні встановлюємо is2touch в false
								                break;
								            default:
								                break;
								        }
							        return true;
							    }
					});
					
					// Повторіть цей код для кожного linwebviewN від 3 до 6, замінюючи номери
					// linwebview3, linwebview4, linwebview5, linwebview6
					// Запишіть блок коду для кожного linwebviewN
					linwebview3.setOnTouchListener(new OnTouchListener() {
						    PointF DownPT = new PointF();
						    PointF StartPT = new PointF();
						
						    @Override
						    public boolean onTouch(View v, MotionEvent event) {
							        int eid = event.getAction();
							        switch (eid) {
								            case MotionEvent.ACTION_MOVE:
								                PointF mv = new PointF(event.getX() - DownPT.x, event.getY() - DownPT.y);
								                linwebview3.setX((int) (StartPT.x + mv.x));
								                linwebview3.setY((int) (StartPT.y + mv.y));
								                StartPT = new PointF(linwebview3.getX(), linwebview3.getY());
								                break;
								            case MotionEvent.ACTION_DOWN:
								                DownPT.x = event.getX();
								                DownPT.y = event.getY();
								                StartPT = new PointF(linwebview3.getX(), linwebview3.getY());
								                is3touch = true;// При дотику встановлюємо is3touch в true
								                break;
								            case MotionEvent.ACTION_UP:
								                is3touch = false;tab3.performClick();_savewindowparam(); // При відпусканні встановлюємо is3touch в false
								                break;
								            default:
								                break;
								        }
							        return true;
							    }
					});
					
					linwebview4.setOnTouchListener(new OnTouchListener() {
						    PointF DownPT = new PointF();
						    PointF StartPT = new PointF();
						
						    @Override
						    public boolean onTouch(View v, MotionEvent event) {
							        int eid = event.getAction();
							        switch (eid) {
								            case MotionEvent.ACTION_MOVE:
								                PointF mv = new PointF(event.getX() - DownPT.x, event.getY() - DownPT.y);
								                linwebview4.setX((int) (StartPT.x + mv.x));
								                linwebview4.setY((int) (StartPT.y + mv.y));
								                StartPT = new PointF(linwebview4.getX(), linwebview4.getY());
								                break;
								            case MotionEvent.ACTION_DOWN:
								                DownPT.x = event.getX();
								                DownPT.y = event.getY();
								                StartPT = new PointF(linwebview4.getX(), linwebview4.getY());
								                is4touch = true;// При дотику встановлюємо is4touch в true
								                break;
								            case MotionEvent.ACTION_UP:
								                is4touch = false;tab4.performClick(); _savewindowparam();// При відпусканні встановлюємо is4touch в false
								                break;
								            default:
								                break;
								        }
							        return true;
							    }
					});
					
					
					linwebview5.setOnTouchListener(new OnTouchListener() {
						    PointF DownPT = new PointF();
						    PointF StartPT = new PointF();
						
						    @Override
						    public boolean onTouch(View v, MotionEvent event) {
							        int eid = event.getAction();
							        switch (eid) {
								            case MotionEvent.ACTION_MOVE:
								                PointF mv = new PointF(event.getX() - DownPT.x, event.getY() - DownPT.y);
								                linwebview5.setX((int) (StartPT.x + mv.x));
								                linwebview5.setY((int) (StartPT.y + mv.y));
								                StartPT = new PointF(linwebview5.getX(), linwebview5.getY());
								                break;
								            case MotionEvent.ACTION_DOWN:
								                DownPT.x = event.getX();
								                DownPT.y = event.getY();
								                StartPT = new PointF(linwebview5.getX(), linwebview5.getY());
								                is5touch = true; // При дотику встановлюємо is5touch в true
								                break;
								            case MotionEvent.ACTION_UP:
								                is5touch = false; tab5.performClick();_savewindowparam();// При відпусканні встановлюємо is5touch в false
								                break;
								            default:
								                break;
								        }
							        return true;
							    }
					});
					
					linwebview6.setOnTouchListener(new OnTouchListener() {
						    PointF DownPT = new PointF();
						    PointF StartPT = new PointF();
						
						    @Override
						    public boolean onTouch(View v, MotionEvent event) {
							        int eid = event.getAction();
							        switch (eid) {
								            case MotionEvent.ACTION_MOVE:
								                PointF mv = new PointF(event.getX() - DownPT.x, event.getY() - DownPT.y);
								                linwebview6.setX((int) (StartPT.x + mv.x));
								                linwebview6.setY((int) (StartPT.y + mv.y));
								                StartPT = new PointF(linwebview6.getX(), linwebview6.getY());
								                break;
								            case MotionEvent.ACTION_DOWN:
								                DownPT.x = event.getX();
								                DownPT.y = event.getY();
								                StartPT = new PointF(linwebview6.getX(), linwebview6.getY());
								                is6touch = true;// При дотику встановлюємо is6touch в true
								                break;
								            case MotionEvent.ACTION_UP:
								                is6touch = false;tab6.performClick();_savewindowparam(); // При відпусканні встановлюємо is6touch в false
								                break;
								            default:
								                break;
								        }
							        return true;
							    }
					});
					
					wininit = true;
				}
				if (is1window) {
					_savewindowparam();
					windowpos = new Gson().fromJson(FileUtil.readFile("/storage/emulated/0/WeekBrowser/windows.json"), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					windowpos.get((int)6).put("w", "0");
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/windows.json", new Gson().toJson(windowpos));
					is1window = false;
					_setTopPadding(linwebview1, 0);
					linwebview1.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
					linwebview1.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
					((LinearLayout.LayoutParams) linwebview1.getLayoutParams()).weight = 1; // або будь-яке інше значення, яке вам потрібно
					linwebview1.requestLayout();
					linwebview1.setX(0);
					linwebview1.setY(0);
					_setTopPadding(linwebview2, 0);
					linwebview2.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
					linwebview2.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
					((LinearLayout.LayoutParams) linwebview2.getLayoutParams()).weight = 1; // або будь-яке інше значення, яке вам потрібно
					linwebview2.requestLayout();
					linwebview2.setX(0);
					linwebview2.setY(0);
					_setTopPadding(linwebview3, 0);
					linwebview3.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
					linwebview3.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
					((LinearLayout.LayoutParams) linwebview3.getLayoutParams()).weight = 1; // або будь-яке інше значення, яке вам потрібно
					linwebview3.requestLayout();
					linwebview3.setX(0);
					linwebview3.setY(0);
					_setTopPadding(linwebview4, 0);
					linwebview4.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
					linwebview4.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
					((LinearLayout.LayoutParams) linwebview4.getLayoutParams()).weight = 1; // або будь-яке інше значення, яке вам потрібно
					linwebview4.requestLayout();
					linwebview4.setX(0);
					linwebview4.setY(0);
					_setTopPadding(linwebview5, 0);
					linwebview5.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
					linwebview5.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
					((LinearLayout.LayoutParams) linwebview5.getLayoutParams()).weight = 1; // або будь-яке інше значення, яке вам потрібно
					linwebview5.requestLayout();
					linwebview5.setX(0);
					linwebview5.setY(0);
					_setTopPadding(linwebview6, 0);
					linwebview6.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
					linwebview6.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
					((LinearLayout.LayoutParams) linwebview6.getLayoutParams()).weight = 1; // або будь-яке інше значення, яке вам потрібно
					linwebview6.requestLayout();
					linwebview6.setX(0);
					linwebview6.setY(0);
					windowsmanager.setVisibility(View.GONE);
					_Reopentab();
				}
				else {
					is1window = true;
					windowpos = new Gson().fromJson(FileUtil.readFile("/storage/emulated/0/WeekBrowser/windows.json"), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					windowpos.get((int)6).put("w", "1");
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/windows.json", new Gson().toJson(windowpos));
					_restorewindowparam();
					_Reopentab();
				}
			}
		});
		
		skipvideo.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						webview1.loadUrl("javascript:(function() {\n    var videos = document.querySelectorAll('video, [src*=\".mp4\"], [src*=\".webm\"], [src*=\".ogv\"], [type*=\"video\"]');\n    for (var i = 0; i < videos.length; i++) {\n        var video = videos[i];\n        if (typeof video.currentTime !== 'undefined') {\n            video.currentTime = 65535;\n        }\n    }\n})();");
						break;
					}
					case "1": {
						webview2.loadUrl("javascript:(function() {\n    var videos = document.querySelectorAll('video, [src*=\".mp4\"], [src*=\".webm\"], [src*=\".ogv\"], [type*=\"video\"]');\n    for (var i = 0; i < videos.length; i++) {\n        var video = videos[i];\n        if (typeof video.currentTime !== 'undefined') {\n            video.currentTime = 65535;\n        }\n    }\n})();");
						break;
					}
					case "2": {
						webview3.loadUrl("javascript:(function() {\n    var videos = document.querySelectorAll('video, [src*=\".mp4\"], [src*=\".webm\"], [src*=\".ogv\"], [type*=\"video\"]');\n    for (var i = 0; i < videos.length; i++) {\n        var video = videos[i];\n        if (typeof video.currentTime !== 'undefined') {\n            video.currentTime = 65535;\n        }\n    }\n})();");
						break;
					}
					case "3": {
						webview4.loadUrl("javascript:(function() {\n    var videos = document.querySelectorAll('video, [src*=\".mp4\"], [src*=\".webm\"], [src*=\".ogv\"], [type*=\"video\"]');\n    for (var i = 0; i < videos.length; i++) {\n        var video = videos[i];\n        if (typeof video.currentTime !== 'undefined') {\n            video.currentTime = 65535;\n        }\n    }\n})();");
						break;
					}
					case "4": {
						webview5.loadUrl("javascript:(function() {\n    var videos = document.querySelectorAll('video, [src*=\".mp4\"], [src*=\".webm\"], [src*=\".ogv\"], [type*=\"video\"]');\n    for (var i = 0; i < videos.length; i++) {\n        var video = videos[i];\n        if (typeof video.currentTime !== 'undefined') {\n            video.currentTime = 65535;\n        }\n    }\n})();");
						break;
					}
					case "5": {
						webview6.loadUrl("javascript:(function() {\n    var videos = document.querySelectorAll('video, [src*=\".mp4\"], [src*=\".webm\"], [src*=\".ogv\"], [type*=\"video\"]');\n    for (var i = 0; i < videos.length; i++) {\n        var video = videos[i];\n        if (typeof video.currentTime !== 'undefined') {\n            video.currentTime = 65535;\n        }\n    }\n})();");
						break;
					}
				}
			}
		});
		
		pagesearch.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (!srhinit) {
					webview1.setFindListener(new WebView.FindListener() {
						    @Override
						    public void onFindResultReceived(int activeMatchOrdinal, int numberOfMatches, boolean isDoneCounting) {
							            allnum=numberOfMatches;
							        }
					});
					webview2.setFindListener(new WebView.FindListener() {
						    @Override
						    public void onFindResultReceived(int activeMatchOrdinal, int numberOfMatches, boolean isDoneCounting) {
							            allnum=numberOfMatches;
							        }
					});
					webview3.setFindListener(new WebView.FindListener() {
						    @Override
						    public void onFindResultReceived(int activeMatchOrdinal, int numberOfMatches, boolean isDoneCounting) {
							            allnum=numberOfMatches;
							        }
					});
					webview4.setFindListener(new WebView.FindListener() {
						    @Override
						    public void onFindResultReceived(int activeMatchOrdinal, int numberOfMatches, boolean isDoneCounting) {
							            allnum=numberOfMatches;
							        }
					});
					webview5.setFindListener(new WebView.FindListener() {
						    @Override
						    public void onFindResultReceived(int activeMatchOrdinal, int numberOfMatches, boolean isDoneCounting) {
							            allnum=numberOfMatches;
							        }
					});
					webview6.setFindListener(new WebView.FindListener() {
						    @Override
						    public void onFindResultReceived(int activeMatchOrdinal, int numberOfMatches, boolean isDoneCounting) {
							            allnum=numberOfMatches;
							        }
					});
					
					srhinit = true;
				}
				if (searchpan.getVisibility() == View.GONE) {
					searchpan.setVisibility(View.VISIBLE);
					srhanim.setTarget(searchpan);
					srhanim.setPropertyName("alpha");
					srhanim.setFloatValues((float)(0), (float)(1));
					srhanim.setDuration((int)(500));
					srhanim.start();
					switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
						case "0": {
							webview1.findAll(search.getText().toString());
							break;
						}
						case "1": {
							webview2.findAll(search.getText().toString());
							break;
						}
						case "2": {
							webview3.findAll(search.getText().toString());
							break;
						}
						case "3": {
							webview4.findAll(search.getText().toString());
							break;
						}
						case "4": {
							webview5.findAll(search.getText().toString());
							break;
						}
						case "5": {
							webview6.findAll(search.getText().toString());
							break;
						}
					}
				}
				else {
					searchpan.setVisibility(View.GONE);
					switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
						case "0": {
							webview1.findAll("");
							break;
						}
						case "1": {
							webview2.findAll("");
							break;
						}
						case "2": {
							webview3.findAll("");
							break;
						}
						case "3": {
							webview4.findAll("");
							break;
						}
						case "4": {
							webview5.findAll("");
							break;
						}
						case "5": {
							webview6.findAll("");
							break;
						}
					}
				}
			}
		});
		
		coordinates.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (linear9.getVisibility() == View.VISIBLE) {
					linear9.setVisibility(View.GONE);
				}
				else {
					linear9.setVisibility(View.VISIBLE);
					position.setTarget(linear9);
					position.setPropertyName("alpha");
					position.setFloatValues((float)(0), (float)(1));
					position.setDuration((int)(500));
					position.start();
				}
			}
		});
		
		search.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						webview1.findAll(_charSeq);
						break;
					}
					case "1": {
						webview2.findAll(_charSeq);
						break;
					}
					case "2": {
						webview3.findAll(_charSeq);
						break;
					}
					case "3": {
						webview4.findAll(_charSeq);
						break;
					}
					case "4": {
						webview5.findAll(_charSeq);
						break;
					}
					case "5": {
						webview6.findAll(_charSeq);
						break;
					}
				}
				curnum = 1;
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		//OnTouch
		sup.setOnTouchListener(new View.OnTouchListener(){
				@Override
				public boolean onTouch(View v, MotionEvent event){
						int ev = event.getAction();
						switch (ev) {
								case MotionEvent.ACTION_DOWN:
								
								 if (curnum > 1) {
						    curnum--;
					} else {
						    // Якщо к-ть переповнюється, переходимо до кінця
						    curnum = allnum;
					}
					num.setText(String.valueOf((int) curnum) + "/" + String.valueOf((int) allnum));
					
					switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
						case "0": {
							webview1.findNext(false);
							break;
						}
						case "1": {
							webview2.findNext(false);
							break;
						}
						case "2": {
							webview3.findNext(false);
							break;
						}
						case "3": {
							webview4.findNext(false);
							break;
						}
						case "4": {
							webview5.findNext(false);
							break;
						}
						case "5": {
							webview6.findNext(false);
							break;
						}
					}
								
								break;
								case MotionEvent.ACTION_UP:
								
								 
								
								break;
						} return true;
				}
		});
		
		//OnTouch
		sdown.setOnTouchListener(new View.OnTouchListener(){
				@Override
				public boolean onTouch(View v, MotionEvent event){
						int ev = event.getAction();
						switch (ev) {
								case MotionEvent.ACTION_DOWN:
								
								 if (curnum < allnum) {
						    curnum++;
					} else {
						    // Якщо к-ть переповнюється, повертаємося до початку
						    curnum = 1;
					}
					num.setText(String.valueOf((long)(curnum)).concat("/".concat(String.valueOf((long)(allnum)))));
					switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
						case "0": {
							webview1.findNext(true);
							break;
						}
						case "1": {
							webview2.findNext(true);
							break;
						}
						case "2": {
							webview3.findNext(true);
							break;
						}
						case "3": {
							webview4.findNext(true);
							break;
						}
						case "4": {
							webview5.findNext(true);
							break;
						}
						case "5": {
							webview6.findNext(true);
							break;
						}
					}
								
								break;
								case MotionEvent.ACTION_UP:
								
								 
								
								break;
						} return true;
				}
		});
		
		autocomplete1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				autocomplete1.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_list_item_1, srcsug));
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		//OnTouch
		hide.setOnTouchListener(new View.OnTouchListener(){
				@Override
				public boolean onTouch(View v, MotionEvent event){
						int ev = event.getAction();
						switch (ev) {
								case MotionEvent.ACTION_DOWN:
								
								 linear1.setVisibility(View.GONE);
					linear5.setVisibility(View.GONE);
					getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_FULLSCREEN
					        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
					        | View.SYSTEM_UI_FLAG_IMMERSIVE);
					isnotchfullscreen = true;
								
								break;
								case MotionEvent.ACTION_UP:
								
								 
								
								break;
						} return true;
				}
		});
		
		refresh.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						if (webview1.getProgress() == 100) {
							webview1.loadUrl(webview1.getUrl());
						}
						else {
							webview1.stopLoading();
						}
						break;
					}
					case "1": {
						if (webview2.getProgress() == 100) {
							webview2.loadUrl(webview2.getUrl());
						}
						else {
							webview2.stopLoading();
						}
						break;
					}
					case "2": {
						if (webview3.getProgress() == 100) {
							webview3.loadUrl(webview3.getUrl());
						}
						else {
							webview3.stopLoading();
						}
						break;
					}
					case "3": {
						if (webview4.getProgress() == 100) {
							webview4.loadUrl(webview4.getUrl());
						}
						else {
							webview4.stopLoading();
						}
						break;
					}
					case "4": {
						if (webview5.getProgress() == 100) {
							webview5.loadUrl(webview5.getUrl());
						}
						else {
							webview5.stopLoading();
						}
						break;
					}
					case "5": {
						if (webview6.getProgress() == 100) {
							webview6.loadUrl(webview6.getUrl());
						}
						else {
							webview6.stopLoading();
						}
						break;
					}
				}
			}
		});
		
		button1.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				autocomplete1.setText(autocomplete1.getText().toString().replaceAll(FileUtil.readFile("/storage/emulated/0/WeekBrowser/replaces/10.txt"), FileUtil.readFile("/storage/emulated/0/WeekBrowser/replaces/11.txt")));
				autocomplete1.setText(autocomplete1.getText().toString().replaceAll(FileUtil.readFile("/storage/emulated/0/WeekBrowser/replaces/20.txt"), FileUtil.readFile("/storage/emulated/0/WeekBrowser/replaces/21.txt")));
				autocomplete1.setText(autocomplete1.getText().toString().replaceAll(FileUtil.readFile("/storage/emulated/0/WeekBrowser/replaces/30.txt"), FileUtil.readFile("/storage/emulated/0/WeekBrowser/replaces/31.txt")));
				autocomplete1.setText(autocomplete1.getText().toString().replaceAll(FileUtil.readFile("/storage/emulated/0/WeekBrowser/replaces/40.txt"), FileUtil.readFile("/storage/emulated/0/WeekBrowser/replaces/41.txt")));
				autocomplete1.setText(autocomplete1.getText().toString().replaceAll(FileUtil.readFile("/storage/emulated/0/WeekBrowser/replaces/50.txt"), FileUtil.readFile("/storage/emulated/0/WeekBrowser/replaces/51.txt")));
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						webview1.loadUrl(autocomplete1.getText().toString());
						break;
					}
					case "1": {
						webview2.loadUrl(autocomplete1.getText().toString());
						break;
					}
					case "2": {
						webview3.loadUrl(autocomplete1.getText().toString());
						break;
					}
					case "3": {
						webview4.loadUrl(autocomplete1.getText().toString());
						break;
					}
					case "4": {
						webview5.loadUrl(autocomplete1.getText().toString());
						break;
					}
					case "5": {
						webview6.loadUrl(autocomplete1.getText().toString());
						break;
					}
				}
				return true;
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.hideKeyboard(getApplicationContext());
				URL = autocomplete1.getText().toString();
				if (URLUtil.isValidUrl(autocomplete1.getText().toString())) {
					switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
						case "0": {
							webview1.loadUrl(URL);
							break;
						}
						case "1": {
							webview2.loadUrl(URL);
							break;
						}
						case "2": {
							webview3.loadUrl(URL);
							break;
						}
						case "3": {
							webview4.loadUrl(URL);
							break;
						}
						case "4": {
							webview5.loadUrl(URL);
							break;
						}
						case "5": {
							webview6.loadUrl(URL);
							break;
						}
					}
				}
				else {
					if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/SearchEngine.txt").equals("0") && FileUtil.readFile("/storage/emulated/0/WeekBrowser/incognito.txt").equals("0")) {
						URL = "https://www.google.com/search?q=".concat(autocomplete1.getText().toString());
					}
					if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/SearchEngine.txt").equals("1") && FileUtil.readFile("/storage/emulated/0/WeekBrowser/incognito.txt").equals("0")) {
						URL = "https://www.bing.com/search?q=".concat(autocomplete1.getText().toString());
					}
					if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/SearchEngine.txt").equals("2") && FileUtil.readFile("/storage/emulated/0/WeekBrowser/incognito.txt").equals("0")) {
						URL = "https://search.yahoo.com/search?p=".concat(autocomplete1.getText().toString());
					}
					if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/SearchEngine.txt").equals("3") || FileUtil.readFile("/storage/emulated/0/WeekBrowser/incognito.txt").equals("1")) {
						URL = "https://duckduckgo.com/?t=h_&q=".concat(autocomplete1.getText().toString());
					}
					if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/incognito.txt").equals("0")) {
						srcsug = new Gson().fromJson(FileUtil.readFile("/storage/emulated/0/WeekBrowser/search.txt"), new TypeToken<ArrayList<String>>(){}.getType());
						srcsug.add(autocomplete1.getText().toString().trim());
						Set<String> uniqueValues = new HashSet<>(srcsug);
						        srcsug.clear();
						        srcsug.addAll(uniqueValues);
						
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/search.txt", new Gson().toJson(srcsug));
					}
					switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
						case "0": {
							webview1.loadUrl(URL);
							break;
						}
						case "1": {
							webview2.loadUrl(URL);
							break;
						}
						case "2": {
							webview3.loadUrl(URL);
							break;
						}
						case "3": {
							webview4.loadUrl(URL);
							break;
						}
						case "4": {
							webview5.loadUrl(URL);
							break;
						}
						case "5": {
							webview6.loadUrl(URL);
							break;
						}
					}
				}
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						autocomplete1.setText(webview1.getUrl());
						break;
					}
					case "1": {
						autocomplete1.setText(webview2.getUrl());
						break;
					}
					case "2": {
						autocomplete1.setText(webview3.getUrl());
						break;
					}
					case "3": {
						autocomplete1.setText(webview4.getUrl());
						break;
					}
					case "4": {
						autocomplete1.setText(webview5.getUrl());
						break;
					}
					case "5": {
						autocomplete1.setText(webview6.getUrl());
						break;
					}
				}
			}
		});
		
		//OnTouch
		openpanel.setOnTouchListener(new View.OnTouchListener(){
				@Override
				public boolean onTouch(View v, MotionEvent event){
						int ev = event.getAction();
						switch (ev) {
								case MotionEvent.ACTION_DOWN:
								
								 if (settingspanel.getVisibility() == View.VISIBLE) {
						settingspanel.setVisibility(View.GONE);
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/NavPan.txt")) == 0) {
							linear5.setVisibility(View.GONE);
						}
					}
					else {
						settingspanel.setVisibility(View.VISIBLE);
						linear5.setVisibility(View.VISIBLE);
						anim.setTarget(settingspanel);
						anim.setPropertyName("scaleY");
						anim.setFloatValues((float)(0), (float)(1));
						anim.setDuration((int)(500));
						anim.start();
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/NavPan.txt")) == 0) {
							anim2.setTarget(linear5);
							anim2.setPropertyName("alpha");
							anim2.setFloatValues((float)(0), (float)(1));
							anim2.setDuration((int)(500));
							anim2.start();
						}
					}
								
								break;
								case MotionEvent.ACTION_UP:
								
								 
								
								break;
						} return true;
				}
		});
		
		//OnTouch
		button3.setOnTouchListener(new View.OnTouchListener(){
				@Override
				public boolean onTouch(View v, MotionEvent event){
						int ev = event.getAction();
						switch (ev) {
								case MotionEvent.ACTION_DOWN:
								
								 intent.setClass(getApplicationContext(), SettingsActivity.class);
					startActivity(intent);
								
								break;
								case MotionEvent.ACTION_UP:
								
								 
								
								break;
						} return true;
				}
		});
		
		tab1.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				tab.get((int)0).put("name", "");
				tab.get((int)0).put("url", "about:blank");
				for (int i = 0; i < (int)(6); i++) {
					if (!tab.get((int)i).get("url").toString().equals("about:blank")) {
						notemptytab = i;
					}
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/activeTab.txt", String.valueOf((long)(notemptytab)));
				}
				webview1.loadUrl("about:blank");
				_Reopentab();
				return true;
			}
		});
		
		tab1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/activeTab.txt", "0");
				linwebview1.bringToFront();
				if (is1window && linwebview1.getVisibility() == View.GONE) {
					linwebview1.setX(0);
					linwebview1.setY(0);
				}
				_Reopentab();
				_setcolofuttons();
			}
		});
		
		tab2.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				tab.get((int)1).put("name", "");
				tab.get((int)1).put("url", "about:blank");
				for (int i = 0; i < (int)(6); i++) {
					if (!tab.get((int)i).get("url").toString().equals("about:blank")) {
						notemptytab = i;
					}
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/activeTab.txt", String.valueOf((long)(notemptytab)));
				}
				webview2.loadUrl("about:blank");
				_Reopentab();
				return true;
			}
		});
		
		tab2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/activeTab.txt", "1");
				linwebview2.bringToFront();
				if (is1window && linwebview2.getVisibility() == View.GONE) {
					linwebview2.setX(0);
					linwebview2.setY(0);
				}
				_Reopentab();
				_setcolofuttons();
			}
		});
		
		tab3.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				tab.get((int)2).put("name", "");
				tab.get((int)2).put("url", "about:blank");
				for (int i = 0; i < (int)(6); i++) {
					if (!tab.get((int)i).get("url").toString().equals("about:blank")) {
						notemptytab = i;
					}
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/activeTab.txt", String.valueOf((long)(notemptytab)));
				}
				webview3.loadUrl("about:blank");
				_Reopentab();
				return true;
			}
		});
		
		tab3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/activeTab.txt", "2");
				linwebview3.bringToFront();
				if (is1window && linwebview3.getVisibility() == View.GONE) {
					linwebview3.setX(0);
					linwebview3.setY(0);
				}
				_Reopentab();
				_setcolofuttons();
			}
		});
		
		tab4.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				tab.get((int)3).put("name", "");
				tab.get((int)3).put("url", "about:blank");
				for (int i = 0; i < (int)(6); i++) {
					if (!tab.get((int)i).get("url").toString().equals("about:blank")) {
						notemptytab = i;
					}
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/activeTab.txt", String.valueOf((long)(notemptytab)));
				}
				webview4.loadUrl("about:blank");
				_Reopentab();
				return true;
			}
		});
		
		tab4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/activeTab.txt", "3");
				linwebview4.bringToFront();
				if (is1window && linwebview4.getVisibility() == View.GONE) {
					linwebview4.setX(0);
					linwebview4.setY(0);
				}
				_Reopentab();
				_setcolofuttons();
			}
		});
		
		tab5.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				tab.get((int)4).put("name", "");
				tab.get((int)4).put("url", "about:blank");
				for (int i = 0; i < (int)(6); i++) {
					if (!tab.get((int)i).get("url").toString().equals("about:blank")) {
						notemptytab = i;
					}
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/activeTab.txt", String.valueOf((long)(notemptytab)));
				}
				webview5.loadUrl("about:blank");
				_Reopentab();
				return true;
			}
		});
		
		tab5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/activeTab.txt", "4");
				linwebview5.bringToFront();
				if (is1window && linwebview5.getVisibility() == View.GONE) {
					linwebview5.setX(0);
					linwebview5.setY(0);
				}
				_Reopentab();
				_setcolofuttons();
			}
		});
		
		tab6.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				tab.get((int)5).put("name", "");
				tab.get((int)5).put("url", "about:blank");
				for (int i = 0; i < (int)(6); i++) {
					if (!tab.get((int)i).get("url").toString().equals("about:blank")) {
						notemptytab = i;
					}
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/activeTab.txt", String.valueOf((long)(notemptytab)));
				}
				webview6.loadUrl("about:blank");
				_Reopentab();
				return true;
			}
		});
		
		tab6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/activeTab.txt", "5");
				linwebview6.bringToFront();
				if (is1window && linwebview6.getVisibility() == View.GONE) {
					linwebview6.setX(0);
					linwebview6.setY(0);
				}
				_Reopentab();
				_setcolofuttons();
			}
		});
		
		pos1.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posx1.txt", String.valueOf((long)(webview1.getScrollX())));
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posy1.txt", String.valueOf((long)(webview1.getScrollY())));
						break;
					}
					case "1": {
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posx1.txt", String.valueOf((long)(webview2.getScrollX())));
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posy1.txt", String.valueOf((long)(webview2.getScrollY())));
						break;
					}
					case "2": {
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posx1.txt", String.valueOf((long)(webview3.getScrollX())));
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posy1.txt", String.valueOf((long)(webview3.getScrollY())));
						break;
					}
					case "3": {
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posx1.txt", String.valueOf((long)(webview4.getScrollX())));
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posy1.txt", String.valueOf((long)(webview4.getScrollY())));
						break;
					}
					case "4": {
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posx1.txt", String.valueOf((long)(webview5.getScrollX())));
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posy1.txt", String.valueOf((long)(webview5.getScrollY())));
						break;
					}
					case "5": {
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posx1.txt", String.valueOf((long)(webview6.getScrollX())));
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posy1.txt", String.valueOf((long)(webview6.getScrollY())));
						break;
					}
				}
				pos1.setText("(".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posx1.txt").concat("; ".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posy1.txt").concat(")")))));
				return true;
			}
		});
		
		pos1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						webview1.scrollTo(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posx1.txt")),Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posy1.txt")));
						break;
					}
					case "1": {
						webview2.scrollTo(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posx1.txt")),Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posy1.txt")));
						break;
					}
					case "2": {
						webview3.scrollTo(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posx1.txt")),Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posy1.txt")));
						break;
					}
					case "3": {
						webview4.scrollTo(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posx1.txt")),Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posy1.txt")));
						break;
					}
					case "4": {
						webview5.scrollTo(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posx1.txt")),Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posy1.txt")));
						break;
					}
					case "5": {
						webview6.scrollTo(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posx1.txt")),Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posy1.txt")));
						break;
					}
				}
			}
		});
		
		pos2.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posx2.txt", String.valueOf((long)(webview1.getScrollX())));
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posy2.txt", String.valueOf((long)(webview1.getScrollY())));
						break;
					}
					case "1": {
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posx2.txt", String.valueOf((long)(webview2.getScrollX())));
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posy2.txt", String.valueOf((long)(webview2.getScrollY())));
						break;
					}
					case "2": {
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posx2.txt", String.valueOf((long)(webview3.getScrollX())));
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posy2.txt", String.valueOf((long)(webview3.getScrollY())));
						break;
					}
					case "3": {
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posx2.txt", String.valueOf((long)(webview4.getScrollX())));
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posy2.txt", String.valueOf((long)(webview4.getScrollY())));
						break;
					}
					case "4": {
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posx2.txt", String.valueOf((long)(webview5.getScrollX())));
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posy2.txt", String.valueOf((long)(webview5.getScrollY())));
						break;
					}
					case "5": {
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posx2.txt", String.valueOf((long)(webview6.getScrollX())));
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posy2.txt", String.valueOf((long)(webview6.getScrollY())));
						break;
					}
				}
				pos2.setText("(".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posx2.txt").concat("; ".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posy2.txt").concat(")")))));
				return true;
			}
		});
		
		pos2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						webview1.scrollTo(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posx2.txt")),Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posy2.txt")));
						break;
					}
					case "1": {
						webview2.scrollTo(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posx2.txt")),Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posy2.txt")));
						break;
					}
					case "2": {
						webview3.scrollTo(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posx2.txt")),Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posy2.txt")));
						break;
					}
					case "3": {
						webview4.scrollTo(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posx2.txt")),Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posy2.txt")));
						break;
					}
					case "4": {
						webview5.scrollTo(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posx2.txt")),Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posy2.txt")));
						break;
					}
					case "5": {
						webview6.scrollTo(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posx2.txt")),Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posy2.txt")));
						break;
					}
				}
			}
		});
		
		pos3.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posx3.txt", String.valueOf((long)(webview1.getScrollX())));
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posy3.txt", String.valueOf((long)(webview1.getScrollY())));
						break;
					}
					case "1": {
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posx3.txt", String.valueOf((long)(webview2.getScrollX())));
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posy3.txt", String.valueOf((long)(webview2.getScrollY())));
						break;
					}
					case "2": {
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posx3.txt", String.valueOf((long)(webview3.getScrollX())));
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posy3.txt", String.valueOf((long)(webview3.getScrollY())));
						break;
					}
					case "3": {
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posx3.txt", String.valueOf((long)(webview4.getScrollX())));
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posy3.txt", String.valueOf((long)(webview4.getScrollY())));
						break;
					}
					case "4": {
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posx3.txt", String.valueOf((long)(webview5.getScrollX())));
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posy3.txt", String.valueOf((long)(webview5.getScrollY())));
						break;
					}
					case "5": {
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posx3.txt", String.valueOf((long)(webview6.getScrollX())));
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posy3.txt", String.valueOf((long)(webview6.getScrollY())));
						break;
					}
				}
				pos3.setText("(".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posx3.txt").concat("; ".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posy3.txt").concat(")")))));
				return true;
			}
		});
		
		pos3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
					case "0": {
						webview1.scrollTo(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posx3.txt")),Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posy3.txt")));
						break;
					}
					case "1": {
						webview2.scrollTo(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posx3.txt")),Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posy3.txt")));
						break;
					}
					case "2": {
						webview3.scrollTo(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posx3.txt")),Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posy3.txt")));
						break;
					}
					case "3": {
						webview4.scrollTo(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posx3.txt")),Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posy3.txt")));
						break;
					}
					case "4": {
						webview5.scrollTo(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posx3.txt")),Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posy3.txt")));
						break;
					}
					case "5": {
						webview6.scrollTo(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posx3.txt")),Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posy3.txt")));
						break;
					}
				}
			}
		});
		
		anim2.addListener(new Animator.AnimatorListener() {
			@Override
			public void onAnimationStart(Animator _param1) {
				
			}
			
			@Override
			public void onAnimationEnd(Animator _param1) {
				
			}
			
			@Override
			public void onAnimationCancel(Animator _param1) {
				
			}
			
			@Override
			public void onAnimationRepeat(Animator _param1) {
				
			}
		});
	}
	
	private void initializeLogic() {
		setupWebView(webview1,this);setupWebView(webview2,this);setupWebView(webview3,this);setupWebView(webview4,this);setupWebView(webview5,this);setupWebView(webview6,this);
		
		
		
		webview1.getSettings().setDomStorageEnabled(true);
		webview2.getSettings().setDomStorageEnabled(true);
		webview3.getSettings().setDomStorageEnabled(true);
		webview4.getSettings().setDomStorageEnabled(true);
		webview5.getSettings().setDomStorageEnabled(true);
		webview6.getSettings().setDomStorageEnabled(true);
		
		
		webview1.getSettings().setDatabaseEnabled(true);
		webview2.getSettings().setDatabaseEnabled(true);
		webview3.getSettings().setDatabaseEnabled(true);
		webview4.getSettings().setDatabaseEnabled(true);
		webview5.getSettings().setDatabaseEnabled(true);
		webview6.getSettings().setDatabaseEnabled(true);
		
		webview1.getSettings().setAllowContentAccess(true);
		webview2.getSettings().setAllowContentAccess(true);
		webview3.getSettings().setAllowContentAccess(true);
		webview4.getSettings().setAllowContentAccess(true);
		webview5.getSettings().setAllowContentAccess(true);
		webview6.getSettings().setAllowContentAccess(true);
		
		webview1.getSettings().setAllowFileAccess(true);
		webview2.getSettings().setAllowFileAccess(true);
		webview3.getSettings().setAllowFileAccess(true);
		webview4.getSettings().setAllowFileAccess(true);
		webview5.getSettings().setAllowFileAccess(true);
		webview6.getSettings().setAllowFileAccess(true);
		
		webview1.getSettings().setSaveFormData(true);
		webview2.getSettings().setSaveFormData(true);
		webview3.getSettings().setSaveFormData(true);
		webview4.getSettings().setSaveFormData(true);
		webview5.getSettings().setSaveFormData(true);
		webview6.getSettings().setSaveFormData(true);
		
		/*webview1.getSettings().setSupportMultipleWindows(true);
webview2.getSettings().setSupportMultipleWindows(true);
webview3.getSettings().setSupportMultipleWindows(true);
webview4.getSettings().setSupportMultipleWindows(true);
webview5.getSettings().setSupportMultipleWindows(true);
webview6.getSettings().setSupportMultipleWindows(true);*/
		
		webview1.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
		webview2.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
		webview3.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
		webview4.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
		webview5.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
		webview6.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
		if(Integer.parseInt(Build.VERSION.SDK)>=20){webview1.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);}
		if(Integer.parseInt(Build.VERSION.SDK)>=20){webview2.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);}
		if(Integer.parseInt(Build.VERSION.SDK)>=20){webview3.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);}
		if(Integer.parseInt(Build.VERSION.SDK)>=20){webview4.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);}
		if(Integer.parseInt(Build.VERSION.SDK)>=20){webview5.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);}
		if(Integer.parseInt(Build.VERSION.SDK)>=20){webview6.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);}
		
		autocomplete1.setOnEditorActionListener(new TextView.OnEditorActionListener() {
			            @Override
			            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				                if (actionId == EditorInfo.IME_ACTION_SEARCH || 
				                    actionId == EditorInfo.IME_ACTION_DONE || 
				                    event != null && event.getAction() == KeyEvent.ACTION_DOWN && event.getKeyCode() == KeyEvent.KEYCODE_ENTER) {
					                    if (event == null || !event.isShiftPressed()) {
						                        button1.performClick();
						                        return true; // Сигналізуємо, що подія оброблена
						                    }
					                }
				                return false;
				            }
			        });
		    
		
		
		_fonts();
		searchpan.setVisibility(View.GONE);
		linear9.setVisibility(View.GONE);
		
		tablayout.setVisibility(View.GONE);
		
		if (!_ispermission()) {
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/incognito.txt").equals("1")) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Tabs.json", "[{\"name\":\"bookmark.html\",\"url\":\"file:///storage/emulated/0/WeekBrowser/bookmark.html\"},{\"name\":\"about:blank\",\"url\":\"about:blank\"},{\"name\":\"about:blank\",\"url\":\"about:blank\"},{\"name\":\"about:blank\",\"url\":\"about:blank\"},{\"name\":\"about:blank\",\"url\":\"about:blank\"},{\"name\":\"about:blank\",\"url\":\"about:blank\"}]");
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/activeTab.txt", "0");
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/incognito.txt", "0");
			}
			info = "";
			textview1.setText(info);
			_ifex();
			_clearonexit();
			_settabswindow();
			_jsset();
			_swipe();
			_restorewindowparam();
			tab = new Gson().fromJson(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Tabs.json"), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			try{
				webview1.loadUrl(tab.get((int)0).get("url").toString());
			}catch(Exception e){
				SketchwareUtil.showMessage(getApplicationContext(), "1");
			}
			try{
				webview2.loadUrl(tab.get((int)1).get("url").toString());
			}catch(Exception e){
				SketchwareUtil.showMessage(getApplicationContext(), "2");
			}
			try{
				webview3.loadUrl(tab.get((int)2).get("url").toString());
			}catch(Exception e){
				SketchwareUtil.showMessage(getApplicationContext(), "3");
			}
			try{
				webview4.loadUrl(tab.get((int)3).get("url").toString());
			}catch(Exception e){
				SketchwareUtil.showMessage(getApplicationContext(), "4");
			}
			try{
				webview5.loadUrl(tab.get((int)4).get("url").toString());
			}catch(Exception e){
				SketchwareUtil.showMessage(getApplicationContext(), "5");
			}
			try{
				webview6.loadUrl(tab.get((int)5).get("url").toString());
			}catch(Exception e){
				SketchwareUtil.showMessage(getApplicationContext(), "6");
			}
			font.setProgress((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/fontsize.txt")));
			seekbar1.setProgress((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/minfont.txt")));
			dp.setProgress((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt")));
			try{
				textview5.setText(languag.get((int)(9)).concat(String.valueOf((long)(dp.getProgress() * 10)).concat(")")));
			}catch(Exception e){
				if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
					textview5.setText("UI size (".concat(String.valueOf((long)(dp.getProgress() * 10)).concat(")")));
				}
				else {
					textview5.setText("Розмір інтерфейсу (".concat(String.valueOf((long)(dp.getProgress() * 10)).concat(")")));
				}
			}
			settingspanel.setVisibility(View.GONE);
			webview1.getSettings().setBuiltInZoomControls(true);
			webview1.getSettings().setDisplayZoomControls(false);
			webview2.getSettings().setBuiltInZoomControls(true);
			webview2.getSettings().setDisplayZoomControls(false);
			webview3.getSettings().setBuiltInZoomControls(true);
			webview3.getSettings().setDisplayZoomControls(false);
			webview4.getSettings().setBuiltInZoomControls(true);
			webview4.getSettings().setDisplayZoomControls(false);
			webview5.getSettings().setBuiltInZoomControls(true);
			webview5.getSettings().setDisplayZoomControls(false);
			webview6.getSettings().setBuiltInZoomControls(true);
			webview6.getSettings().setDisplayZoomControls(false);
			webview1.getSettings().setLoadWithOverviewMode(false);
			webview1.getSettings().setUseWideViewPort(false);
			webview2.getSettings().setLoadWithOverviewMode(false);
			webview2.getSettings().setUseWideViewPort(false);
			webview3.getSettings().setLoadWithOverviewMode(false);
			webview3.getSettings().setUseWideViewPort(false);
			webview4.getSettings().setLoadWithOverviewMode(false);
			webview4.getSettings().setUseWideViewPort(false);
			webview5.getSettings().setLoadWithOverviewMode(false);
			webview5.getSettings().setUseWideViewPort(false);
			webview6.getSettings().setLoadWithOverviewMode(false);
			webview6.getSettings().setUseWideViewPort(false);
			((EditText)autocomplete1).setMaxLines((int)1);
			((EditText)search).setMaxLines((int)3);
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/NavPan.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/NavPan.txt", "1");
			}
			if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/incognito.txt")) == 1) {
				if (android.os.Build.VERSION.SDK_INT >= 21) { CookieManager.getInstance().setAcceptThirdPartyCookies(webview1, false);CookieManager.getInstance().setAcceptThirdPartyCookies(webview2, false);CookieManager.getInstance().setAcceptThirdPartyCookies(webview3, false);CookieManager.getInstance().setAcceptThirdPartyCookies(webview4, false);CookieManager.getInstance().setAcceptThirdPartyCookies(webview5, false);CookieManager.getInstance().setAcceptThirdPartyCookies(webview6, false); } else { CookieManager.getInstance().setAcceptCookie(false); }
				incognito.setChecked(true);
			}
			else {
				if (android.os.Build.VERSION.SDK_INT >= 21) { CookieManager.getInstance().setAcceptThirdPartyCookies(webview1, true);CookieManager.getInstance().setAcceptThirdPartyCookies(webview2, true);CookieManager.getInstance().setAcceptThirdPartyCookies(webview3, true);CookieManager.getInstance().setAcceptThirdPartyCookies(webview4, true);CookieManager.getInstance().setAcceptThirdPartyCookies(webview5, true);CookieManager.getInstance().setAcceptThirdPartyCookies(webview6, true); } else { CookieManager.getInstance().setAcceptCookie(true); }
				incognito.setChecked(false);
			}
			if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/BlockAd.txt")) == 1) {
				blockad.setChecked(true);
			}
			else {
				blockad.setChecked(false);
			}
			if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/IfameBlock.txt")) == 1) {
				iframe.setChecked(true);
			}
			else {
				iframe.setChecked(false);
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/NavPan.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/NavPan.txt", "1");
			}
			
			timer = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/onNoInternet.txt").equals("1")) {
								if (Internet) {
									webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
									webview2.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
									webview3.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
									webview4.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
									webview5.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
									webview6.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
								}
								else {
									if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/incognito.txt").equals("0")) {
										if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 0) {
											webview1.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
											webview2.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
											webview3.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
											webview4.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
											webview5.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
											webview6.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
										}
										else {
											if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 1) {
												webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
												webview2.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
												webview3.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
												webview4.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
												webview5.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
												webview6.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
											}
											else {
												if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 2) {
													webview1.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
													webview2.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
													webview3.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
													webview4.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
													webview5.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
													webview6.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
												}
												else {
													webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
													webview2.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
													webview3.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
													webview4.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
													webview5.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
													webview6.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
												}
											}
										}
									}
									else {
										if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 0) {
											webview1.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
											webview2.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
											webview3.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
											webview4.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
											webview5.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
											webview6.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
										}
										else {
											if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 1) {
												webview1.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
												webview2.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
												webview3.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
												webview4.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
												webview5.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
												webview6.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
											}
											else {
												if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 2) {
													webview1.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
													webview2.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
													webview3.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
													webview4.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
													webview5.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
													webview6.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
												}
												else {
													webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
													webview2.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
													webview3.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
													webview4.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
													webview5.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
													webview6.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
												}
											}
										}
									}
								}
							}
							_loading();
							if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/LoadImages.txt").equals("1")) {
								webview1.getSettings().setBlockNetworkImage(false);
								webview1.getSettings().setLoadsImagesAutomatically(true);
								webview2.getSettings().setBlockNetworkImage(false);
								webview2.getSettings().setLoadsImagesAutomatically(true);
								webview3.getSettings().setBlockNetworkImage(false);
								webview3.getSettings().setLoadsImagesAutomatically(true);
								webview4.getSettings().setBlockNetworkImage(false);
								webview4.getSettings().setLoadsImagesAutomatically(true);
								webview5.getSettings().setBlockNetworkImage(false);
								webview5.getSettings().setLoadsImagesAutomatically(true);
								webview6.getSettings().setBlockNetworkImage(false);
								webview6.getSettings().setLoadsImagesAutomatically(true);
								image.setChecked(true);
							}
							else {
								webview1.getSettings().setBlockNetworkImage(true);webview1.getSettings().setLoadsImagesAutomatically(false);
								webview2.getSettings().setBlockNetworkImage(true);webview2.getSettings().setLoadsImagesAutomatically(false);
								webview3.getSettings().setBlockNetworkImage(true);webview3.getSettings().setLoadsImagesAutomatically(false);
								webview4.getSettings().setBlockNetworkImage(true);webview4.getSettings().setLoadsImagesAutomatically(false);
								webview5.getSettings().setBlockNetworkImage(true);webview5.getSettings().setLoadsImagesAutomatically(false);
								webview6.getSettings().setBlockNetworkImage(true);webview6.getSettings().setLoadsImagesAutomatically(false);
								image.setChecked(false);
							}
							num.setText(String.valueOf((long)(curnum)).concat("/".concat(String.valueOf((long)(allnum)))));
							_titl();
							_instantbookmarklets();
							if (is1window) {
								
							}
							else {
								_setTopPadding(linwebview1, 0);
								linwebview1.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
								linwebview1.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
								((LinearLayout.LayoutParams) linwebview1.getLayoutParams()).weight = 1; // або будь-яке інше значення, яке вам потрібно
								linwebview1.requestLayout();
								linwebview1.setX(0);
								linwebview1.setY(0);
								_setTopPadding(linwebview2, 0);
								linwebview2.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
								linwebview2.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
								((LinearLayout.LayoutParams) linwebview2.getLayoutParams()).weight = 1; // або будь-яке інше значення, яке вам потрібно
								linwebview2.requestLayout();
								linwebview2.setX(0);
								linwebview2.setY(0);
								_setTopPadding(linwebview3, 0);
								linwebview3.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
								linwebview3.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
								((LinearLayout.LayoutParams) linwebview3.getLayoutParams()).weight = 1; // або будь-яке інше значення, яке вам потрібно
								linwebview3.requestLayout();
								linwebview3.setX(0);
								linwebview3.setY(0);
								_setTopPadding(linwebview4, 0);
								linwebview4.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
								linwebview4.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
								((LinearLayout.LayoutParams) linwebview4.getLayoutParams()).weight = 1; // або будь-яке інше значення, яке вам потрібно
								linwebview4.requestLayout();
								linwebview4.setX(0);
								linwebview4.setY(0);
								_setTopPadding(linwebview5, 0);
								linwebview5.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
								linwebview5.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
								((LinearLayout.LayoutParams) linwebview5.getLayoutParams()).weight = 1; // або будь-яке інше значення, яке вам потрібно
								linwebview5.requestLayout();
								linwebview5.setX(0);
								linwebview5.setY(0);
								_setTopPadding(linwebview6, 0);
								linwebview6.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
								linwebview6.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
								((LinearLayout.LayoutParams) linwebview6.getLayoutParams()).weight = 1; // або будь-яке інше значення, яке вам потрібно
								linwebview6.requestLayout();
								linwebview6.setX(0);
								linwebview6.setY(0);
							}
						}
					});
				}
			};
			_timer.scheduleAtFixedRate(timer, (int)(149), (int)(150));
			timer = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							new async().execute("");
							_Blockifr();
						}
					});
				}
			};
			_timer.scheduleAtFixedRate(timer, (int)(1499), (int)(1500));
			webview1.setLayerType(View.LAYER_TYPE_HARDWARE, null);
			webview2.setLayerType(View.LAYER_TYPE_HARDWARE, null);
			webview3.setLayerType(View.LAYER_TYPE_HARDWARE, null);
			webview4.setLayerType(View.LAYER_TYPE_HARDWARE, null);
			webview5.setLayerType(View.LAYER_TYPE_HARDWARE, null);
			webview6.setLayerType(View.LAYER_TYPE_HARDWARE, null);
			pos1.setText("(".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posx1.txt").concat("; ".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posy1.txt").concat(")")))));
			pos2.setText("(".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posx2.txt").concat("; ".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posy2.txt").concat(")")))));
			pos3.setText("(".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posx3.txt").concat("; ".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posy3.txt").concat(")")))));
			timer = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							if (statush) {
								getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_FULLSCREEN
								        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
								        | View.SYSTEM_UI_FLAG_IMMERSIVE);
								isnotchfullscreen = true;
							}
						}
					});
				}
			};
			_timer.scheduleAtFixedRate(timer, (int)(2999), (int)(3000));
			_Reopentab();
			timer = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							if (!focused) {
								if (!ismovedpanels) {
									if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Navpanelpos.txt").equals("1")) {
										linear2.removeView(searchpan);
										    linear2.addView(searchpan, 0);
										
										linear2.removeView(linear9);
										    linear2.addView(linear9, 0);
										
										linear2.removeView(nav);
										    linear2.addView(nav, 0);
									}
									else {
										linear2.removeView(linear9);
										    linear2.addView(linear9);
										
										linear2.removeView(nav);
										    linear2.addView(nav);
										
										linear2.removeView(searchpan);
										    linear2.addView(searchpan);
									}
									if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Searchpanelpos.txt").equals("1")) {
										linear2.removeView(settingspanel);
										    linear2.addView(settingspanel, 0);
										
										
										linear2.removeView(linear1);
										    linear2.addView(linear1, 0);
									}
									else {
										linear2.removeView(settingspanel);
										    linear2.addView(settingspanel);
										
										linear2.removeView(linear1);
										    linear2.addView(linear1);
									}
								}
								ismovedpanels = true;
							}
						}
					});
				}
			};
			_timer.scheduleAtFixedRate(timer, (int)(0), (int)(1000));
		}
		_download(webview1);
		_download(webview2);
		_download(webview3);
		_download(webview4);
		_download(webview5);
		_download(webview6);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_FP:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
			}
			break;
			
			case REQUEST_SELECT_FILE:
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
				if (uploadMessage == null) return; uploadMessage.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(_resultCode, _data)); uploadMessage = null; }
			break;
			
			case FILECHOOSER_RESULTCODE:
			if (null == mUploadMessage){
				return; }
			Uri result = _data == null || _resultCode != RESULT_OK ? null : _data.getData(); mUploadMessage.onReceiveValue(result);
			mUploadMessage = null;
			
			if (true){
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	private class async extends AsyncTask<String, Integer, String> {
		@Override
		protected void onPreExecute() {
			
		}
		
		@Override
		protected String doInBackground(String... params) {
			String _param = params[0];
			try {
				        int timeoutMs = 1500;
				        Socket sock = new Socket();
				        SocketAddress sockaddr = new InetSocketAddress("8.8.8.8", 53);
				
				        sock.connect(sockaddr, timeoutMs);
				        sock.close();
				
				        Internet=false;
				    } catch (IOException e) {Internet=true;}
			return ("");
		}
		
		@Override
		protected void onProgressUpdate(Integer... values) {
			int _value = values[0];
			
		}
		
		@Override
		protected void onPostExecute(String _result) {
			
		}
	}
	
	private class buttoncolorificator extends AsyncTask<String, Integer, String> {
		@Override
		protected void onPreExecute() {
			
		}
		
		@Override
		protected String doInBackground(String... params) {
			String _param = params[0];
			isredrawbuttons = true;
			buttoncolors = 100000000;
			try{
				for (int i = 0; i < (int)(sitepermis.size()); i++) {
					if (tempurl.contains(sitepermis.get((int)i).get("url").toString())) {
						switch(sitepermis.get((int)i).get("ad").toString()) {
							case "1": {
								buttoncolors = buttoncolors + 1;
								break;
							}
							case "2": {
								buttoncolors = buttoncolors + 2;
								break;
							}
						}
						issu = true;
					}
				}
				if (!issu) {
					buttoncolors = buttoncolors + 2;
				}
			}catch(Exception e){
				buttoncolors = buttoncolors + 2;
			}
			issu = false;
			try{
				for (int i = 0; i < (int)(sitepermis.size()); i++) {
					if (tempurl.contains(sitepermis.get((int)i).get("url").toString())) {
						switch(sitepermis.get((int)i).get("if").toString()) {
							case "1": {
								buttoncolors = buttoncolors + 10;
								break;
							}
							case "2": {
								buttoncolors = buttoncolors + 20;
								break;
							}
						}
						issu = true;
					}
				}
				if (!issu) {
					buttoncolors = buttoncolors + 20;
				}
			}catch(Exception e){
				buttoncolors = buttoncolors + 20;
			}
			issu = false;
			try{
				for (int i = 0; i < (int)(sitepermis.size()); i++) {
					if (tempurl.contains(sitepermis.get((int)i).get("url").toString())) {
						switch(sitepermis.get((int)i).get("js").toString()) {
							case "1": {
								buttoncolors = buttoncolors + 100;
								break;
							}
							case "2": {
								buttoncolors = buttoncolors + 200;
								break;
							}
						}
						issu = true;
					}
				}
				if (!issu) {
					buttoncolors = buttoncolors + 200;
				}
			}catch(Exception e){
				buttoncolors = buttoncolors + 200;
			}
			issu = false;
			try{
				for (int i = 0; i < (int)(sitepermis.size()); i++) {
					if (tempurl.contains(sitepermis.get((int)i).get("url").toString())) {
						switch(sitepermis.get((int)i).get("th").toString()) {
							case "1": {
								buttoncolors = buttoncolors + 1000;
								break;
							}
							case "2": {
								buttoncolors = buttoncolors + 2000;
								break;
							}
						}
						issu = true;
					}
				}
				if (!issu) {
					buttoncolors = buttoncolors + 2000;
				}
			}catch(Exception e){
				buttoncolors = buttoncolors + 2000;
			}
			issu = false;
			try{
				for (int i = 0; i < (int)(sitepermis.size()); i++) {
					if (tempurl.contains(sitepermis.get((int)i).get("url").toString())) {
						switch(sitepermis.get((int)i).get("sr").toString()) {
							case "1": {
								buttoncolors = buttoncolors + 10000;
								break;
							}
							case "2": {
								buttoncolors = buttoncolors + 20000;
								break;
							}
						}
						issu = true;
					}
				}
				if (!issu) {
					buttoncolors = buttoncolors + 20000;
				}
			}catch(Exception e){
				buttoncolors = buttoncolors + 20000;
			}
			issu = false;
			return ("");
		}
		
		@Override
		protected void onProgressUpdate(Integer... values) {
			int _value = values[0];
			
		}
		
		@Override
		protected void onPostExecute(String _result) {
			int color1 = (int) Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg.txt"), 16);
			int color2 = (int) Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg2.txt"), 16);
			final int roundness = Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/roundness.txt"));
			int rcolor1 = (int) Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg.txt"), 16);
			int rcolor2 = (int) Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg2.txt"), 16);
			switch(String.valueOf((long)(buttoncolors)).substring((int)(8), (int)(9))) {
				case "1": {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
						blockad.setBackgroundColor(0xFF33B5E5);
						blockad.setTextColor(0xFF000000);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
							blockad.setBackgroundColor(0xFF33B5E5);
							blockad.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
								blockad.setBackgroundColor(0xFF00FF00);
								blockad.setTextColor(0xFF000000);
							}
							else {
											blockad.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
											blockad.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
										    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
									}});
							}
						}
					}
					break;
				}
				case "2": {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
						blockad.setBackgroundColor(Color.TRANSPARENT);
						blockad.setTextColor(0xFF000000);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
							blockad.setBackgroundColor(Color.TRANSPARENT);
							blockad.setTextColor(0xFFFFFFFF);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
								blockad.setBackgroundColor(Color.TRANSPARENT);
								blockad.setTextColor(0xFF00FF00);
							}
							else {
											blockad.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
								blockad.setBackgroundColor(Color.TRANSPARENT);
							}
						}
					}
					break;
				}
				case "0": {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
						blockad.setBackgroundColor(0xFFB71C1C);
						blockad.setTextColor(0xFF000000);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
							blockad.setBackgroundColor(0xFFB71C1C);
							blockad.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
								blockad.setBackgroundColor(0xFFF00000);
								blockad.setTextColor(0xFF000000);
							}
							else {
											blockad.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
											blockad.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
										    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
									}});
							}
						}
					}
					break;
				}
			}
			switch(String.valueOf((long)(buttoncolors)).substring((int)(7), (int)(8))) {
				case "1": {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
						iframe.setBackgroundColor(0xFF33B5E5);
						iframe.setTextColor(0xFF000000);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
							iframe.setBackgroundColor(0xFF33B5E5);
							iframe.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
								iframe.setBackgroundColor(0xFF00FF00);
								iframe.setTextColor(0xFF000000);
							}
							else {
											iframe.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
											iframe.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
										    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
									}});
							}
						}
					}
					break;
				}
				case "2": {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
						iframe.setBackgroundColor(Color.TRANSPARENT);
						iframe.setTextColor(0xFF000000);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
							iframe.setBackgroundColor(Color.TRANSPARENT);
							iframe.setTextColor(0xFFFFFFFF);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
								iframe.setBackgroundColor(Color.TRANSPARENT);
								iframe.setTextColor(0xFF00FF00);
							}
							else {
											iframe.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
								iframe.setBackgroundColor(Color.TRANSPARENT);
							}
						}
					}
					break;
				}
				case "0": {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
						iframe.setBackgroundColor(0xFFB71C1C);
						iframe.setTextColor(0xFF000000);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
							iframe.setBackgroundColor(0xFFB71C1C);
							iframe.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
								iframe.setBackgroundColor(0xFFF00000);
								iframe.setTextColor(0xFF000000);
							}
							else {
											iframe.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
											iframe.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
										    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
									}});
							}
						}
					}
					break;
				}
			}
			switch(String.valueOf((long)(buttoncolors)).substring((int)(6), (int)(7))) {
				case "1": {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
						js.setBackgroundColor(0xFF33B5E5);
						js.setTextColor(0xFF000000);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
							js.setBackgroundColor(0xFF33B5E5);
							js.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
								js.setBackgroundColor(0xFF00FF00);
								js.setTextColor(0xFF000000);
							}
							else {
											js.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
											js.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
										    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
									}});
							}
						}
					}
					break;
				}
				case "2": {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
						js.setBackgroundColor(Color.TRANSPARENT);
						js.setTextColor(0xFF000000);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
							js.setBackgroundColor(Color.TRANSPARENT);
							js.setTextColor(0xFFFFFFFF);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
								js.setBackgroundColor(Color.TRANSPARENT);
								js.setTextColor(0xFF00FF00);
							}
							else {
											js.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
								js.setBackgroundColor(Color.TRANSPARENT);
							}
						}
					}
					break;
				}
				case "0": {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
						js.setBackgroundColor(0xFFB71C1C);
						js.setTextColor(0xFF000000);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
							js.setBackgroundColor(0xFFB71C1C);
							js.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
								js.setBackgroundColor(0xFFF00000);
								js.setTextColor(0xFF000000);
							}
							else {
											js.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
											js.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
										    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
									}});
							}
						}
					}
					break;
				}
			}
			switch(String.valueOf((long)(buttoncolors)).substring((int)(5), (int)(6))) {
				case "1": {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
						themepage.setBackgroundColor(0xFF33B5E5);
						themepage.setTextColor(0xFF000000);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
							themepage.setBackgroundColor(0xFF33B5E5);
							themepage.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
								themepage.setBackgroundColor(0xFF00FF00);
								themepage.setTextColor(0xFF000000);
							}
							else {
											themepage.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
											themepage.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
										    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
									}});
							}
						}
					}
					break;
				}
				case "2": {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
						themepage.setBackgroundColor(Color.TRANSPARENT);
						themepage.setTextColor(0xFF000000);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
							themepage.setBackgroundColor(Color.TRANSPARENT);
							themepage.setTextColor(0xFFFFFFFF);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
								themepage.setBackgroundColor(Color.TRANSPARENT);
								themepage.setTextColor(0xFF00FF00);
							}
							else {
											themepage.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
								themepage.setBackgroundColor(Color.TRANSPARENT);
							}
						}
					}
					break;
				}
				case "0": {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
						themepage.setBackgroundColor(0xFFB71C1C);
						themepage.setTextColor(0xFF000000);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
							themepage.setBackgroundColor(0xFFB71C1C);
							themepage.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
								themepage.setBackgroundColor(0xFFF00000);
								themepage.setTextColor(0xFF000000);
							}
							else {
											themepage.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
											themepage.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
										    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
									}});
							}
						}
					}
					break;
				}
			}
			switch(String.valueOf((long)(buttoncolors)).substring((int)(4), (int)(5))) {
				case "1": {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
						swipetore.setBackgroundColor(0xFF33B5E5);
						swipetore.setTextColor(0xFF000000);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
							swipetore.setBackgroundColor(0xFF33B5E5);
							swipetore.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
								swipetore.setBackgroundColor(0xFF00FF00);
								swipetore.setTextColor(0xFF000000);
							}
							else {
											swipetore.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
											swipetore.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
										    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
									}});
							}
						}
					}
					break;
				}
				case "2": {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
						swipetore.setBackgroundColor(Color.TRANSPARENT);
						swipetore.setTextColor(0xFF000000);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
							swipetore.setBackgroundColor(Color.TRANSPARENT);
							swipetore.setTextColor(0xFFFFFFFF);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
								swipetore.setBackgroundColor(Color.TRANSPARENT);
								swipetore.setTextColor(0xFF00FF00);
							}
							else {
											swipetore.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
								swipetore.setBackgroundColor(Color.TRANSPARENT);
							}
						}
					}
					break;
				}
				case "0": {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
						swipetore.setBackgroundColor(0xFFB71C1C);
						swipetore.setTextColor(0xFF000000);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
							swipetore.setBackgroundColor(0xFFB71C1C);
							swipetore.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
								swipetore.setBackgroundColor(0xFFF00000);
								swipetore.setTextColor(0xFF000000);
							}
							else {
											swipetore.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
											swipetore.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
										    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
									}});
							}
						}
					}
					break;
				}
			}
			isredrawbuttons = false;
		}
	}
	
	private class histor extends AsyncTask<String, Integer, String> {
		@Override
		protected void onPreExecute() {
			
		}
		
		@Override
		protected String doInBackground(String... params) {
			String _param = params[0];
			dnt = Calendar.getInstance();
			if (!(_param.equals("file:///storage/emulated/0/WeekBrowser/bookmark.html") || _param.equals("about:blank"))) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/incognito.txt")) == 0) {
					HashMap<String, Object> _item = new HashMap<>();
					_item.put("name", "UNTITLED :-/");
					_item.put("url", _param);
					_item.put("date", new SimpleDateFormat("dd/MM EE HH:mm").format(dnt.getTime()) );
					history.add(_item);
					if (history.size() > Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/SaveNumOfHistory.txt"))) {
						    int numberOfItemsToRemove = history.size() - Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/SaveNumOfHistory.txt"));
						    history.subList(0, numberOfItemsToRemove).clear();
					}
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/history.json", new Gson().toJson(history));
				}
			}
			return ("");
		}
		
		@Override
		protected void onProgressUpdate(Integer... values) {
			int _value = values[0];
			
		}
		
		@Override
		protected void onPostExecute(String _result) {
			
		}
	}
	
	private class histor2 extends AsyncTask<String, Integer, String> {
		@Override
		protected void onPreExecute() {
			
		}
		
		@Override
		protected String doInBackground(String... params) {
			String _param = params[0];
			if (!(_param.equals("bookmark.html") || _param.equals("about:blank"))) {
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/incognito.txt").equals("0")) {
					if (!history.isEmpty()) {
						    HashMap<String, Object> lastItem = history.get(history.size() - 1);
						    lastItem.put("name", _param);
					}
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/history.json", new Gson().toJson(history));
				}
			}
			return ("");
		}
		
		@Override
		protected void onProgressUpdate(Integer... values) {
			int _value = values[0];
			
		}
		
		@Override
		protected void onPostExecute(String _result) {
			
		}
	}
	
	@Override
	public void onBackPressed() {
		switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
			case "0": {
				if (webview1.canGoBack()) {
					webview1.goBack();
				}
				else {
					dial.setTitle("ВИХІД");
					dial.setMessage("Ви дійсно хочете вийти?");
					dial.setPositiveButton("Так", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							finish();
						}
					});
					dial.setNegativeButton("Ні", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					dial.create().show();
				}
				break;
			}
			case "1": {
				if (webview2.canGoBack()) {
					webview2.goBack();
				}
				else {
					dial.setTitle("ВИХІД");
					dial.setMessage("Ви дійсно хочете вийти?");
					dial.setPositiveButton("Так", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							finish();
						}
					});
					dial.setNegativeButton("Ні", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					dial.create().show();
				}
				break;
			}
			case "2": {
				if (webview3.canGoBack()) {
					webview3.goBack();
				}
				else {
					dial.setTitle("ВИХІД");
					dial.setMessage("Ви дійсно хочете вийти?");
					dial.setPositiveButton("Так", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							finish();
						}
					});
					dial.setNegativeButton("Ні", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					dial.create().show();
				}
				break;
			}
			case "3": {
				if (webview4.canGoBack()) {
					webview4.goBack();
				}
				else {
					dial.setTitle("ВИХІД");
					dial.setMessage("Ви дійсно хочете вийти?");
					dial.setPositiveButton("Так", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							finish();
						}
					});
					dial.setNegativeButton("Ні", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					dial.create().show();
				}
				break;
			}
			case "4": {
				if (webview5.canGoBack()) {
					webview5.goBack();
				}
				else {
					dial.setTitle("ВИХІД");
					dial.setMessage("Ви дійсно хочете вийти?");
					dial.setPositiveButton("Так", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							finish();
						}
					});
					dial.setNegativeButton("Ні", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					dial.create().show();
				}
				break;
			}
			case "5": {
				if (webview6.canGoBack()) {
					webview6.goBack();
				}
				else {
					dial.setTitle("ВИХІД");
					dial.setMessage("Ви дійсно хочете вийти?");
					dial.setPositiveButton("Так", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							finish();
						}
					});
					dial.setNegativeButton("Ні", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					dial.create().show();
				}
				break;
			}
		}
	}
	
	@Override
	public void onResume() {
		super.onResume();
		if (!_ispermission()) {
			designbmlcache = FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache/bmkdsgn.txt");
			ismovedpanels = false;
			_verifynew();
			_restorewindowparam();
			_buttonsizeset();
			srcsug = new Gson().fromJson(FileUtil.readFile("/storage/emulated/0/WeekBrowser/search.txt"), new TypeToken<ArrayList<String>>(){}.getType());
			getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
			
			_newintentt();
			_monet();
			linear1.setVisibility(View.VISIBLE);
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/")) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/InfoText.txt")) == 1) {
					textview1.setGravity(Gravity.CENTER_HORIZONTAL);
				}
				else {
					textview1.setGravity(Gravity.LEFT);
				}
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/PC.txt")) == 1) {
					webview1.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*5);webview1.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/currentpc.txt"));
					webview2.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*5);webview2.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/currentpc.txt"));
					webview3.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*5);webview3.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/currentpc.txt"));
					webview4.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*5);webview4.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/currentpc.txt"));
					webview5.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*5);webview5.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/currentpc.txt"));
					webview6.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*5);webview6.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/currentpc.txt"));
					pc.setChecked(true);
				}
				else {
					webview1.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*10);webview1.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/current.txt"));
					webview2.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*10);webview2.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/current.txt"));
					webview3.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*10);webview3.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/current.txt"));
					webview4.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*10);webview4.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/current.txt"));
					webview5.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*10);webview5.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/current.txt"));
					webview6.setInitialScale((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*10);webview6.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/current.txt"));
					pc.setChecked(false);
				}
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/themepage.txt")) == 1) {
					themepage.setChecked(true);
				}
				else {
					themepage.setChecked(false);
				}
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Swipetorefresh.txt")) == 1) {
					swipetore.setChecked(true);
				}
				else {
					swipetore.setChecked(false);
				}
				supermenu.setChecked(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Supermenu.txt").equals("1"));
				
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/incognito.txt")) == 1) {
					if (android.os.Build.VERSION.SDK_INT >= 21) { CookieManager.getInstance().setAcceptThirdPartyCookies(webview1, false); } else { CookieManager.getInstance().setAcceptCookie(false); }
					
					openpanel.setText("👀");
					
					webview1.getSettings().setDomStorageEnabled(true);
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 0) {
						webview1.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
						webview2.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
						webview3.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
						webview4.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
						webview5.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
						webview6.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 1) {
							webview1.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
							webview2.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
							webview3.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
							webview4.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
							webview5.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
							webview6.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 2) {
								webview1.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
								webview2.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
								webview3.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
								webview4.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
								webview5.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
								webview6.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
							}
							else {
								webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
								webview2.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
								webview3.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
								webview4.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
								webview5.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
								webview6.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
							}
						}
					}
					if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/NoScreen.txt").equals("0")) {
						getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
					}
					if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/NoScreen.txt").equals("1")) {
						getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
					}
				}
				else {
					WebView webview1 = findViewById(R.id.webview1); if (android.os.Build.VERSION.SDK_INT >= 21) { CookieManager.getInstance().setAcceptThirdPartyCookies(webview1, true); } else { CookieManager.getInstance().setAcceptCookie(true); }
					
					
					openpanel.setText("");
					
					webview1.getSettings().setDomStorageEnabled(true);
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 0) {
						webview1.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
						webview2.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
						webview3.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
						webview4.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
						webview5.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
						webview6.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 1) {
							webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
							webview2.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
							webview3.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
							webview4.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
							webview5.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
							webview6.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 2) {
								webview1.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
								webview2.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
								webview3.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
								webview4.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
								webview5.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
								webview6.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
							}
							else {
								webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
								webview2.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
								webview3.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
								webview4.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
								webview5.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
								webview6.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
							}
						}
					}
					getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
				}
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/NavPan.txt")) == 1) {
					linear5.setVisibility(View.VISIBLE);
				}
				else {
					linear5.setVisibility(View.GONE);
				}
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
					_light();
					addshortcut.setTextColor(0xFF000000);
					addshortcut.setBackgroundColor(0xFF33B5E5);
					copyallurl.setTextColor(0xFF000000);
					copyallurl.setBackgroundColor(0xFF33B5E5);
					multilink.setTextColor(0xFF000000);
					multilink.setBackgroundColor(0xFF33B5E5);
					share.setTextColor(0xFF000000);
					share.setBackgroundColor(0xFF33B5E5);
					otherapp.setTextColor(0xFF000000);
					otherapp.setBackgroundColor(0xFF33B5E5);
				}
				else {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
						_dark();
						addshortcut.setTextColor(0xFF000000);
						addshortcut.setBackgroundColor(0xFF33B5E5);
						copyallurl.setTextColor(0xFF000000);
						copyallurl.setBackgroundColor(0xFF33B5E5);
						multilink.setTextColor(0xFF000000);
						multilink.setBackgroundColor(0xFF33B5E5);
						share.setTextColor(0xFF000000);
						share.setBackgroundColor(0xFF33B5E5);
						otherapp.setTextColor(0xFF000000);
						otherapp.setBackgroundColor(0xFF33B5E5);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
							_hicontr();
							addshortcut.setTextColor(0xFF000000);
							addshortcut.setBackgroundColor(0xFF00FF00);
							copyallurl.setTextColor(0xFF000000);
							copyallurl.setBackgroundColor(0xFF00FF00);
							multilink.setTextColor(0xFF000000);
							multilink.setBackgroundColor(0xFF00FF00);
							share.setTextColor(0xFF000000);
							share.setBackgroundColor(0xFF00FF00);
							otherapp.setTextColor(0xFF000000);
							otherapp.setBackgroundColor(0xFF00FF00);
						}
						else {
							bml5.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));bml4.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));bml3.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));bml2.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));linear1.setBackgroundColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/bg.txt"),16));
							searchpan.setBackgroundColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/bg.txt"),16));
										nav.setBackgroundColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/bg.txt"),16));
								multilink.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));	tabscontainer.setBackgroundColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/bg.txt"),16));
									windowsmanager.setBackgroundColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/bg.txt"),16));
										settingspanel.setBackgroundColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/bg.txt"),16));
										pc.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
										supermenu.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
										title.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
							addshortcut.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
							share.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
							otherapp.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
							
							blockad.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
							num.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
							iframe.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
							
							image.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
										js.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
									incognito.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
										back.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
							hide.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
										forward.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
							pagesearch.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
							copyallurl.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
							sup.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
							sdown.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
										pgup.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
							refresh.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
										pgdn.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
										home.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
							tabs.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
										dual.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
										histori.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
										skipvideo.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
										autocomplete1.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/textfield.txt"),16));
							search.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/textfield.txt"),16));
							textview2.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt"),16));
										textview5.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt"),16));
										textview3.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt"),16));
										autocomplete1.setHintTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt"),16));
							search.setHintTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt"),16));
										refresh.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
										button1.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
										openpanel.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
										bookmarks.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
										button3.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
										textview1.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
							coordinates.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
							pos1.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
							pos2.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
							pos3.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
										
										
										
							
							
							
							bml1.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
							
							
							
							
							widthp1.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
							
							widthm1.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
							
							heightp1.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
							
							heightm1.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
							
							int color1 = (int) Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg.txt"), 16);
							int color2 = (int) Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg2.txt"), 16);
							final int roundness = Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/roundness.txt"));
							
							
							
							
							heightm1.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
							back.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
							
							heightp1.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
							widthm1.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
							heightm1.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
							widthp1.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
							addshortcut.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
							bml1.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
							bml2.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
							bml3.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
							bml4.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
							bml5.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
							pos1.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
							pos2.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
							pos3.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
							skipvideo.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
							hide.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
										button1.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
										openpanel.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
										button3.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
							refresh.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
							coordinates.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
							pgup.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
										pgdn.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
										bookmarks.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
										home.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
										histori.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
										tabs.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
								dual.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
								textview1.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
							copyallurl.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
							pagesearch.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
							sup.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
							sdown.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
										forward.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
							multilink.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
							
							share.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
							
							otherapp.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
									    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
								}});
							
						}
					}
				}
			}
			bml1.setText(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20001n.txt"));
			bml2.setText(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20002n.txt"));
			bml3.setText(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20003n.txt"));
			bml4.setText(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20004n.txt"));
			bml5.setText(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20005n.txt"));
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/ZoomButton.txt").equals("1")) {
				webview1.getSettings().setDisplayZoomControls(true);
			}
			else {
				webview1.getSettings().setDisplayZoomControls(false);
			}
			_language();
			if (!FileUtil.readFile("/storage/emulated/0/ColorPicker/color.txt").isEmpty()) {
				intent.setClass(getApplicationContext(), CustomthemeActivity.class);
				startActivity(intent);
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/monofortextarea.txt").equals("1")) {
				autocomplete1.setTypeface(Typeface.MONOSPACE);
				search.setTypeface(Typeface.MONOSPACE);
			}
			else {
				autocomplete1.setTypeface(Typeface.DEFAULT);
				search.setTypeface(Typeface.DEFAULT);
			}
			try{
				sitepermis = new Gson().fromJson(FileUtil.readFile("/storage/emulated/0/WeekBrowser/SitePermission.json"), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			}catch(Exception e){
				 
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/js.txt").equals("1")) {
				js.setChecked(true);
			}
			_setcolofuttons();
		}
	}
	
	
	@Override
	public void onPause() {
		super.onPause();
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/NoPreview.txt").equals("1") && FileUtil.readFile("/storage/emulated/0/WeekBrowser/incognito.txt").equals("1")) {
			getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
		}
		_Reopentab();
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/incognito.txt").equals("1")) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Tabs.json", "[{\"name\":\"bookmark.html\",\"url\":\"file:///storage/emulated/0/WeekBrowser/bookmark.html\"},{\"name\":\"about:blank\",\"url\":\"about:blank\"},{\"name\":\"about:blank\",\"url\":\"about:blank\"},{\"name\":\"about:blank\",\"url\":\"about:blank\"},{\"name\":\"about:blank\",\"url\":\"about:blank\"},{\"name\":\"about:blank\",\"url\":\"about:blank\"}]");
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/activeTab.txt", "0");
		}
		_clearonexit();
	}
	
	    public void onLowMemory() {
		        super.onLowMemory();
		        SketchwareUtil.showMessage(getApplicationContext(), "WeekBrowser:\nМало оперативної пам'яті. Оптимізація сайтів. Є ризик вильоту браузера");
		webview1.loadUrl(_clearram());
		webview2.loadUrl(_clearram());
		webview3.loadUrl(_clearram());
		webview4.loadUrl(_clearram());
		webview5.loadUrl(_clearram());
		webview6.loadUrl(_clearram());
		        }
	public void _extra() {
		
	}
	
	
	public void _ifex() {
		if (!FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache/ifex.txt").equals("b")) {
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache/ifex.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/cache/ifex.txt", "b");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Supermenu.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Supermenu.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt", "30");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/firstpage.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/firstpage.txt", "file:///storage/emulated/0/WeekBrowser/bookmark.html");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/autofirstpage.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/autofirstpage.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Autoclean/search.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Autoclean/search.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Autoclean/cache.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Autoclean/cache.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Autoclean/cookie.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Autoclean/cookie.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Autoclean/form.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Autoclean/form.txt", "0");
			}
			if (!FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/replaces/10.txt")) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/replaces/10.txt", "youtube.com");
			}
			if (!FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/replaces/11.txt")) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/replaces/11.txt", "ssyoutube.com");
			}
			if (!FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/replaces/20.txt")) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/replaces/20.txt", "");
			}
			if (!FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/replaces/21.txt")) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/replaces/21.txt", "");
			}
			if (!FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/replaces/30.txt")) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/replaces/30.txt", "");
			}
			if (!FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/replaces/31.txt")) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/replaces/31.txt", "");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/search.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/search.txt", "[weekbrowser]");
			}
			if (!FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/replaces/40.txt")) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/replaces/40.txt", "");
			}
			if (!FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/replaces/41.txt")) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/replaces/41.txt", "");
			}
			if (!FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/replaces/50.txt")) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/replaces/50.txt", "");
			}
			if (!FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/replaces/51.txt")) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/replaces/51.txt", "");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posx1.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posx1.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posy1.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posy1.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posx2.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posx2.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posy2.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posy2.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posx3.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posx3.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Positions/posy3.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Positions/posy3.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/fontsize.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Sizes/fontsize.txt", "10");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Searchpanelpos.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Searchpanelpos.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/LoadImages.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/LoadImages.txt", "1");
				image.setChecked(true);
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/minfont.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Sizes/minfont.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/BlockAd.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/BlockAd.txt", "1");
				blockad.setChecked(true);
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/IfameBlock.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/IfameBlock.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/HidePanels.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/HidePanels.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/SearchEngine.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SearchEngine.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/onNoInternet.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/onNoInternet.txt", "1");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/bg.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/bg.txt", "FF000000");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/InfoText.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/InfoText.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg.txt", "FF00FF00");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg.txt", "FFFF0000");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg2.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg2.txt", "FF00FF00");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg2.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg2.txt", "FFFF0000");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt", "FF00FF00");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/textfield.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/textfield.txt", "FF00FFFF");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt", "FFFF0070");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt", "FF7000FF");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt", "FF000000");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/style.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/style.txt", "5");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt", "FF000000");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/SaveNumOfHistory.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SaveNumOfHistory.txt", "1000");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/currentpc.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Useragents/currentpc.txt", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/current.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Useragents/current.txt", "");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/incognito.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/incognito.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt", "1");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/js.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/js.txt", "1");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/history.json").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/history.json", "[{\"date\":\"до нашої ери\",\"name\":\"༺ВАША ІСТОРІЯ༻\",\"url\":\"\"}]");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt", "30");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt", "1");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/bookmark.html").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/bookmark.html", "<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\">\n<body style=\"background-color:#000000\">\n<a href=\"https://www.google.com\"><font color=\"#00ff00\">Google</font></a>\n<font color=\"#ff0000\"> ❖ </font>");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/cache.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/PC.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/PC.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/1.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/1.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/2.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/2.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/3.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/3.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/1.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Bookmarklets/1.txt", "");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/2.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Bookmarklets/2.txt", "");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/3.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Bookmarklets/3.txt", "");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/4.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/4.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/5.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/5.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/6.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/6.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/4.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Bookmarklets/4.txt", "");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/5.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Bookmarklets/5.txt", "");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/6.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Bookmarklets/6.txt", "");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/10001.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/10001.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/10002.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/10002.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20001.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20001.txt", "javascript:(function() {\n    var inputs = document.getElementsByTagName('input');\n    for (var i = 0; i < inputs.length; i++) {\n        if (inputs[i].type.toLowerCase() === 'password') {\n            inputs[i].type = 'text';\n        }\n    }\n})();");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20001n.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20001n.txt", "SHOW PASSWORD");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20002.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20002.txt", "javascript:(function(){\n    for (var i = 0; i < document.styleSheets.length; i++){\n        document.styleSheets.item(i).disabled = true;\n    }\n    var all = document.getElementsByTagName('*');\n    for (var i = 0; i < all.length; i++){\n        var el = all[i];\n        el.style.cssText = '';\n        el.style.width = '';\n        el.style.padding = '0px';\n        el.style.margin = '2px';\n        el.style.backgroundImage = 'none';\n        el.style.backgroundColor = '#$colbg$';\n        el.style.color = '#$coltext$';\n        /* Змінюємо колір посилань */\n        if (el.tagName === 'A') {\n            el.style.color = '#$coladd$';\n        }\n        /* Змінюємо колір нещодавно відвіданих посилань */\n        if (el.tagName === 'A' && el.hasAttribute('visited')) {\n            el.style.color = '#$colhint$';\n        }\n        /* Змінюємо колір підказок текстового поля */\n        if (el.tagName === 'INPUT' && el.type === 'text') {\n            el.style.color = '#$colhint$';\n        }\n        /* Змінюємо колір самого тексту текстового поля */\n        if (el.tagName === 'INPUT' && el.type === 'text') {\n            el.style.backgroundColor = '#$colfield$';\n        }\n    }\n    var images = document.getElementsByTagName('img');\n    for (var i = 0; i < images.length; i++) {\n        images[i].style.width = '140px';\n        images[i].style.height = 'auto';\n    }\n})();\n");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20002n.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20002n.txt", "READING MODE");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20003.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20003.txt", "");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20003n.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20003n.txt", "");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20004.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20004.txt", "");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20004n.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20004n.txt", "");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20005.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20005.txt", "");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20005n.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Bookmarklets/20005n.txt", "");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/ZoomButton.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/ZoomButton.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Tabs.json").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Tabs.json", "[{\"name\":\"bookmark.html\",\"url\":\"file:///storage/emulated/0/WeekBrowser/bookmark.html\"},{\"name\":\"about:blank\",\"url\":\"about:blank\"},{\"name\":\"about:blank\",\"url\":\"about:blank\"},{\"name\":\"about:blank\",\"url\":\"about:blank\"},{\"name\":\"about:blank\",\"url\":\"about:blank\"},{\"name\":\"about:blank\",\"url\":\"about:blank\"}]");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/activeTab.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/NoScreen.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/NoScreen.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/NoPreview.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/NoPreview.txt", "1");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/monofortextarea.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/monofortextarea.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/SitePermission.json").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SitePermission.json", "[{\"url\":\"file:///storage/emulated/0/WeekBrowser/bookmark.html\",\"im\"=\"1\"}]");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/themepage.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/themepage.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/roundness.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/roundness.txt", "0");
			}
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Blockad/domains.txt", "unityad\ndalead\nposix\npremier1\ngtblg\nwwwhkinwa\ngoogle_vignette\nforlifecode\nbitcoin\\.site\nnowuive\nadtelligent\nwiimguup\nday\\.alerts\npush-news\ndirectrankcl\nluckyorange\nneloha\nliga-koroliv\npub\\.network\nhadron\n%adclick\n%doubleclick\nstats\\.wp\nfreshmarketer\nadsystem\n%googlead\n%advertising\n%banner\n%google_ad\n%pagead\n%googlesynd\n%googletag\n1xbet\nfavbet\nd2wy8f7a9ursnm\ncasino\npncloudfl\nvbet\nloto\ncloudfrale\noneclick\n%lyti\ncriteo\nmetric\nhotjar\n(pixel|an)\\.facebook\nadcolony\n777\nyandex\nmail\\.ru\nsentry\nbugsnag\npari\nmonoslot\nmelbet\nloot\\.bet\nloto-zoloto\\.net\nlottoland\\.com\nlegzocasinoua\\.com\nlegzo\\.casino\nleon\\.bet\nkalmar-ukr-shop\nicanshop\nhelpukr\nct.*\\.biz\ncr.*\\.biz\nwwbm\nlkcl\njsc\\.mgid\nhelp24\nepidtrymka\nbitz-play\ngo\\.redav\nw\\.news\neuropeanchallengeukraine\ndragongold88\nderjavaukraine\nclubdeluxe\\.net\ncoins\\.game\ncashalot\\.bet\nbitfinexgroup\ndopomoga\nblockchain4ukraine\nbetwinner\nbet-boom\n97jokerua\n100bankiv\n24uadopomoga\n23konkurs\n15jokerua\nimasdk\n8slottica\n7goxbet\nslotscity\nlucky-wheel\n%cummerata\n%trafficjunk\nsupergra\ngivemelink\nsteepto\nmixadvert\nservetraff\nkyivstar\\.(?!ua)\nvodafone\\.(?!ua)\nlifecell\\.(?!ua)\nmonobank\\.(?!ua)\nprivat24\\.(?!ua)\nnovapost\\.(?!com)\nukrposhta\\.(?!ua)\ndiia\\.(?!gov\\.ua)\ninstagram\\.(?!com)\nfacebook\\.(?!com)\nnovapay\\.(?!com)");
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Blockad/blockredir.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Blockad/blockredir.txt", "1");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/windows.json").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/windows.json", "[{\"e\":\"0\",\"px\":\"0\",\"py\":\"0\",\"sx\":\"2\",\"sy\":\"2\"},{\"e\":\"0\",\"px\":\"2\",\"py\":\"0\",\"sx\":\"2\",\"sy\":\"2\"},\n{\"e\":\"0\",\"px\":\"0\",\"py\":\"2\",\"sx\":\"2\",\"sy\":\"1\"},{\"e\":\"0\",\"px\":\"2\",\"py\":\"2\",\"sx\":\"2\",\"sy\":\"1\"},{\"e\":\"0\",\"px\":\"0\",\"py\":\"3\",\"sx\":\"2\",\"sy\":\"1\"},{\"e\":\"0\",\"px\":\"2\",\"py\":\"3\",\"sx\":\"2\",\"sy\":\"1\"},{\"w\":\"0\"}]");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Navpanelpos.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Navpanelpos.txt", "0");
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Swipetorefresh.txt").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Swipetorefresh.txt", "0");
			}
			_ifex2();
			if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
				
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/monet/on.txt").isEmpty()) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/monet/on.txt", "0");
				}
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/monet/bg.txt").isEmpty()) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/monet/bg.txt", "n2900");
				}
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/monet/buttonbg1.txt").isEmpty()) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/monet/buttonbg1.txt", "a1200");
				}
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/monet/buttonbg2.txt").isEmpty()) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/monet/buttonbg2.txt", "a1200");
				}
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/monet/redbuttonbg1.txt").isEmpty()) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/monet/redbuttonbg1.txt", "a3200");
				}
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/monet/redbuttonbg2.txt").isEmpty()) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/monet/redbuttonbg2.txt", "a3200");
				}
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/monet/buttontext.txt").isEmpty()) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/monet/buttontext.txt", "a1800");
				}
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/monet/redbuttontext.txt").isEmpty()) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/monet/redbuttontext.txt", "a3800");
				}
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/monet/text.txt").isEmpty()) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/monet/text.txt", "n2200");
				}
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/monet/additional.txt").isEmpty()) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/monet/additional.txt", "a3200");
				}
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/monet/hint.txt").isEmpty()) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/monet/hint.txt", "a2200");
				}
			}
		}
		else {
			
		}
		srcsug = new Gson().fromJson(FileUtil.readFile("/storage/emulated/0/WeekBrowser/search.txt"), new TypeToken<ArrayList<String>>(){}.getType());
		history = new Gson().fromJson(FileUtil.readFile("/storage/emulated/0/WeekBrowser/history.json"), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
	}
	
	
	public String _replaceInstructions(final String _javascript) {
		temp = _javascript;
		if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
			temp = temp.replace("$colbg$", "ffffff");
			temp = temp.replace("$colb1$", "33b5e5");
			temp = temp.replace("$colb2$", "33b5e5");
			temp = temp.replace("$colrb1$", "b71c1c");
			temp = temp.replace("$colrb2$", "b71c1c");
			temp = temp.replace("$coltext$", "000000");
			temp = temp.replace("$colfield$", "000000");
			temp = temp.replace("$coladd$", "33b5e5");
			temp = temp.replace("$colhint$", "757575");
			temp = temp.replace("$colbtxt$", "000000");
			temp = temp.replace("$colrbtxt2$", "000000");
		}
		else {
			if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
				temp = temp.replace("$colbg$", "111111");
				temp = temp.replace("$colb1$", "33b5e5");
				temp = temp.replace("$colb2$", "33b5e5");
				temp = temp.replace("$colrb1$", "b71c1c");
				temp = temp.replace("$colrb2$", "b71c1c");
				temp = temp.replace("$coltext$", "ffffff");
				temp = temp.replace("$colfield$", "ffffff");
				temp = temp.replace("$coladd$", "33b5e5");
				temp = temp.replace("$colhint$", "bdbdbd");
				temp = temp.replace("$colbtxt$", "000000");
				temp = temp.replace("$colrbtxt2$", "000000");
			}
			else {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
					temp = temp.replace("$colbg$", "000000");
					temp = temp.replace("$colb1$", "00ff00");
					temp = temp.replace("$colb2$", "00ff00");
					temp = temp.replace("$colrb1$", "ff0000");
					temp = temp.replace("$colrb2$", "ff0000");
					temp = temp.replace("$coltext$", "00ff00");
					temp = temp.replace("$colfield$", "ff00ffff");
					temp = temp.replace("$coladd$", "ff0070");
					temp = temp.replace("$colhint$", "7000ff");
					temp = temp.replace("$colbtxt$", "000000");
					temp = temp.replace("$colrbtxt2$", "000000");
				}
				else {
					temp = temp.replace("$colbg$", FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/bg.txt").substring(2));
					temp = temp.replace("$colb1$", FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg.txt").substring(2));
					temp = temp.replace("$colb2$", FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg2.txt").substring(2));
					temp = temp.replace("$colrb1$", FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg.txt").substring(2));
					temp = temp.replace("$colrb2$", FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg2.txt").substring(2));
					temp = temp.replace("$coltext$", FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt").substring(2));
					temp = temp.replace("$colfield$", FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/textfield.txt").substring(2));
					temp = temp.replace("$coladd$", FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt").substring(2));
					temp = temp.replace("$colhint$", FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt").substring(2));
					temp = temp.replace("$colbtxt$", FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt").substring(2));
					temp = temp.replace("$colrbtxt2$", FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt").substring(2));
				}
			}
		}
		temp = temp.replace("$$", "$");
		return (temp);
	}
	
	
	public void _hicontr() {
		textview1.setBackgroundColor(0xFF00FF00);
		linear1.setBackgroundColor(0xFF000000);
		nav.setBackgroundColor(0xFF000000);
		settingspanel.setBackgroundColor(0xFF000000);
		pc.setTextColor(0xFF00FF00);
		js.setTextColor(0xFF00FF00);
		back.setTextColor(0xFF000000);
		forward.setTextColor(0xFF000000);
		pgup.setTextColor(0xFF000000);
		pgdn.setTextColor(0xFF000000);
		home.setTextColor(0xFF000000);
		autocomplete1.setTextColor(0xFF00FFFF);
		autocomplete1.setHintTextColor(0xFF7000FF);
		refresh.setTextColor(0xFF000000);
		image.setTextColor(0xFF00FF00);
		button1.setTextColor(0xFF000000);
		openpanel.setTextColor(0xFF000000);
		bookmarks.setTextColor(0xFF000000);
		button3.setTextColor(0xFF000000);
		pagesearch.setTextColor(0xFF000000);
		textview1.setTextColor(0xFF000000);
		back.setBackgroundColor(0xFF00FF00);
		forward.setBackgroundColor(0xFF00FF00);
		pgup.setBackgroundColor(0xFF00FF00);
		pgdn.setBackgroundColor(0xFF00FF00);
		home.setBackgroundColor(0xFF00FF00);
		refresh.setBackgroundColor(0xFF00FF00);
		blockad.setTextColor(0xFF00FF00);
		bookmarks.setBackgroundColor(0xFF00FF00);
		button1.setBackgroundColor(0xFF00FF00);
		incognito.setTextColor(0xFF00FF00);
		button3.setBackgroundColor(0xFF00FF00);
		openpanel.setBackgroundColor(0xFF00FF00);
		textview2.setTextColor(0xFFFF0070);
		textview5.setTextColor(0xFFFF0070);
		textview3.setTextColor(0xFFFF0070);
		tabs.setBackgroundColor(0xFF00FF00);
		
		dual.setBackgroundColor(0xFF00FF00);
		button3.setBackgroundColor(0xFF00FF00);
		tabs.setTextColor(0xFF000000);
		
		dual.setTextColor(0xFF000000);
		histori.setBackgroundColor(0xFF00FF00);
		skipvideo.setBackgroundColor(0xFF00FF00);
		histori.setTextColor(0xFF000000);
		skipvideo.setTextColor(0xFF000000);
		searchpan.setBackgroundColor(0xFF000000);
		pagesearch.setBackgroundColor(0xFF00FF00);
		sup.setBackgroundColor(0xFF00FF00);
		sdown.setBackgroundColor(0xFF00FF00);
		search.setTextColor(0xFF00FFFF);
		search.setHintTextColor(0xFF7000FF);
		sup.setTextColor(0xFF000000);
		sdown.setTextColor(0xFF000000);
		num.setTextColor(0xFF00FF00);
		hide.setBackgroundColor(0xFF00FF00);
		hide.setTextColor(0xFF000000);
		coordinates.setBackgroundColor(0xFF00FF00);
		coordinates.setTextColor(0xFF000000);
		pos1.setBackgroundColor(0xFF00FF00);
		pos1.setTextColor(0xFF000000);
		pos2.setBackgroundColor(0xFF00FF00);
		pos2.setTextColor(0xFF000000);
		pos3.setBackgroundColor(0xFF00FF00);
		pos3.setTextColor(0xFF000000);
		
		
		
		
		
		
		
		
		
		
		
		
		
		iframe.setTextColor(0xFF00FF00);
		bml1.setBackgroundColor(0xFF00FF00);
		bml1.setTextColor(0xFF000000);
		bml2.setBackgroundColor(0xFF00FF00);
		bml2.setTextColor(0xFF000000);
		bml3.setBackgroundColor(0xFF00FF00);
		bml3.setTextColor(0xFF000000);
		bml4.setBackgroundColor(0xFF00FF00);
		bml4.setTextColor(0xFF000000);
		bml5.setBackgroundColor(0xFF00FF00);
		bml5.setTextColor(0xFF000000);
		
		
		
		title.setTextColor(0xFF00FF00);
		supermenu.setTextColor(0xFF00FF00);
		widthm1.setBackgroundColor(0xFF00FF00);
		widthm1.setTextColor(0xFF000000);
		widthp1.setBackgroundColor(0xFF00FF00);
		widthp1.setTextColor(0xFF000000);
		heightm1.setBackgroundColor(0xFF00FF00);
		heightm1.setTextColor(0xFF000000);
		heightp1.setBackgroundColor(0xFF00FF00);
		widthp1.setTextColor(0xFF000000);
		tabscontainer.setBackgroundColor(0xFF000000);
		windowsmanager.setBackgroundColor(0xFF000000);
	}
	
	
	public void _language() {
		try{
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				languag = new Gson().fromJson(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Language.welang"), new TypeToken<ArrayList<String>>(){}.getType());
			}
			try{
				autocomplete1.setHint(languag.get((int)(0)));
				
			}catch(Exception e){
				if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
					autocomplete1.setHint("Search/URL");
					
				}
				else {
					autocomplete1.setHint("Пошук/адреса");
					
				}
			}
			try{
				pc.setText(languag.get((int)(1)));
			}catch(Exception e){
				if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
					pc.setText("PC version");
				}
				else {
					pc.setText("ПК-версія");
				}
			}
			try{
				js.setText(languag.get((int)(2)));
			}catch(Exception e){
				js.setText("JS");
			}
			try{
				incognito.setText(languag.get((int)(3)));
			}catch(Exception e){
				if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
					incognito.setText("Incognito");
				}
				else {
					incognito.setText("Інкогніто");
				}
			}
			try{
				image.setText(languag.get((int)(4)));
			}catch(Exception e){
				if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
					image.setText("Load images");
				}
				else {
					image.setText("Завант. зобр.");
				}
			}
			try{
				blockad.setText(languag.get((int)(5)));
			}catch(Exception e){
				if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
					blockad.setText("Block ads");
				}
				else {
					blockad.setText("Блок. реклами");
				}
			}
			try{
				iframe.setText(languag.get((int)(6)));
			}catch(Exception e){
				if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
					iframe.setText("Block \"sites in sites\"");
				}
				else {
					iframe.setText("Блок. \"сайти у сайті\"");
				}
			}
		}catch(Exception e){
			 
		}
		try{
			textview2.setText(languag.get((int)(8)).concat(String.valueOf((long)(seekbar1.getProgress())).concat(")")));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				textview2.setText("Minimal font size (".concat(String.valueOf((long)(seekbar1.getProgress())).concat(")")));
			}
			else {
				textview2.setText("Мінімальний розмір шрифту (".concat(String.valueOf((long)(seekbar1.getProgress())).concat(")")));
			}
		}
		try{
			textview3.setText(languag.get((int)(7)).concat(String.valueOf((long)(font.getProgress() * 10)).concat("%)")));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				textview3.setText("General font size (".concat(String.valueOf((long)(font.getProgress() * 10)).concat("%)")));
			}
			else {
				textview3.setText("Загальний розмір шрифту (".concat(String.valueOf((long)(font.getProgress() * 10)).concat("%)")));
			}
		}
		try{
			textview5.setText(languag.get((int)(9)).concat(String.valueOf((long)(dp.getProgress() * 10)).concat(")")));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				textview5.setText("GUI size (".concat(String.valueOf((long)(dp.getProgress() * 10)).concat(")")));
			}
			else {
				textview5.setText("Розмір Інтерфейсу (".concat(String.valueOf((long)(dp.getProgress() * 10)).concat(")")));
			}
		}
		try{
			search.setHint(languag.get((int)(33)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				search.setHint("Search in webpage");
			}
			else {
				search.setHint("Пошук по сайту");
			}
		}
		try{
			supermenu.setText(languag.get((int)(98)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				supermenu.setText("Supermenu");
			}
			else {
				supermenu.setText("Суперменю");
			}
		}
	}
	
	
	public void _Reopentab() {
		tab = new Gson().fromJson(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Tabs.json"), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		int color1 = (int) Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg.txt"), 16);
		int color2 = (int) Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg2.txt"), 16);
		int rcolor1 = (int) Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg.txt"), 16);
		int rcolor2 = (int) Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg2.txt"), 16);
		final int roundness = Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/roundness.txt"));
		switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
			case "0": {
				if (is1window) {
					linwebview1.setVisibility(View.VISIBLE);
				}
				else {
					linwebview1.setVisibility(View.VISIBLE);
					linwebview2.setVisibility(View.GONE);
					linwebview3.setVisibility(View.GONE);
					linwebview4.setVisibility(View.GONE);
					linwebview5.setVisibility(View.GONE);
					linwebview6.setVisibility(View.GONE);
				}
				if (tab.get((int)0).get("url").toString().equals("about:blank")) {
					webview1.loadUrl(FileUtil.readFile("/storage/emulated/0/WeekBrowser/firstpage.txt"));
				}
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) < 2) {
					tab1.setBackgroundColor(0xFFB71C1C);
					tab1.setTextColor(0xFF000000);
					tab2.setBackgroundColor(0xFF33B5E5);
					tab2.setTextColor(0xFF000000);
					tab3.setBackgroundColor(0xFF33B5E5);
					tab3.setTextColor(0xFF000000);
					tab4.setBackgroundColor(0xFF33B5E5);
					tab4.setTextColor(0xFF000000);
					tab5.setBackgroundColor(0xFF33B5E5);
					tab5.setTextColor(0xFF000000);
					tab6.setBackgroundColor(0xFF33B5E5);
					tab6.setTextColor(0xFF000000);
					linwebview1.setBackgroundColor(0xFFB71C1C);
					linwebview2.setBackgroundColor(0xFF33B5E5);
					linwebview3.setBackgroundColor(0xFF33B5E5);
					linwebview4.setBackgroundColor(0xFF33B5E5);
					linwebview5.setBackgroundColor(0xFF33B5E5);
					linwebview6.setBackgroundColor(0xFF33B5E5);
				}
				else {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
						tab1.setBackgroundColor(0xFFF00000);
						tab1.setTextColor(0xFF000000);
						tab2.setBackgroundColor(0xFF00FF00);
						tab2.setTextColor(0xFF000000);
						tab3.setBackgroundColor(0xFF00FF00);
						tab3.setTextColor(0xFF000000);
						tab4.setBackgroundColor(0xFF00FF00);
						tab4.setTextColor(0xFF000000);
						tab5.setBackgroundColor(0xFF00FF00);
						tab5.setTextColor(0xFF000000);
						tab6.setBackgroundColor(0xFF00FF00);
						tab6.setTextColor(0xFF000000);
						linwebview1.setBackgroundColor(0xFFF00000);
						linwebview2.setBackgroundColor(0xFF00FF00);
						linwebview3.setBackgroundColor(0xFF00FF00);
						linwebview4.setBackgroundColor(0xFF00FF00);
						linwebview5.setBackgroundColor(0xFF00FF00);
						linwebview6.setBackgroundColor(0xFF00FF00);
					}
					else {
						tab1.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
						tab1.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab2.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab2.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab3.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab3.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab4.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab4.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab5.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab5.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab6.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab6.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						
						linwebview1.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview2.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview3.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview4.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview5.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview6.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
					}
				}
				break;
			}
			case "1": {
				linwebview2.setVisibility(View.VISIBLE);
				if (!is1window) {
					linwebview1.setVisibility(View.GONE);
					linwebview3.setVisibility(View.GONE);
					linwebview4.setVisibility(View.GONE);
					linwebview5.setVisibility(View.GONE);
					linwebview6.setVisibility(View.GONE);
				}
				if (tab.get((int)1).get("url").toString().equals("about:blank")) {
					webview2.loadUrl(FileUtil.readFile("/storage/emulated/0/WeekBrowser/firstpage.txt"));
				}
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) < 2) {
					tab1.setBackgroundColor(0xFF33B5E5);
					tab1.setTextColor(0xFF000000);
					tab2.setBackgroundColor(0xFFB71C1C);
					tab2.setTextColor(0xFF000000);
					tab3.setBackgroundColor(0xFF33B5E5);
					tab3.setTextColor(0xFF000000);
					tab4.setBackgroundColor(0xFF33B5E5);
					tab4.setTextColor(0xFF000000);
					tab5.setBackgroundColor(0xFF33B5E5);
					tab5.setTextColor(0xFF000000);
					tab6.setBackgroundColor(0xFF33B5E5);
					tab6.setTextColor(0xFF000000);
					linwebview2.setBackgroundColor(0xFFB71C1C);
					linwebview1.setBackgroundColor(0xFF33B5E5);
					linwebview3.setBackgroundColor(0xFF33B5E5);
					linwebview4.setBackgroundColor(0xFF33B5E5);
					linwebview5.setBackgroundColor(0xFF33B5E5);
					linwebview6.setBackgroundColor(0xFF33B5E5);
				}
				else {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
						tab1.setBackgroundColor(0xFF00FF00);
						tab1.setTextColor(0xFF000000);
						tab2.setBackgroundColor(0xFFF00000);
						tab2.setTextColor(0xFF000000);
						tab3.setBackgroundColor(0xFF00FF00);
						tab3.setTextColor(0xFF000000);
						tab4.setBackgroundColor(0xFF00FF00);
						tab4.setTextColor(0xFF000000);
						tab5.setBackgroundColor(0xFF00FF00);
						tab5.setTextColor(0xFF000000);
						tab6.setBackgroundColor(0xFF00FF00);
						tab6.setTextColor(0xFF000000);
						linwebview1.setBackgroundColor(0xFFF00000);
						linwebview2.setBackgroundColor(0xFF00FF00);
						linwebview3.setBackgroundColor(0xFF00FF00);
						linwebview4.setBackgroundColor(0xFF00FF00);
						linwebview5.setBackgroundColor(0xFF00FF00);
						linwebview6.setBackgroundColor(0xFF00FF00);
					}
					else {
						tab2.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
						tab2.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab1.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab1.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab3.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab3.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab4.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab4.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab5.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab5.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab6.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab6.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						
						linwebview2.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview1.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview3.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview4.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview5.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview6.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
					}
				}
				break;
			}
			case "2": {
				if (!is1window) {
					linwebview1.setVisibility(View.GONE);
					linwebview2.setVisibility(View.GONE);
					linwebview4.setVisibility(View.GONE);
					linwebview5.setVisibility(View.GONE);
					linwebview6.setVisibility(View.GONE);
				}
				linwebview3.setVisibility(View.VISIBLE);
				if (tab.get((int)2).get("url").toString().equals("about:blank")) {
					webview3.loadUrl(FileUtil.readFile("/storage/emulated/0/WeekBrowser/firstpage.txt"));
				}
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) < 2) {
					tab1.setBackgroundColor(0xFF33B5E5);
					tab1.setTextColor(0xFF000000);
					tab2.setBackgroundColor(0xFF33B5E5);
					tab2.setTextColor(0xFF000000);
					tab3.setBackgroundColor(0xFFB71C1C);
					tab3.setTextColor(0xFF000000);
					tab4.setBackgroundColor(0xFF33B5E5);
					tab4.setTextColor(0xFF000000);
					tab5.setBackgroundColor(0xFF33B5E5);
					tab5.setTextColor(0xFF000000);
					tab6.setBackgroundColor(0xFF33B5E5);
					tab6.setTextColor(0xFF000000);
					linwebview3.setBackgroundColor(0xFFB71C1C);
					linwebview2.setBackgroundColor(0xFF33B5E5);
					linwebview1.setBackgroundColor(0xFF33B5E5);
					linwebview4.setBackgroundColor(0xFF33B5E5);
					linwebview5.setBackgroundColor(0xFF33B5E5);
					linwebview6.setBackgroundColor(0xFF33B5E5);
				}
				else {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
						tab1.setBackgroundColor(0xFF00FF00);
						tab1.setTextColor(0xFF000000);
						tab2.setBackgroundColor(0xFF00FF00);
						tab2.setTextColor(0xFF000000);
						tab3.setBackgroundColor(0xFFF00000);
						tab3.setTextColor(0xFF000000);
						tab4.setBackgroundColor(0xFF00FF00);
						tab4.setTextColor(0xFF000000);
						tab5.setBackgroundColor(0xFF00FF00);
						tab5.setTextColor(0xFF000000);
						tab6.setBackgroundColor(0xFF00FF00);
						tab6.setTextColor(0xFF000000);
						linwebview3.setBackgroundColor(0xFFF00000);
						linwebview2.setBackgroundColor(0xFF00FF00);
						linwebview1.setBackgroundColor(0xFF00FF00);
						linwebview4.setBackgroundColor(0xFF00FF00);
						linwebview5.setBackgroundColor(0xFF00FF00);
						linwebview6.setBackgroundColor(0xFF00FF00);
					}
					else {
						tab3.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
						tab3.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab1.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab1.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab2.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab2.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab4.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab4.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab5.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab5.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab6.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab6.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						
						linwebview3.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview2.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview1.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview4.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview5.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview6.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
					}
				}
				break;
			}
			case "3": {
				if (!is1window) {
					linwebview1.setVisibility(View.GONE);
					linwebview2.setVisibility(View.GONE);
					linwebview3.setVisibility(View.GONE);
					linwebview6.setVisibility(View.GONE);
					linwebview5.setVisibility(View.GONE);
				}
				linwebview4.setVisibility(View.VISIBLE);
				if (tab.get((int)3).get("url").toString().equals("about:blank")) {
					webview4.loadUrl(FileUtil.readFile("/storage/emulated/0/WeekBrowser/firstpage.txt"));
				}
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) < 2) {
					tab1.setBackgroundColor(0xFF33B5E5);
					tab1.setTextColor(0xFF000000);
					tab2.setBackgroundColor(0xFF33B5E5);
					tab2.setTextColor(0xFF000000);
					tab3.setBackgroundColor(0xFF33B5E5);
					tab3.setTextColor(0xFF000000);
					tab4.setBackgroundColor(0xFFB71C1C);
					tab4.setTextColor(0xFF000000);
					tab5.setBackgroundColor(0xFF33B5E5);
					tab5.setTextColor(0xFF000000);
					tab6.setBackgroundColor(0xFF33B5E5);
					tab6.setTextColor(0xFF000000);
					linwebview4.setBackgroundColor(0xFFB71C1C);
					linwebview2.setBackgroundColor(0xFF33B5E5);
					linwebview3.setBackgroundColor(0xFF33B5E5);
					linwebview1.setBackgroundColor(0xFF33B5E5);
					linwebview5.setBackgroundColor(0xFF33B5E5);
					linwebview6.setBackgroundColor(0xFF33B5E5);
				}
				else {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
						tab1.setBackgroundColor(0xFF00FF00);
						tab1.setTextColor(0xFF000000);
						tab2.setBackgroundColor(0xFF00FF00);
						tab2.setTextColor(0xFF000000);
						tab3.setBackgroundColor(0xFF00FF00);
						tab3.setTextColor(0xFF000000);
						tab4.setBackgroundColor(0xFFF00000);
						tab4.setTextColor(0xFF000000);
						tab5.setBackgroundColor(0xFF00FF00);
						tab5.setTextColor(0xFF000000);
						tab6.setBackgroundColor(0xFF00FF00);
						tab6.setTextColor(0xFF000000);
						linwebview4.setBackgroundColor(0xFFF00000);
						linwebview2.setBackgroundColor(0xFF00FF00);
						linwebview3.setBackgroundColor(0xFF00FF00);
						linwebview1.setBackgroundColor(0xFF00FF00);
						linwebview5.setBackgroundColor(0xFF00FF00);
						linwebview6.setBackgroundColor(0xFF00FF00);
					}
					else {
						tab4.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
						tab4.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab1.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab1.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab2.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab2.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab3.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab3.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab5.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab5.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab6.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab6.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						
						linwebview4.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview2.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview3.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview1.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview5.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview6.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
					}
				}
				break;
			}
			case "4": {
				if (!is1window) {
					linwebview1.setVisibility(View.GONE);
					linwebview2.setVisibility(View.GONE);
					linwebview3.setVisibility(View.GONE);
					linwebview4.setVisibility(View.GONE);
					linwebview6.setVisibility(View.GONE);
				}
				linwebview5.setVisibility(View.VISIBLE);
				if (tab.get((int)4).get("url").toString().equals("about:blank")) {
					webview5.loadUrl(FileUtil.readFile("/storage/emulated/0/WeekBrowser/firstpage.txt"));
				}
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) < 2) {
					tab1.setBackgroundColor(0xFF33B5E5);
					tab1.setTextColor(0xFF000000);
					tab2.setBackgroundColor(0xFF33B5E5);
					tab2.setTextColor(0xFF000000);
					tab3.setBackgroundColor(0xFF33B5E5);
					tab3.setTextColor(0xFF000000);
					tab4.setBackgroundColor(0xFF33B5E5);
					tab4.setTextColor(0xFF000000);
					tab5.setBackgroundColor(0xFFB71C1C);
					tab5.setTextColor(0xFF000000);
					tab6.setBackgroundColor(0xFF33B5E5);
					tab6.setTextColor(0xFF000000);
					linwebview5.setBackgroundColor(0xFFB71C1C);
					linwebview2.setBackgroundColor(0xFF33B5E5);
					linwebview3.setBackgroundColor(0xFF33B5E5);
					linwebview4.setBackgroundColor(0xFF33B5E5);
					linwebview1.setBackgroundColor(0xFF33B5E5);
					linwebview6.setBackgroundColor(0xFF33B5E5);
				}
				else {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
						tab1.setBackgroundColor(0xFF00FF00);
						tab1.setTextColor(0xFF000000);
						tab2.setBackgroundColor(0xFF00FF00);
						tab2.setTextColor(0xFF000000);
						tab3.setBackgroundColor(0xFF00FF00);
						tab3.setTextColor(0xFF000000);
						tab4.setBackgroundColor(0xFF00FF00);
						tab4.setTextColor(0xFF000000);
						tab5.setBackgroundColor(0xFFF00000);
						tab5.setTextColor(0xFF000000);
						tab6.setBackgroundColor(0xFF00FF00);
						tab6.setTextColor(0xFF000000);
						linwebview5.setBackgroundColor(0xFFF00000);
						linwebview2.setBackgroundColor(0xFF00FF00);
						linwebview3.setBackgroundColor(0xFF00FF00);
						linwebview4.setBackgroundColor(0xFF00FF00);
						linwebview1.setBackgroundColor(0xFF00FF00);
						linwebview6.setBackgroundColor(0xFF00FF00);
					}
					else {
						tab5.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
						tab5.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab1.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab1.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab2.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab2.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab3.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab3.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab4.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab4.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab6.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab6.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						
						linwebview5.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview2.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview3.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview4.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview1.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview6.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
					}
				}
				break;
			}
			case "5": {
				if (!is1window) {
					linwebview1.setVisibility(View.GONE);
					linwebview2.setVisibility(View.GONE);
					linwebview3.setVisibility(View.GONE);
					linwebview4.setVisibility(View.GONE);
					linwebview5.setVisibility(View.GONE);
				}
				linwebview6.setVisibility(View.VISIBLE);
				if (tab.get((int)5).get("url").toString().equals("about:blank")) {
					webview6.loadUrl(FileUtil.readFile("/storage/emulated/0/WeekBrowser/firstpage.txt"));
				}
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) < 2) {
					tab1.setBackgroundColor(0xFF33B5E5);
					tab1.setTextColor(0xFF000000);
					tab2.setBackgroundColor(0xFF33B5E5);
					tab2.setTextColor(0xFF000000);
					tab3.setBackgroundColor(0xFF33B5E5);
					tab3.setTextColor(0xFF000000);
					tab4.setBackgroundColor(0xFF33B5E5);
					tab4.setTextColor(0xFF000000);
					tab5.setBackgroundColor(0xFF33B5E5);
					tab5.setTextColor(0xFF000000);
					tab6.setBackgroundColor(0xFFB71C1C);
					tab6.setTextColor(0xFF000000);
					linwebview6.setBackgroundColor(0xFFB71C1C);
					linwebview2.setBackgroundColor(0xFF33B5E5);
					linwebview3.setBackgroundColor(0xFF33B5E5);
					linwebview4.setBackgroundColor(0xFF33B5E5);
					linwebview5.setBackgroundColor(0xFF33B5E5);
					linwebview1.setBackgroundColor(0xFF33B5E5);
				}
				else {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
						tab1.setBackgroundColor(0xFF00FF00);
						tab1.setTextColor(0xFF000000);
						tab2.setBackgroundColor(0xFF00FF00);
						tab2.setTextColor(0xFF000000);
						tab3.setBackgroundColor(0xFF00FF00);
						tab3.setTextColor(0xFF000000);
						tab4.setBackgroundColor(0xFF00FF00);
						tab4.setTextColor(0xFF000000);
						tab5.setBackgroundColor(0xFF00FF00);
						tab5.setTextColor(0xFF000000);
						tab6.setBackgroundColor(0xFFF00000);
						tab6.setTextColor(0xFF000000);
						linwebview6.setBackgroundColor(0xFFF00000);
						linwebview2.setBackgroundColor(0xFF00FF00);
						linwebview3.setBackgroundColor(0xFF00FF00);
						linwebview4.setBackgroundColor(0xFF00FF00);
						linwebview5.setBackgroundColor(0xFF00FF00);
						linwebview1.setBackgroundColor(0xFF00FF00);
					}
					else {
						tab6.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
						tab6.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab1.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab1.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab2.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab2.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab3.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab3.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab4.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab4.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						tab5.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						tab5.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						
						linwebview6.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview2.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview3.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview4.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview5.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
						linwebview1.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
								    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
							}});
					}
				}
				break;
			}
		}
		try{
			if (!_isNull(webview1.getUrl()) && !webview1.getUrl().isEmpty()) {
				tab.get((int)0).put("name", webview1.getTitle());
				tab.get((int)0).put("url", webview1.getUrl());
			}
		}catch(Exception e){
			 
		}
		try{
			if (!_isNull(webview2.getUrl()) && !webview2.getUrl().isEmpty()) {
				tab.get((int)1).put("name", webview2.getTitle());
				tab.get((int)1).put("url", webview2.getUrl());
			}
		}catch(Exception e){
			 
		}
		try{
			if (!_isNull(webview3.getUrl()) && !webview3.getUrl().isEmpty()) {
				tab.get((int)2).put("name", webview3.getTitle());
				tab.get((int)2).put("url", webview3.getUrl());
			}
		}catch(Exception e){
			 
		}
		try{
			if (!_isNull(webview4.getUrl()) && !webview4.getUrl().isEmpty()) {
				tab.get((int)3).put("name", webview4.getTitle());
				tab.get((int)3).put("url", webview4.getUrl());
			}
		}catch(Exception e){
			 
		}
		try{
			if (!_isNull(webview5.getUrl()) && !webview5.getUrl().isEmpty()) {
				tab.get((int)4).put("name", webview5.getTitle());
				tab.get((int)4).put("url", webview5.getUrl());
			}
		}catch(Exception e){
			 
		}
		try{
			if (!_isNull(webview6.getUrl()) && !webview6.getUrl().isEmpty()) {
				tab.get((int)5).put("name", webview6.getTitle());
				tab.get((int)5).put("url", webview6.getUrl());
			}
		}catch(Exception e){
			 
		}
		if (!FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/TabsIntent")) {
			if (tab.get((int)0).get("url").toString().equals("about:blank")) {
				tab1.setText("+");
				linwebview1.setVisibility(View.GONE);
			}
			else {
				tab1.setText(tab.get((int)0).get("name").toString());
			}
			if (tab.get((int)1).get("url").toString().equals("about:blank")) {
				tab2.setText("+");
				linwebview2.setVisibility(View.GONE);
			}
			else {
				tab2.setText(tab.get((int)1).get("name").toString());
			}
			if (tab.get((int)2).get("url").toString().equals("about:blank")) {
				tab3.setText("+");
				linwebview3.setVisibility(View.GONE);
			}
			else {
				tab3.setText(tab.get((int)2).get("name").toString());
			}
			if (tab.get((int)3).get("url").toString().equals("about:blank")) {
				tab4.setText("+");
				linwebview4.setVisibility(View.GONE);
			}
			else {
				tab4.setText(tab.get((int)3).get("name").toString());
			}
			if (tab.get((int)4).get("url").toString().equals("about:blank")) {
				tab5.setText("+");
				linwebview5.setVisibility(View.GONE);
			}
			else {
				tab5.setText(tab.get((int)4).get("name").toString());
			}
			if (tab.get((int)5).get("url").toString().equals("about:blank")) {
				tab6.setText("+");
				linwebview6.setVisibility(View.GONE);
			}
			else {
				tab6.setText(tab.get((int)5).get("name").toString());
			}
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Tabs.json", new Gson().toJson(tab));
		}
		else {
			webview1.loadUrl(tab.get((int)0).get("url").toString());
			webview2.loadUrl(tab.get((int)1).get("url").toString());
			webview3.loadUrl(tab.get((int)2).get("url").toString());
			webview4.loadUrl(tab.get((int)3).get("url").toString());
			webview5.loadUrl(tab.get((int)4).get("url").toString());
			webview6.loadUrl(tab.get((int)5).get("url").toString());
		}
		FileUtil.deleteFile("/storage/emulated/0/WeekBrowser/intent.txt");
		FileUtil.deleteFile("/storage/emulated/0/WeekBrowser/TabsIntent");
		_swipeset();
	}
	
	
	public void _loading() {
		if (isnotchfullscreen) {
			textview1.setPadding(0, NotchUtils.getNotchHeightDp(this), 0, 0);
		}
		else {
			textview1.setPadding(0, 0, 0, 0);
		}
		if (isshowed && !swipetorefresh) {
			info = info.concat("[▽▼🔄🔄🔄▼▽]\n");
		}
		if (swipetorefresh) {
			info = info.concat("[✅✅✅🔄🔄🔄✅✅✅]\n");
		}
		switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
			case "0": {
				if (webview1.getProgress() < 100) {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) < 2) {
						try{
							info = languag.get((int)(65));
						}catch(Exception e){
							if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
								info = "Loading ";
							}
							else {
								info = "Завантаження ";
							}
						}
					}
					if ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) == 0) || (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) == 2)) {
						for(int _repeat32 = 0; _repeat32 < (int)(webview1.getProgress()); _repeat32++) {
							info = info.concat("/");
						}
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) == 4) {
							for(int _repeat41 = 0; _repeat41 < (int)((webview1.getProgress() / 2)); _repeat41++) {
								info = info.concat("/");
							}
							info = info.concat(String.valueOf((long)(webview1.getProgress())).concat("%"));
							for(int _repeat53 = 0; _repeat53 < (int)((webview1.getProgress() / 2)); _repeat53++) {
								info = info.concat("/");
							}
						}
						else {
							info = info.concat(String.valueOf((long)(webview1.getProgress())).concat("%"));
						}
					}
					refresh.setText("✖");
				}
				else {
					refresh.setText("");
				}
				if (Internet) {
					info = info.concat(" (Немає інтернет-з'єднання)");
				}
				if (info.trim().equals("")) {
					textview1.setVisibility(View.GONE);
				}
				else {
					textview1.setVisibility(View.VISIBLE);
				}
				textview1.setText(info);
				info = "";
				break;
			}
			case "1": {
				if (webview2.getProgress() < 100) {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) < 2) {
						try{
							info = languag.get((int)(65));
						}catch(Exception e){
							if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
								info = "Loading ";
							}
							else {
								info = "Завантаження ";
							}
						}
					}
					if ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) == 0) || (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) == 2)) {
						for(int _repeat145 = 0; _repeat145 < (int)(webview2.getProgress()); _repeat145++) {
							info = info.concat("/");
						}
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) == 4) {
							for(int _repeat154 = 0; _repeat154 < (int)((webview2.getProgress() / 2)); _repeat154++) {
								info = info.concat("/");
							}
							info = info.concat(String.valueOf((long)(webview2.getProgress())).concat("%"));
							for(int _repeat166 = 0; _repeat166 < (int)((webview2.getProgress() / 2)); _repeat166++) {
								info = info.concat("/");
							}
						}
						else {
							info = info.concat(String.valueOf((long)(webview2.getProgress())).concat("%"));
						}
					}
					refresh.setText("✖");
				}
				else {
					refresh.setText("");
				}
				if (Internet) {
					info = info.concat(" (Немає інтернет-з'єднання)");
				}
				if (info.trim().equals("")) {
					textview1.setVisibility(View.GONE);
				}
				else {
					textview1.setVisibility(View.VISIBLE);
				}
				textview1.setText(info);
				info = "";
				break;
			}
			case "2": {
				if (webview3.getProgress() < 100) {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) < 2) {
						try{
							info = languag.get((int)(65));
						}catch(Exception e){
							if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
								info = "Loading ";
							}
							else {
								info = "Завантаження ";
							}
						}
					}
					if ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) == 0) || (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) == 2)) {
						for(int _repeat217 = 0; _repeat217 < (int)(webview3.getProgress()); _repeat217++) {
							info = info.concat("/");
						}
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) == 4) {
							for(int _repeat226 = 0; _repeat226 < (int)((webview3.getProgress() / 2)); _repeat226++) {
								info = info.concat("/");
							}
							info = info.concat(String.valueOf((long)(webview3.getProgress())).concat("%"));
							for(int _repeat238 = 0; _repeat238 < (int)((webview3.getProgress() / 2)); _repeat238++) {
								info = info.concat("/");
							}
						}
						else {
							info = info.concat(String.valueOf((long)(webview3.getProgress())).concat("%"));
						}
					}
					refresh.setText("✖");
				}
				else {
					refresh.setText("");
				}
				if (Internet) {
					info = info.concat(" (Немає інтернет-з'єднання)");
				}
				if (info.trim().equals("")) {
					textview1.setVisibility(View.GONE);
				}
				else {
					textview1.setVisibility(View.VISIBLE);
				}
				textview1.setText(info);
				info = "";
				break;
			}
			case "3": {
				if (webview4.getProgress() < 100) {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) < 2) {
						try{
							info = languag.get((int)(65));
						}catch(Exception e){
							if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
								info = "Loading ";
							}
							else {
								info = "Завантаження ";
							}
						}
					}
					if ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) == 0) || (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) == 2)) {
						for(int _repeat289 = 0; _repeat289 < (int)(webview4.getProgress()); _repeat289++) {
							info = info.concat("/");
						}
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) == 4) {
							for(int _repeat298 = 0; _repeat298 < (int)((webview4.getProgress() / 2)); _repeat298++) {
								info = info.concat("/");
							}
							info = info.concat(String.valueOf((long)(webview4.getProgress())).concat("%"));
							for(int _repeat310 = 0; _repeat310 < (int)((webview4.getProgress() / 2)); _repeat310++) {
								info = info.concat("/");
							}
						}
						else {
							info = info.concat(String.valueOf((long)(webview4.getProgress())).concat("%"));
						}
					}
					refresh.setText("✖");
				}
				else {
					refresh.setText("");
				}
				if (Internet) {
					info = info.concat(" (Немає інтернет-з'єднання)");
				}
				if (info.trim().equals("")) {
					textview1.setVisibility(View.GONE);
				}
				else {
					textview1.setVisibility(View.VISIBLE);
				}
				textview1.setText(info);
				info = "";
				break;
			}
			case "4": {
				if (webview5.getProgress() < 100) {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) < 2) {
						try{
							info = languag.get((int)(65));
						}catch(Exception e){
							if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
								info = "Loading ";
							}
							else {
								info = "Завантаження ";
							}
						}
					}
					if ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) == 0) || (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) == 2)) {
						for(int _repeat361 = 0; _repeat361 < (int)(webview5.getProgress()); _repeat361++) {
							info = info.concat("/");
						}
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) == 4) {
							for(int _repeat370 = 0; _repeat370 < (int)((webview5.getProgress() / 2)); _repeat370++) {
								info = info.concat("/");
							}
							info = info.concat(String.valueOf((long)(webview5.getProgress())).concat("%"));
							for(int _repeat382 = 0; _repeat382 < (int)((webview5.getProgress() / 2)); _repeat382++) {
								info = info.concat("/");
							}
						}
						else {
							info = info.concat(String.valueOf((long)(webview5.getProgress())).concat("%"));
						}
					}
					refresh.setText("✖");
				}
				else {
					refresh.setText("");
				}
				if (Internet) {
					info = info.concat(" (Немає інтернет-з'єднання)");
				}
				if (info.trim().equals("")) {
					textview1.setVisibility(View.GONE);
				}
				else {
					textview1.setVisibility(View.VISIBLE);
				}
				textview1.setText(info);
				info = "";
				break;
			}
			case "5": {
				if (webview6.getProgress() < 100) {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) < 2) {
						try{
							info = languag.get((int)(65));
						}catch(Exception e){
							if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
								info = "Loading ";
							}
							else {
								info = "Завантаження ";
							}
						}
					}
					if ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) == 0) || (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) == 2)) {
						for(int _repeat433 = 0; _repeat433 < (int)(webview6.getProgress()); _repeat433++) {
							info = info.concat("/");
						}
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) == 4) {
							for(int _repeat442 = 0; _repeat442 < (int)((webview6.getProgress() / 2)); _repeat442++) {
								info = info.concat("/");
							}
							info = info.concat(String.valueOf((long)(webview6.getProgress())).concat("%"));
							for(int _repeat454 = 0; _repeat454 < (int)((webview6.getProgress() / 2)); _repeat454++) {
								info = info.concat("/");
							}
						}
						else {
							info = info.concat(String.valueOf((long)(webview6.getProgress())).concat("%"));
						}
					}
					refresh.setText("✖");
				}
				else {
					refresh.setText("");
				}
				if (Internet) {
					info = info.concat(" (Немає інтернет-з'єднання)");
				}
				if (info.trim().equals("")) {
					textview1.setVisibility(View.GONE);
				}
				else {
					textview1.setVisibility(View.VISIBLE);
				}
				textview1.setText(info);
				info = "";
				break;
			}
		}
	}
	
	
	public boolean _isNull(final String _v) {
		if(_v==null)return true; else return false;
	}
	
	
	public void _newintentt() {
		if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/idtxt")) {
			switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
				case "0": {
					webview1.loadUrl("javascript:(function() {" +
					    "var textField = document.getElementById('" + FileUtil.readFile("/storage/emulated/0/WeekBrowser/idtxt") + "');" +
					    "if(textField) {" +
					    "textField.value = '" + FileUtil.readFile("/storage/emulated/0/WeekBrowser/txt") + "';" +
					    "}" +
					"})();");
					
					break;
				}
				case "1": {
					webview2.loadUrl("javascript:(function() {" +
					    "var textField = document.getElementById('" + FileUtil.readFile("/storage/emulated/0/WeekBrowser/idtxt") + "');" +
					    "if(textField) {" +
					    "textField.value = '" + FileUtil.readFile("/storage/emulated/0/WeekBrowser/txt") + "';" +
					    "}" +
					"})();");
					
					break;
				}
				case "2": {
					webview3.loadUrl("javascript:(function() {" +
					    "var textField = document.getElementById('" + FileUtil.readFile("/storage/emulated/0/WeekBrowser/idtxt") + "');" +
					    "if(textField) {" +
					    "textField.value = '" + FileUtil.readFile("/storage/emulated/0/WeekBrowser/txt") + "';" +
					    "}" +
					"})();");
					
					break;
				}
				case "3": {
					webview4.loadUrl("javascript:(function() {" +
					    "var textField = document.getElementById('" + FileUtil.readFile("/storage/emulated/0/WeekBrowser/idtxt") + "');" +
					    "if(textField) {" +
					    "textField.value = '" + FileUtil.readFile("/storage/emulated/0/WeekBrowser/txt") + "';" +
					    "}" +
					"})();");
					
					break;
				}
				case "4": {
					webview5.loadUrl("javascript:(function() {" +
					    "var textField = document.getElementById('" + FileUtil.readFile("/storage/emulated/0/WeekBrowser/idtxt") + "');" +
					    "if(textField) {" +
					    "textField.value = '" + FileUtil.readFile("/storage/emulated/0/WeekBrowser/txt") + "';" +
					    "}" +
					"})();");
					
					break;
				}
				case "5": {
					webview6.loadUrl("javascript:(function() {" +
					    "var textField = document.getElementById('" + FileUtil.readFile("/storage/emulated/0/WeekBrowser/idtxt") + "');" +
					    "if(textField) {" +
					    "textField.value = '" + FileUtil.readFile("/storage/emulated/0/WeekBrowser/txt") + "';" +
					    "}" +
					"})();");
					
					break;
				}
			}
			FileUtil.deleteFile("/storage/emulated/0/WeekBrowser/idtxt");
			FileUtil.deleteFile("/storage/emulated/0/WeekBrowser/txt");
		}
	}
	
	
	public void _titl() {
		switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
			case "0": {
				title.setText(webview1.getTitle());
				break;
			}
			case "1": {
				title.setText(webview2.getTitle());
				break;
			}
			case "2": {
				title.setText(webview3.getTitle());
				break;
			}
			case "3": {
				title.setText(webview4.getTitle());
				break;
			}
			case "4": {
				title.setText(webview5.getTitle());
				break;
			}
			case "5": {
				title.setText(webview6.getTitle());
				break;
			}
		}
	}
	
	
	public boolean _ispermission() {
		if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
			return (false);
		}
		else {
			if (Build.VERSION.SDK_INT >= 23) {
							if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_DENIED) {
									return (true);
							}
							else {
					return (false);
							}
					}
					else {
				return (false);
					}
		}
	}
	
	
	public void _settabswindow() {
		width1 = 2;
		height1 = 2;
		width2 = 2;
		height2 = 2;
		width3 = 2;
		height3 = 2;
		width4 = 2;
		height4 = 2;
		width5 = 2;
		height5 = 2;
		width6 = 2;
		height6 = 2;
		windowsmanager.setVisibility(View.GONE);
		if (!is1window) {
			_setTopPadding(linwebview1, 0);
			linwebview1.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
			linwebview1.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
			((LinearLayout.LayoutParams) linwebview1.getLayoutParams()).weight = 1; // або будь-яке інше значення, яке вам потрібно
			linwebview1.setX(0);
			linwebview1.setY(0);
			linwebview1.requestLayout();
			_setTopPadding(linwebview2, 0);
			linwebview2.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
			linwebview2.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
			((LinearLayout.LayoutParams) linwebview2.getLayoutParams()).weight = 1; // або будь-яке інше значення, яке вам потрібно
			linwebview2.setX(0);
			linwebview2.setY(0);
			linwebview2.requestLayout();
			_setTopPadding(linwebview3, 0);
			linwebview3.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
			linwebview3.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
			((LinearLayout.LayoutParams) linwebview3.getLayoutParams()).weight = 1; // або будь-яке інше значення, яке вам потрібно
			linwebview3.setX(0);
			linwebview3.setY(0);
			linwebview3.requestLayout();
			_setTopPadding(linwebview4, 0);
			linwebview4.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
			linwebview4.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
			((LinearLayout.LayoutParams) linwebview4.getLayoutParams()).weight = 1; // або будь-яке інше значення, яке вам потрібно
			linwebview4.setX(0);
			linwebview4.setY(0);
			linwebview4.requestLayout();
			_setTopPadding(linwebview5, 0);
			linwebview5.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
			linwebview5.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
			((LinearLayout.LayoutParams) linwebview5.getLayoutParams()).weight = 1; // або будь-яке інше значення, яке вам потрібно
			linwebview5.setX(0);
			linwebview5.setY(0);
			linwebview5.requestLayout();
			_setTopPadding(linwebview6, 0);
			linwebview6.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
			linwebview6.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
			((LinearLayout.LayoutParams) linwebview6.getLayoutParams()).weight = 1; // або будь-яке інше значення, яке вам потрібно
			linwebview6.setX(0);
			linwebview6.setY(0);
			linwebview6.requestLayout();
		}
		timer = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						if (is1window) {
							try{
								
								linwebview6.getLayoutParams().width = (int)(width6*(tabscontainer.getWidth()/4));
								linwebview6.requestLayout();
								linwebview5.getLayoutParams().width = (int)(width5*(tabscontainer.getWidth()/4));
								linwebview5.requestLayout();
								linwebview4.getLayoutParams().width = (int)(width4*(tabscontainer.getWidth()/4));
								linwebview4.requestLayout();
								linwebview3.getLayoutParams().width = (int)(width3*(tabscontainer.getWidth()/4));
								linwebview3.requestLayout();
								linwebview2.getLayoutParams().width = (int)(width2*(tabscontainer.getWidth()/4));
								linwebview2.requestLayout();
								linwebview1.getLayoutParams().width = (int)(width1*(tabscontainer.getWidth()/4));
								linwebview1.requestLayout();
								linwebview1.getLayoutParams().height = (int)(height1*(tabscontainer.getHeight()/4));
								linwebview1.requestLayout();
								linwebview2.getLayoutParams().height = (int)(height2*(tabscontainer.getHeight()/4));
								linwebview2.requestLayout();
								linwebview3.getLayoutParams().height = (int)(height3*(tabscontainer.getHeight()/4));
								linwebview3.requestLayout();
								linwebview4.getLayoutParams().height = (int)(height4*(tabscontainer.getHeight()/4));
								linwebview4.requestLayout();
								linwebview5.getLayoutParams().height = (int)(height5*(tabscontainer.getHeight()/4));
								linwebview5.requestLayout();
								linwebview6.getLayoutParams().height = (int)(height6*(tabscontainer.getHeight()/4));
								linwebview6.requestLayout();
								if ((is1touch || is2touch) || (is3touch || (is4touch || (is5touch || is6touch)))) {
									th1 = ((int)linwebview1.getY() / (int)(tabscontainer.getHeight() / 4));
									th2 = ((int)linwebview2.getY() / (int)(tabscontainer.getHeight() / 4));
									th3 = ((int)linwebview3.getY() / (int)(tabscontainer.getHeight() / 4));
									th4 = ((int)linwebview4.getY() / (int)(tabscontainer.getHeight() / 4));
									th5 = ((int)linwebview5.getY() / (int)(tabscontainer.getHeight() / 4));
									th6 = ((int)linwebview6.getY() / (int)(tabscontainer.getHeight() / 4));
									ti1 = ((int)linwebview1.getX() / (int)(tabscontainer.getWidth() / 4));
									ti2 = ((int)linwebview2.getX() / (int)(tabscontainer.getWidth() / 4));
									ti3 = ((int)linwebview3.getX() / (int)(tabscontainer.getWidth() / 4));
									ti4 = ((int)linwebview4.getX() / (int)(tabscontainer.getWidth() / 4));
									ti5 = ((int)linwebview5.getX() / (int)(tabscontainer.getWidth() / 4));
									ti6 = ((int)linwebview6.getX() / (int)(tabscontainer.getWidth() / 4));
								}
								else {
									linwebview1.setY((int)th1 * (int)(tabscontainer.getHeight() / 4));
									linwebview2.setY((int)th2 * (int)(tabscontainer.getHeight() / 4));
									linwebview3.setY((int)th3 * (int)(tabscontainer.getHeight() / 4));
									linwebview4.setY((int)th4 * (int)(tabscontainer.getHeight() / 4));
									linwebview5.setY((int)th5 * (int)(tabscontainer.getHeight() / 4));
									linwebview6.setY((int)th6 * (int)(tabscontainer.getHeight() / 4));
									linwebview1.setX((int)ti1 * (int)(tabscontainer.getWidth() / 4));
									linwebview2.setX((int)ti2 * (int)(tabscontainer.getWidth() / 4));
									linwebview3.setX((int)ti3 * (int)(tabscontainer.getWidth() / 4));
									linwebview4.setX((int)ti4 * (int)(tabscontainer.getWidth() / 4));
									linwebview5.setX((int)ti5 * (int)(tabscontainer.getWidth() / 4));
									linwebview6.setX((int)ti6 * (int)(tabscontainer.getWidth() / 4));
									linwebview1.setX(((int)linwebview1.getX() / (int)(tabscontainer.getWidth() / 4)) * (int)(tabscontainer.getWidth() / 4));
									linwebview1.setY( ((int)linwebview1.getY() / (int)(tabscontainer.getHeight() / 4)) * (int)(tabscontainer.getHeight() / 4));
									linwebview2.setX(((int)linwebview2.getX() / (int)(tabscontainer.getWidth() / 4)) * (int)(tabscontainer.getWidth() / 4));
									linwebview2.setY( ((int)linwebview2.getY() / (int)(tabscontainer.getHeight() / 4)) * (int)(tabscontainer.getHeight() / 4));
									linwebview3.setX(((int)linwebview3.getX() / (int)(tabscontainer.getWidth() / 4)) * (int)(tabscontainer.getWidth() / 4));
									linwebview3.setY( ((int)linwebview3.getY() / (int)(tabscontainer.getHeight() / 4)) * (int)(tabscontainer.getHeight() / 4));
									linwebview4.setX(((int)linwebview4.getX() / (int)(tabscontainer.getWidth() / 4)) * (int)(tabscontainer.getWidth() / 4));
									linwebview4.setY( ((int)linwebview4.getY() / (int)(tabscontainer.getHeight() / 4)) * (int)(tabscontainer.getHeight() / 4));
									linwebview5.setX(((int)linwebview5.getX() / (int)(tabscontainer.getWidth() / 4)) * (int)(tabscontainer.getWidth() / 4));
									linwebview5.setY( ((int)linwebview5.getY() / (int)(tabscontainer.getHeight() / 4)) * (int)(tabscontainer.getHeight() / 4));
									linwebview6.setX(((int)linwebview6.getX() / (int)(tabscontainer.getWidth() / 4)) * (int)(tabscontainer.getWidth() / 4));
									linwebview6.setY( ((int)linwebview6.getY() / (int)(tabscontainer.getHeight() / 4)) * (int)(tabscontainer.getHeight() / 4));
									
								}
							}catch(Exception e){
								 
							}
						}
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(timer, (int)(99), (int)(100));
	}
	
	
	public void _setTopPadding(final View _view, final double _topPadding) {
		int topPaddingInPx = (int) ((int)_topPadding * getResources().getDisplayMetrics().density + 0.5f);
		
		    if(topPaddingInPx>0){_view.setPadding(1, (int)topPaddingInPx, 1, 1);}else
		{_view.setPadding(0,0,0,0);}
	}
	
	
	public void _verifynew() {
		tab = new Gson().fromJson(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Tabs.json"), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		if (!webview1.getUrl().equals(tab.get((int)0).get("url").toString())) {
			webview1.loadUrl(tab.get((int)0).get("url").toString());
		}
		if (!webview2.getUrl().equals(tab.get((int)1).get("url").toString())) {
			webview2.loadUrl(tab.get((int)1).get("url").toString());
		}
		if (!webview3.getUrl().equals(tab.get((int)2).get("url").toString())) {
			webview3.loadUrl(tab.get((int)2).get("url").toString());
		}
		if (!webview4.getUrl().equals(tab.get((int)3).get("url").toString())) {
			webview4.loadUrl(tab.get((int)3).get("url").toString());
		}
		if (!webview5.getUrl().equals(tab.get((int)4).get("url").toString())) {
			webview5.loadUrl(tab.get((int)4).get("url").toString());
		}
		if (!webview6.getUrl().equals(tab.get((int)5).get("url").toString())) {
			webview6.loadUrl(tab.get((int)5).get("url").toString());
		}
	}
	
	
	public void _light() {
		textview1.setBackgroundColor(0xFF33B5E5);
		linear1.setBackgroundColor(0xFFFFFFFF);
		nav.setBackgroundColor(0xFFFFFFFF);
		settingspanel.setBackgroundColor(0xFFFFFFFF);
		pc.setTextColor(0xFF000000);
		js.setTextColor(0xFF000000);
		back.setTextColor(0xFF000000);
		forward.setTextColor(0xFF000000);
		pgup.setTextColor(0xFF000000);
		pgdn.setTextColor(0xFF000000);
		home.setTextColor(0xFF000000);
		image.setTextColor(0xFF000000);
		autocomplete1.setTextColor(0xFF000000);
		autocomplete1.setHintTextColor(0xFF9E9E9E);
		refresh.setTextColor(0xFF000000);
		button1.setTextColor(0xFF000000);
		openpanel.setTextColor(0xFF000000);
		bookmarks.setTextColor(0xFF000000);
		incognito.setTextColor(0xFF000000);
		button3.setTextColor(0xFF000000);
		blockad.setTextColor(0xFF000000);
		textview1.setTextColor(0xFF000000);
		back.setBackgroundColor(0xFF33B5E5);
		forward.setBackgroundColor(0xFF33B5E5);
		pgup.setBackgroundColor(0xFF33B5E5);
		pgdn.setBackgroundColor(0xFF33B5E5);
		pagesearch.setTextColor(0xFF000000);
		home.setBackgroundColor(0xFF33B5E5);
		refresh.setBackgroundColor(0xFF33B5E5);
		bookmarks.setBackgroundColor(0xFF33B5E5);
		hide.setTextColor(0xFF000000);
		hide.setBackgroundColor(0xFF33B5E5);
		button1.setBackgroundColor(0xFF33B5E5);
		button3.setBackgroundColor(0xFF33B5E5);
		openpanel.setBackgroundColor(0xFF33B5E5);
		button3.setBackgroundColor(0xFF33B5E5);
		textview2.setTextColor(0xFF33B5E5);
		textview3.setTextColor(0xFF33B5E5);
		textview5.setTextColor(0xFF33B5E5);
		tabs.setBackgroundColor(0xFF33B5E5);
		
		dual.setBackgroundColor(0xFF33B5E5);
		tabs.setTextColor(0xFF000000);
		
		dual.setTextColor(0xFF000000);
		histori.setBackgroundColor(0xFF33B5E5);
		skipvideo.setBackgroundColor(0xFF33B5E5);
		histori.setTextColor(0xFF000000);
		skipvideo.setTextColor(0xFF000000);
		searchpan.setBackgroundColor(0xFFFFFFFF);
		pagesearch.setBackgroundColor(0xFF33B5E5);
		sup.setBackgroundColor(0xFF33B5E5);
		sdown.setBackgroundColor(0xFF33B5E5);
		search.setTextColor(0xFF000000);
		search.setHintTextColor(0xFF757575);
		sup.setTextColor(0xFF000000);
		sdown.setTextColor(0xFF000000);
		num.setTextColor(0xFF000000);
		coordinates.setBackgroundColor(0xFF33B5E5);
		coordinates.setTextColor(0xFF000000);
		pos1.setBackgroundColor(0xFF33B5E5);
		pos1.setTextColor(0xFF000000);
		pos2.setBackgroundColor(0xFF33B5E5);
		pos2.setTextColor(0xFF000000);
		pos3.setBackgroundColor(0xFF33B5E5);
		pos3.setTextColor(0xFF000000);
		
		
		
		
		
		
		
		
		
		
		
		
		
		iframe.setTextColor(0xFF000000);
		bml1.setBackgroundColor(0xFF33B5E5);
		bml1.setTextColor(0xFF000000);
		bml2.setBackgroundColor(0xFF33B5E5);
		bml2.setTextColor(0xFF000000);
		bml3.setBackgroundColor(0xFF33B5E5);
		bml3.setTextColor(0xFF000000);
		bml4.setBackgroundColor(0xFF33B5E5);
		bml4.setTextColor(0xFF000000);
		bml5.setBackgroundColor(0xFF33B5E5);
		bml5.setTextColor(0xFF000000);
		title.setTextColor(0xFF000000);
		supermenu.setTextColor(0xFF000000);
		addshortcut.setTextColor(0xFF000000);
		addshortcut.setBackgroundColor(0xFF33B5E5);
		widthm1.setBackgroundColor(0xFF33B5E5);
		widthm1.setTextColor(0xFF000000);
		widthp1.setBackgroundColor(0xFF33B5E5);
		widthp1.setTextColor(0xFF000000);
		heightm1.setBackgroundColor(0xFF33B5E5);
		heightm1.setTextColor(0xFF000000);
		heightp1.setBackgroundColor(0xFF33B5E5);
		widthp1.setTextColor(0xFF000000);
		tabscontainer.setBackgroundColor(0xFFFFFFFF);
		windowsmanager.setBackgroundColor(0xFFFFFFFF);
	}
	
	
	public void _dark() {
		textview1.setBackgroundColor(0xFF33B5E5);
		linear1.setBackgroundColor(0xFF111111);
		nav.setBackgroundColor(0xFF111111);
		settingspanel.setBackgroundColor(0xFF111111);
		pc.setTextColor(0xFFFFFFFF);
		js.setTextColor(0xFFFFFFFF);
		back.setTextColor(0xFF000000);
		forward.setTextColor(0xFF000000);
		pgup.setTextColor(0xFF000000);
		pgdn.setTextColor(0xFF000000);
		home.setTextColor(0xFF000000);
		autocomplete1.setTextColor(0xFFFFFFFF);
		autocomplete1.setHintTextColor(0xFFBDBDBD);
		refresh.setTextColor(0xFF000000);
		image.setTextColor(0xFFFFFFFF);
		button1.setTextColor(0xFF000000);
		openpanel.setTextColor(0xFF000000);
		bookmarks.setTextColor(0xFF000000);
		blockad.setTextColor(0xFFFFFFFF);
		button3.setTextColor(0xFF000000);
		incognito.setTextColor(0xFFFFFFFF);
		pagesearch.setTextColor(0xFF000000);
		textview1.setTextColor(0xFF000000);
		back.setBackgroundColor(0xFF33B5E5);
		forward.setBackgroundColor(0xFF33B5E5);
		pgup.setBackgroundColor(0xFF33B5E5);
		pgdn.setBackgroundColor(0xFF33B5E5);
		home.setBackgroundColor(0xFF33B5E5);
		refresh.setBackgroundColor(0xFF33B5E5);
		bookmarks.setBackgroundColor(0xFF33B5E5);
		button1.setBackgroundColor(0xFF33B5E5);
		button3.setBackgroundColor(0xFF33B5E5);
		openpanel.setBackgroundColor(0xFF33B5E5);
		textview2.setTextColor(0xFF33B5E5);
		textview3.setTextColor(0xFF33B5E5);
		textview5.setTextColor(0xFF33B5E5);
		tabs.setBackgroundColor(0xFF33B5E5);
		
		dual.setBackgroundColor(0xFF33B5E5);
		button3.setBackgroundColor(0xFF33B5E5);
		
		dual.setTextColor(0xFF000000);
		tabs.setTextColor(0xFF000000);
		histori.setBackgroundColor(0xFF33B5E5);
		skipvideo.setBackgroundColor(0xFF33B5E5);
		histori.setTextColor(0xFF000000);
		skipvideo.setTextColor(0xFF000000);
		searchpan.setBackgroundColor(0xFF111111);
		pagesearch.setBackgroundColor(0xFF33B5E5);
		sup.setBackgroundColor(0xFF33B5E5);
		sdown.setBackgroundColor(0xFF33B5E5);
		search.setTextColor(0xFFFFFFFF);
		search.setHintTextColor(0xFFBDBDBD);
		sup.setTextColor(0xFF000000);
		sdown.setTextColor(0xFF000000);
		num.setTextColor(0xFFFFFFFF);
		hide.setBackgroundColor(0xFF33B5E5);
		hide.setTextColor(0xFF000000);
		coordinates.setBackgroundColor(0xFF33B5E5);
		coordinates.setTextColor(0xFF000000);
		pos1.setBackgroundColor(0xFF33B5E5);
		pos1.setTextColor(0xFF000000);
		pos2.setBackgroundColor(0xFF33B5E5);
		pos2.setTextColor(0xFF000000);
		pos3.setBackgroundColor(0xFF33B5E5);
		pos3.setTextColor(0xFF000000);
		
		
		
		
		
		
		
		
		
		
		
		
		
		iframe.setTextColor(0xFFFFFFFF);
		bml1.setBackgroundColor(0xFF33B5E5);
		bml1.setTextColor(0xFF000000);
		bml2.setBackgroundColor(0xFF33B5E5);
		bml2.setTextColor(0xFF000000);
		bml3.setBackgroundColor(0xFF33B5E5);
		bml3.setTextColor(0xFF000000);
		bml4.setBackgroundColor(0xFF33B5E5);
		bml4.setTextColor(0xFF000000);
		bml5.setBackgroundColor(0xFF33B5E5);
		bml5.setTextColor(0xFF000000);
		
		
		
		title.setTextColor(0xFFFFFFFF);
		supermenu.setTextColor(0xFFFFFFFF);
		
		widthm1.setBackgroundColor(0xFF33B5E5);
		widthm1.setTextColor(0xFF000000);
		widthp1.setBackgroundColor(0xFF33B5E5);
		widthp1.setTextColor(0xFF000000);
		heightm1.setBackgroundColor(0xFF33B5E5);
		heightm1.setTextColor(0xFF000000);
		heightp1.setBackgroundColor(0xFF33B5E5);
		widthp1.setTextColor(0xFF000000);
		tabscontainer.setBackgroundColor(0xFF111111);
		windowsmanager.setBackgroundColor(0xFF111111);
	}
	
	
	public String _geturl() {
		String baseUrl = "";
		switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
			case "0": {
				        String fullUrl = webview1.getUrl();
				        try {
					            URL url = new URL(fullUrl);
					             baseUrl = url.getProtocol() + "://" + url.getHost();
					        } catch (MalformedURLException e) {
					            e.printStackTrace();
					        }
				break;
			}
			case "1": {
				        String fullUrl = webview2.getUrl();
				        try {
					            URL url = new URL(fullUrl);
					             baseUrl = url.getProtocol() + "://" + url.getHost();
					
					        } catch (MalformedURLException e) {
					            e.printStackTrace();
					        }
				break;
			}
			case "2": {
				        String fullUrl = webview3.getUrl();
				        try {
					            URL url = new URL(fullUrl);
					             baseUrl = url.getProtocol() + "://" + url.getHost();
					        } catch (MalformedURLException e) {
					            e.printStackTrace();
					        }
				break;
			}
			case "3": {
				        String fullUrl = webview4.getUrl();
				        try {
					            URL url = new URL(fullUrl);
					             baseUrl = url.getProtocol() + "://" + url.getHost();
					        } catch (MalformedURLException e) {
					            e.printStackTrace();
					        }
				break;
			}
			case "4": {
				        String fullUrl = webview5.getUrl();
				        try {
					            URL url = new URL(fullUrl);
					             baseUrl = url.getProtocol() + "://" + url.getHost();
					        } catch (MalformedURLException e) {
					            e.printStackTrace();
					        }
				break;
			}
			case "5": {
				        String fullUrl = webview6.getUrl();
				        try {
					            URL url = new URL(fullUrl);
					             baseUrl = url.getProtocol() + "://" + url.getHost();
					        } catch (MalformedURLException e) {
					            e.printStackTrace();
					        }
				break;
			}
		}
		return (baseUrl);
	}
	
	
	public void _Blockad() {
		try{
			for (int i = 0; i < (int)(sitepermis.size()); i++) {
				if (webview1.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
					switch(sitepermis.get((int)i).get("ad").toString()) {
						case "1": {
							adbl = true;
							break;
						}
						case "2": {
							if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/BlockAd.txt").equals("1")) {
								adbl = true;
							}
							else {
								adbl = false;
							}
							break;
						}
						case "0": {
							adbl = false;
							break;
						}
					}
					issu = true;
				}
			}
			if (!issu) {
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/BlockAd.txt").equals("1")) {
					adbl = true;
				}
				else {
					adbl = false;
				}
			}
			issu = false;
			for (int i = 0; i < (int)(sitepermis.size()); i++) {
				if (webview2.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
					switch(sitepermis.get((int)i).get("ad").toString()) {
						case "0": {
							adbl2 = false;
							break;
						}
						case "1": {
							adbl2 = true;
							break;
						}
						case "2": {
							if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/BlockAd.txt").equals("1")) {
								adbl2 = true;
							}
							else {
								adbl2 = false;
							}
							break;
						}
					}
					issu = true;
				}
			}
			if (!issu) {
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/BlockAd.txt").equals("1")) {
					adbl2 = true;
				}
				else {
					adbl2 = false;
				}
			}
			issu = false;
			for (int i = 0; i < (int)(sitepermis.size()); i++) {
				if (webview3.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
					switch(sitepermis.get((int)i).get("ad").toString()) {
						case "1": {
							adbl3 = true;
							break;
						}
						case "2": {
							if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/BlockAd.txt").equals("1")) {
								adbl3 = true;
							}
							else {
								adbl3 = false;
							}
							break;
						}
						case "0": {
							adbl3 = false;
							break;
						}
					}
					issu = true;
				}
			}
			if (!issu) {
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/BlockAd.txt").equals("1")) {
					adbl3 = true;
				}
				else {
					adbl3 = false;
				}
			}
			issu = false;
			for (int i = 0; i < (int)(sitepermis.size()); i++) {
				if (webview4.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
					switch(sitepermis.get((int)i).get("ad").toString()) {
						case "1": {
							adbl4 = true;
							break;
						}
						case "2": {
							if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/BlockAd.txt").equals("1")) {
								adbl4 = true;
							}
							else {
								adbl4 = false;
							}
							break;
						}
						case "0": {
							adbl4 = false;
							break;
						}
					}
					issu = true;
				}
			}
			if (!issu) {
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/BlockAd.txt").equals("1")) {
					adbl4 = true;
				}
				else {
					adbl4 = false;
				}
			}
			issu = false;
			for (int i = 0; i < (int)(sitepermis.size()); i++) {
				if (webview5.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
					switch(sitepermis.get((int)i).get("ad").toString()) {
						case "1": {
							adbl5 = true;
							break;
						}
						case "2": {
							if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/BlockAd.txt").equals("1")) {
								adbl5 = true;
							}
							else {
								adbl5 = false;
							}
							break;
						}
						case "0": {
							adbl5 = false;
							break;
						}
					}
					issu = true;
				}
			}
			if (!issu) {
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/BlockAd.txt").equals("1")) {
					adbl5 = true;
				}
				else {
					adbl5 = false;
				}
			}
			issu = false;
			for (int i = 0; i < (int)(sitepermis.size()); i++) {
				if (webview6.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
					switch(sitepermis.get((int)i).get("ad").toString()) {
						case "1": {
							adbl6 = true;
							break;
						}
						case "2": {
							if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/BlockAd.txt").equals("1")) {
								adbl6 = true;
							}
							else {
								adbl6 = false;
							}
							break;
						}
						case "0": {
							adbl6 = false;
							break;
						}
					}
					issu = true;
				}
			}
			if (!issu) {
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/BlockAd.txt").equals("1")) {
					if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/BlockAd.txt").equals("1")) {
						adbl6 = true;
					}
					else {
						adbl6 = false;
					}
				}
			}
			issu = false;
		}catch(Exception e){
			issu = false;
		}
	}
	
	
	public void _setcolofuttons() {
		switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
			case "0": {
				tempurl = webview1.getUrl();
				break;
			}
			case "1": {
				tempurl = webview2.getUrl();
				break;
			}
			case "2": {
				tempurl = webview3.getUrl();
				break;
			}
			case "3": {
				tempurl = webview4.getUrl();
				break;
			}
			case "4": {
				tempurl = webview5.getUrl();
				break;
			}
			case "5": {
				tempurl = webview6.getUrl();
				break;
			}
		}
		if (!isredrawbuttons) {
			new buttoncolorificator().execute("");
		}
	}
	
	
	public void _Blockifr() {
		try{
			for (int i = 0; i < (int)(sitepermis.size()); i++) {
				if (webview1.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
					switch(sitepermis.get((int)i).get("if").toString()) {
						case "1": {
							webview1.loadUrl("javascript:(function() {     var iframes = document.querySelectorAll('iframe');     if (iframes) {         for (var i = 0; i < iframes.length; i++) {             iframes[i].parentNode.removeChild(iframes[i]);         }     } })(); ");
							break;
						}
						case "2": {
							if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/IfameBlock.txt").equals("1")) {
								webview1.loadUrl("javascript:(function() {     var iframes = document.querySelectorAll('iframe');     if (iframes) {         for (var i = 0; i < iframes.length; i++) {             iframes[i].parentNode.removeChild(iframes[i]);         }     } })(); ");
							}
							break;
						}
						case "0": {
							 
							break;
						}
					}
					issu = true;
				}
			}
			if (!issu) {
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/IfameBlock.txt").equals("1")) {
					webview1.loadUrl("javascript:(function() {     var iframes = document.querySelectorAll('iframe');     if (iframes) {         for (var i = 0; i < iframes.length; i++) {             iframes[i].parentNode.removeChild(iframes[i]);         }     } })(); ");
				}
			}
			issu = false;
			for (int i = 0; i < (int)(sitepermis.size()); i++) {
				if (webview2.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
					switch(sitepermis.get((int)i).get("if").toString()) {
						case "0": {
							 
							break;
						}
						case "1": {
							webview2.loadUrl("javascript:(function() {     var iframes = document.querySelectorAll('iframe');     if (iframes) {         for (var i = 0; i < iframes.length; i++) {             iframes[i].parentNode.removeChild(iframes[i]);         }     } })(); ");
							break;
						}
						case "2": {
							if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/IfameBlock.txt").equals("1")) {
								webview2.loadUrl("javascript:(function() {     var iframes = document.querySelectorAll('iframe');     if (iframes) {         for (var i = 0; i < iframes.length; i++) {             iframes[i].parentNode.removeChild(iframes[i]);         }     } })(); ");
							}
							break;
						}
					}
					issu = true;
				}
			}
			if (!issu) {
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/IfameBlock.txt").equals("1")) {
					webview2.loadUrl("javascript:(function() {     var iframes = document.querySelectorAll('iframe');     if (iframes) {         for (var i = 0; i < iframes.length; i++) {             iframes[i].parentNode.removeChild(iframes[i]);         }     } })(); ");
				}
			}
			issu = false;
			for (int i = 0; i < (int)(sitepermis.size()); i++) {
				if (webview3.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
					switch(sitepermis.get((int)i).get("if").toString()) {
						case "1": {
							webview3.loadUrl("javascript:(function() {     var iframes = document.querySelectorAll('iframe');     if (iframes) {         for (var i = 0; i < iframes.length; i++) {             iframes[i].parentNode.removeChild(iframes[i]);         }     } })(); ");
							break;
						}
						case "2": {
							if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/IfameBlock.txt").equals("1")) {
								webview3.loadUrl("javascript:(function() {     var iframes = document.querySelectorAll('iframe');     if (iframes) {         for (var i = 0; i < iframes.length; i++) {             iframes[i].parentNode.removeChild(iframes[i]);         }     } })(); ");
							}
							break;
						}
						case "0": {
							 
							break;
						}
					}
					issu = true;
				}
			}
			if (!issu) {
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/IfameBlock.txt").equals("1")) {
					webview3.loadUrl("javascript:(function() {     var iframes = document.querySelectorAll('iframe');     if (iframes) {         for (var i = 0; i < iframes.length; i++) {             iframes[i].parentNode.removeChild(iframes[i]);         }     } })(); ");
				}
			}
			issu = false;
			for (int i = 0; i < (int)(sitepermis.size()); i++) {
				if (webview4.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
					switch(sitepermis.get((int)i).get("if").toString()) {
						case "1": {
							webview4.loadUrl("javascript:(function() {     var iframes = document.querySelectorAll('iframe');     if (iframes) {         for (var i = 0; i < iframes.length; i++) {             iframes[i].parentNode.removeChild(iframes[i]);         }     } })(); ");
							break;
						}
						case "2": {
							if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/IfameBlock.txt").equals("1")) {
								webview4.loadUrl("javascript:(function() {     var iframes = document.querySelectorAll('iframe');     if (iframes) {         for (var i = 0; i < iframes.length; i++) {             iframes[i].parentNode.removeChild(iframes[i]);         }     } })(); ");
							}
							break;
						}
						case "0": {
							 
							break;
						}
					}
					issu = true;
				}
			}
			if (!issu) {
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/IfameBlock.txt").equals("1")) {
					webview4.loadUrl("javascript:(function() {     var iframes = document.querySelectorAll('iframe');     if (iframes) {         for (var i = 0; i < iframes.length; i++) {             iframes[i].parentNode.removeChild(iframes[i]);         }     } })(); ");
				}
			}
			issu = false;
			for (int i = 0; i < (int)(sitepermis.size()); i++) {
				if (webview5.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
					switch(sitepermis.get((int)i).get("if").toString()) {
						case "1": {
							webview5.loadUrl("javascript:(function() {     var iframes = document.querySelectorAll('iframe');     if (iframes) {         for (var i = 0; i < iframes.length; i++) {             iframes[i].parentNode.removeChild(iframes[i]);         }     } })(); ");
							break;
						}
						case "2": {
							if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/IfameBlock.txt").equals("1")) {
								webview5.loadUrl("javascript:(function() {     var iframes = document.querySelectorAll('iframe');     if (iframes) {         for (var i = 0; i < iframes.length; i++) {             iframes[i].parentNode.removeChild(iframes[i]);         }     } })(); ");
							}
							break;
						}
						case "0": {
							 
							break;
						}
					}
					issu = true;
				}
			}
			if (!issu) {
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/IfameBlock.txt").equals("1")) {
					webview5.loadUrl("javascript:(function() {     var iframes = document.querySelectorAll('iframe');     if (iframes) {         for (var i = 0; i < iframes.length; i++) {             iframes[i].parentNode.removeChild(iframes[i]);         }     } })(); ");
				}
			}
			issu = false;
			for (int i = 0; i < (int)(sitepermis.size()); i++) {
				if (webview6.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
					switch(sitepermis.get((int)i).get("if").toString()) {
						case "1": {
							webview6.loadUrl("javascript:(function() {     var iframes = document.querySelectorAll('iframe');     if (iframes) {         for (var i = 0; i < iframes.length; i++) {             iframes[i].parentNode.removeChild(iframes[i]);         }     } })(); ");
							break;
						}
						case "2": {
							if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/IfameBlock.txt").equals("1")) {
								webview6.loadUrl("javascript:(function() {     var iframes = document.querySelectorAll('iframe');     if (iframes) {         for (var i = 0; i < iframes.length; i++) {             iframes[i].parentNode.removeChild(iframes[i]);         }     } })(); ");
							}
							break;
						}
						case "0": {
							 
							break;
						}
					}
					issu = true;
				}
			}
			if (!issu) {
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/IfameBlock.txt").equals("1")) {
					webview6.loadUrl("javascript:(function() {     var iframes = document.querySelectorAll('iframe');     if (iframes) {         for (var i = 0; i < iframes.length; i++) {             iframes[i].parentNode.removeChild(iframes[i]);         }     } })(); ");
				}
			}
			issu = false;
		}catch(Exception e){
			issu = false;
		}
	}
	
	
	public void _jsset() {
		try{
			for (int i = 0; i < (int)(sitepermis.size()); i++) {
				if (webview1.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
					switch(sitepermis.get((int)i).get("js").toString()) {
						case "1": {
							webview1.getSettings().setJavaScriptEnabled(true);
							webview1.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
							if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
								    webview1.getSettings().setAllowFileAccessFromFileURLs(true);
								    webview1.getSettings().setAllowUniversalAccessFromFileURLs(true);
							}
							break;
						}
						case "2": {
							if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/js.txt").equals("1")) {
								webview1.getSettings().setJavaScriptEnabled(true);
								webview1.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
								if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
									    webview1.getSettings().setAllowFileAccessFromFileURLs(true);
									    webview1.getSettings().setAllowUniversalAccessFromFileURLs(true);
								}
								
							}
							else {
								webview1.getSettings().setJavaScriptEnabled(false);
								webview1.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
								if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
									    webview1.getSettings().setAllowFileAccessFromFileURLs(true);
									    webview1.getSettings().setAllowUniversalAccessFromFileURLs(true);
								}
								
							}
							break;
						}
						case "0": {
							webview1.getSettings().setJavaScriptEnabled(false);
							webview1.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
							if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
								    webview1.getSettings().setAllowFileAccessFromFileURLs(true);
								    webview1.getSettings().setAllowUniversalAccessFromFileURLs(true);
							}
							
							break;
						}
					}
					issu = true;
				}
			}
			if (!issu) {
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/js.txt").equals("1")) {
					webview1.getSettings().setJavaScriptEnabled(true);
					webview1.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
					if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
						    webview1.getSettings().setAllowFileAccessFromFileURLs(true);
						    webview1.getSettings().setAllowUniversalAccessFromFileURLs(true);
					}
					
				}
				else {
					webview1.getSettings().setJavaScriptEnabled(false);
					webview1.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
					if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
						    webview1.getSettings().setAllowFileAccessFromFileURLs(true);
						    webview1.getSettings().setAllowUniversalAccessFromFileURLs(true);
					}
					
				}
			}
			issu = false;
			for (int i = 0; i < (int)(sitepermis.size()); i++) {
				if (webview2.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
					switch(sitepermis.get((int)i).get("js").toString()) {
						case "1": {
							webview2.getSettings().setJavaScriptEnabled(true);
							webview2.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
							if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
								    webview2.getSettings().setAllowFileAccessFromFileURLs(true);
								    webview2.getSettings().setAllowUniversalAccessFromFileURLs(true);
							}
							break;
						}
						case "2": {
							if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/js.txt").equals("1")) {
								webview2.getSettings().setJavaScriptEnabled(true);
								webview2.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
								if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
									    webview2.getSettings().setAllowFileAccessFromFileURLs(true);
									    webview2.getSettings().setAllowUniversalAccessFromFileURLs(true);
								}
								
							}
							else {
								webview2.getSettings().setJavaScriptEnabled(false);
								webview2.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
								if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
									    webview2.getSettings().setAllowFileAccessFromFileURLs(true);
									    webview2.getSettings().setAllowUniversalAccessFromFileURLs(true);
								}
								
							}
							break;
						}
						case "0": {
							webview2.getSettings().setJavaScriptEnabled(false);
							webview2.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
							if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
								    webview2.getSettings().setAllowFileAccessFromFileURLs(true);
								    webview2.getSettings().setAllowUniversalAccessFromFileURLs(true);
							}
							
							break;
						}
					}
					issu = true;
				}
			}
			if (!issu) {
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/js.txt").equals("1")) {
					webview2.getSettings().setJavaScriptEnabled(true);
					webview2.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
					if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
						    webview2.getSettings().setAllowFileAccessFromFileURLs(true);
						    webview2.getSettings().setAllowUniversalAccessFromFileURLs(true);
					}
					
				}
				else {
					webview2.getSettings().setJavaScriptEnabled(false);
					webview2.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
					if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
						    webview2.getSettings().setAllowFileAccessFromFileURLs(true);
						    webview2.getSettings().setAllowUniversalAccessFromFileURLs(true);
					}
					
				}
			}
			issu = false;
			for (int i = 0; i < (int)(sitepermis.size()); i++) {
				if (webview3.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
					switch(sitepermis.get((int)i).get("js").toString()) {
						case "1": {
							webview3.getSettings().setJavaScriptEnabled(true);
							webview3.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
							if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
								    webview3.getSettings().setAllowFileAccessFromFileURLs(true);
								    webview3.getSettings().setAllowUniversalAccessFromFileURLs(true);
							}
							break;
						}
						case "2": {
							if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/js.txt").equals("1")) {
								webview3.getSettings().setJavaScriptEnabled(true);
								webview3.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
								if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
									    webview3.getSettings().setAllowFileAccessFromFileURLs(true);
									    webview3.getSettings().setAllowUniversalAccessFromFileURLs(true);
								}
								
							}
							else {
								webview3.getSettings().setJavaScriptEnabled(false);
								webview3.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
								if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
									    webview3.getSettings().setAllowFileAccessFromFileURLs(true);
									    webview3.getSettings().setAllowUniversalAccessFromFileURLs(true);
								}
								
							}
							break;
						}
						case "0": {
							webview3.getSettings().setJavaScriptEnabled(false);
							webview3.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
							if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
								    webview3.getSettings().setAllowFileAccessFromFileURLs(true);
								    webview3.getSettings().setAllowUniversalAccessFromFileURLs(true);
							}
							
							break;
						}
					}
					issu = true;
				}
			}
			if (!issu) {
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/js.txt").equals("1")) {
					webview3.getSettings().setJavaScriptEnabled(true);
					webview3.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
					if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
						    webview3.getSettings().setAllowFileAccessFromFileURLs(true);
						    webview3.getSettings().setAllowUniversalAccessFromFileURLs(true);
					}
					
				}
				else {
					webview3.getSettings().setJavaScriptEnabled(false);
					webview3.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
					if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
						    webview3.getSettings().setAllowFileAccessFromFileURLs(true);
						    webview3.getSettings().setAllowUniversalAccessFromFileURLs(true);
					}
					
				}
			}
			issu = false;
			for (int i = 0; i < (int)(sitepermis.size()); i++) {
				if (webview4.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
					switch(sitepermis.get((int)i).get("js").toString()) {
						case "1": {
							webview4.getSettings().setJavaScriptEnabled(true);
							webview4.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
							if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
								    webview4.getSettings().setAllowFileAccessFromFileURLs(true);
								    webview4.getSettings().setAllowUniversalAccessFromFileURLs(true);
							}
							break;
						}
						case "2": {
							if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/js.txt").equals("1")) {
								webview4.getSettings().setJavaScriptEnabled(true);
								webview4.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
								if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
									    webview4.getSettings().setAllowFileAccessFromFileURLs(true);
									    webview4.getSettings().setAllowUniversalAccessFromFileURLs(true);
								}
							}
							else {
								webview4.getSettings().setJavaScriptEnabled(false);
								webview4.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
								if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
									    webview4.getSettings().setAllowFileAccessFromFileURLs(true);
									    webview4.getSettings().setAllowUniversalAccessFromFileURLs(true);
								}
								
							}
							break;
						}
						case "0": {
							webview4.getSettings().setJavaScriptEnabled(false);
							webview4.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
							if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
								    webview4.getSettings().setAllowFileAccessFromFileURLs(true);
								    webview4.getSettings().setAllowUniversalAccessFromFileURLs(true);
							}
							
							break;
						}
					}
					issu = true;
				}
			}
			if (!issu) {
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/js.txt").equals("1")) {
					webview4.getSettings().setJavaScriptEnabled(true);
					webview4.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
					if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
						    webview4.getSettings().setAllowFileAccessFromFileURLs(true);
						    webview4.getSettings().setAllowUniversalAccessFromFileURLs(true);
					}
				}
				else {
					webview4.getSettings().setJavaScriptEnabled(false);
					webview4.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
					if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
						    webview4.getSettings().setAllowFileAccessFromFileURLs(true);
						    webview4.getSettings().setAllowUniversalAccessFromFileURLs(true);
					}
					
				}
			}
			issu = false;
			for (int i = 0; i < (int)(sitepermis.size()); i++) {
				if (webview5.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
					switch(sitepermis.get((int)i).get("js").toString()) {
						case "1": {
							webview5.getSettings().setJavaScriptEnabled(true);
							webview5.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
							if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
								    webview5.getSettings().setAllowFileAccessFromFileURLs(true);
								    webview5.getSettings().setAllowUniversalAccessFromFileURLs(true);
							}
							break;
						}
						case "2": {
							if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/js.txt").equals("1")) {
								webview5.getSettings().setJavaScriptEnabled(true);
								webview5.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
								if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
									    webview5.getSettings().setAllowFileAccessFromFileURLs(true);
									    webview5.getSettings().setAllowUniversalAccessFromFileURLs(true);
								}
							}
							else {
								webview5.getSettings().setJavaScriptEnabled(false);
								webview5.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
								if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
									    webview5.getSettings().setAllowFileAccessFromFileURLs(true);
									    webview5.getSettings().setAllowUniversalAccessFromFileURLs(true);
								}
								
							}
							break;
						}
						case "0": {
							webview5.getSettings().setJavaScriptEnabled(false);
							webview5.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
							if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
								    webview5.getSettings().setAllowFileAccessFromFileURLs(true);
								    webview5.getSettings().setAllowUniversalAccessFromFileURLs(true);
							}
							
							break;
						}
					}
					issu = true;
				}
			}
			if (!issu) {
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/js.txt").equals("1")) {
					webview5.getSettings().setJavaScriptEnabled(true);
					webview5.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
					if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
						    webview5.getSettings().setAllowFileAccessFromFileURLs(true);
						    webview5.getSettings().setAllowUniversalAccessFromFileURLs(true);
					}
				}
				else {
					webview5.getSettings().setJavaScriptEnabled(false);
					webview5.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
					if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
						    webview5.getSettings().setAllowFileAccessFromFileURLs(true);
						    webview5.getSettings().setAllowUniversalAccessFromFileURLs(true);
					}
					
				}
			}
			issu = false;
			for (int i = 0; i < (int)(sitepermis.size()); i++) {
				if (webview6.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
					switch(sitepermis.get((int)i).get("js").toString()) {
						case "1": {
							webview6.getSettings().setJavaScriptEnabled(true);
							webview6.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
							if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
								    webview6.getSettings().setAllowFileAccessFromFileURLs(true);
								    webview6.getSettings().setAllowUniversalAccessFromFileURLs(true);
							}
							break;
						}
						case "2": {
							if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/js.txt").equals("1")) {
								webview6.getSettings().setJavaScriptEnabled(true);
								webview6.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
								if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
									    webview6.getSettings().setAllowFileAccessFromFileURLs(true);
									    webview6.getSettings().setAllowUniversalAccessFromFileURLs(true);
								}
							}
							else {
								webview6.getSettings().setJavaScriptEnabled(false);
								webview6.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
								if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
									    webview6.getSettings().setAllowFileAccessFromFileURLs(true);
									    webview6.getSettings().setAllowUniversalAccessFromFileURLs(true);
								}
								
							}
							break;
						}
						case "0": {
							webview6.getSettings().setJavaScriptEnabled(false);
							webview6.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
							if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
								    webview6.getSettings().setAllowFileAccessFromFileURLs(true);
								    webview6.getSettings().setAllowUniversalAccessFromFileURLs(true);
							}
							
							break;
						}
					}
					issu = true;
				}
			}
			if (!issu) {
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/js.txt").equals("1")) {
					webview6.getSettings().setJavaScriptEnabled(true);
					webview6.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
					if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
						    webview6.getSettings().setAllowFileAccessFromFileURLs(true);
						    webview6.getSettings().setAllowUniversalAccessFromFileURLs(true);
					}
				}
				else {
					webview6.getSettings().setJavaScriptEnabled(false);
					webview6.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
					if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
						    webview6.getSettings().setAllowFileAccessFromFileURLs(true);
						    webview6.getSettings().setAllowUniversalAccessFromFileURLs(true);
					}
					
				}
			}
			issu = false;
		}catch(Exception e){
			 
		}
	}
	
	
	public void _instantbookmarklets() {
		if (webview1.getProgress() > 11) {
			if (ibml1) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/10001.txt")) == 1) {
					webview1.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/10001.txt")));
				}
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/10002.txt")) == 1) {
					webview1.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/10002.txt")));
				}
				ibml1 = false;
				try{
					for (int i = 0; i < (int)(sitepermis.size()); i++) {
						if (webview1.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
							switch(sitepermis.get((int)i).get("th").toString()) {
								case "1": {
									webview1.loadUrl(_replaceInstructions("javascript:(function() {\n\n  var applyNightMode = function(window) {\n    (function(document) {\n      var css = 'html{background:#$colbg$ !important}html *{background:none !important;color:#$coltext$ !important;border-color:#$colbg$ !important;border-width:0 !important}html a,html a *{color:#$coladd$ !important;text-decoration:underline !important}html a:visited,html a:visited *,html a:active,html a:active *{color:#$colhint$ !important}html a:hover,html a:hover *{color:#$colhint$ !important;background:#$colbg$ !important}html input,html select,html button,html textarea{background:#$colbg$ !important;border:1px solid #$colb1$ !important;border-top-color:#$colb2$ !important;border-bottom-color:#$colb1$ !important}html input[type=button],html input[type=submit],html input[type=reset],html input[type=image],html button{border-top-color:#$colb1$ !important;border-bottom-color:#$colb2$ !important}html input:focus,html select:focus,html option:focus,html button:focus,html textarea:focus{background:#$colbg$ !important;color:#$colfield$ !important;border-color:#$colb1$ #$colb2$ #$colrb1$ !important;outline:2px solid #$colrb2$ !important}html input[type=button]:focus,html input[type=submit]:focus,html input[type=reset]:focus,html input[type=image]:focus,html button:focus{border-color:#$colb1$ #$colb2$ #$colrb2$ !important}html input[type=radio]{background:none !important;border-color:#$colb1$ !important;border-width:0 !important}html img[src],html input[type=image]{opacity:1}html img[src]:hover,html input[type=image]:hover{opacity:1}html,html body{scrollbar-base-color:#$colb1$ !important;scrollbar-face-color:#$colb2$ !important;scrollbar-shadow-color:#$colhint$ !important;scrollbar-darkshadow-color:#$colhint$ !important;scrollbar-track-color:#$colrb1$ !important;scrollbar-arrow-color:#$colrb2$ !important;scrollbar-3dlight-color:#$colb1$ !important}';\n      var styleNode = document.createElement('style');\n      styleNode.type = 'text/css';\n      styleNode.appendChild(document.createTextNode(css));\n      var head = document.head || document.getElementsByTagName('head')[0];\n      head.appendChild(styleNode);\n    })(window.document);\n    for (var i = 0, frame; frame = window.frames[i]; i++) {\n      try {\n        applyNightMode(frame);\n      } catch (e) {}\n    }\n  };\n\n  applyNightMode(window);\n\n})();\n"));
									break;
								}
								case "2": {
									if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/themepage.txt").equals("1")) {
										webview1.loadUrl(_replaceInstructions("javascript:(function() {\n\n  var applyNightMode = function(window) {\n    (function(document) {\n      var css = 'html{background:#$colbg$ !important}html *{background:none !important;color:#$coltext$ !important;border-color:#$colbg$ !important;border-width:0 !important}html a,html a *{color:#$coladd$ !important;text-decoration:underline !important}html a:visited,html a:visited *,html a:active,html a:active *{color:#$colhint$ !important}html a:hover,html a:hover *{color:#$colhint$ !important;background:#$colbg$ !important}html input,html select,html button,html textarea{background:#$colbg$ !important;border:1px solid #$colb1$ !important;border-top-color:#$colb2$ !important;border-bottom-color:#$colb1$ !important}html input[type=button],html input[type=submit],html input[type=reset],html input[type=image],html button{border-top-color:#$colb1$ !important;border-bottom-color:#$colb2$ !important}html input:focus,html select:focus,html option:focus,html button:focus,html textarea:focus{background:#$colbg$ !important;color:#$colfield$ !important;border-color:#$colb1$ #$colb2$ #$colrb1$ !important;outline:2px solid #$colrb2$ !important}html input[type=button]:focus,html input[type=submit]:focus,html input[type=reset]:focus,html input[type=image]:focus,html button:focus{border-color:#$colb1$ #$colb2$ #$colrb2$ !important}html input[type=radio]{background:none !important;border-color:#$colb1$ !important;border-width:0 !important}html img[src],html input[type=image]{opacity:1}html img[src]:hover,html input[type=image]:hover{opacity:1}html,html body{scrollbar-base-color:#$colb1$ !important;scrollbar-face-color:#$colb2$ !important;scrollbar-shadow-color:#$colhint$ !important;scrollbar-darkshadow-color:#$colhint$ !important;scrollbar-track-color:#$colrb1$ !important;scrollbar-arrow-color:#$colrb2$ !important;scrollbar-3dlight-color:#$colb1$ !important}';\n      var styleNode = document.createElement('style');\n      styleNode.type = 'text/css';\n      styleNode.appendChild(document.createTextNode(css));\n      var head = document.head || document.getElementsByTagName('head')[0];\n      head.appendChild(styleNode);\n    })(window.document);\n    for (var i = 0, frame; frame = window.frames[i]; i++) {\n      try {\n        applyNightMode(frame);\n      } catch (e) {}\n    }\n  };\n\n  applyNightMode(window);\n\n})();\n"));
									}
									break;
								}
								case "0": {
									 
									break;
								}
							}
							issu = true;
						}
					}
					if (!issu) {
						if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/themepage.txt").equals("1")) {
							webview1.loadUrl(_replaceInstructions("javascript:(function() {\n\n  var applyNightMode = function(window) {\n    (function(document) {\n      var css = 'html{background:#$colbg$ !important}html *{background:none !important;color:#$coltext$ !important;border-color:#$colbg$ !important;border-width:0 !important}html a,html a *{color:#$coladd$ !important;text-decoration:underline !important}html a:visited,html a:visited *,html a:active,html a:active *{color:#$colhint$ !important}html a:hover,html a:hover *{color:#$colhint$ !important;background:#$colbg$ !important}html input,html select,html button,html textarea{background:#$colbg$ !important;border:1px solid #$colb1$ !important;border-top-color:#$colb2$ !important;border-bottom-color:#$colb1$ !important}html input[type=button],html input[type=submit],html input[type=reset],html input[type=image],html button{border-top-color:#$colb1$ !important;border-bottom-color:#$colb2$ !important}html input:focus,html select:focus,html option:focus,html button:focus,html textarea:focus{background:#$colbg$ !important;color:#$colfield$ !important;border-color:#$colb1$ #$colb2$ #$colrb1$ !important;outline:2px solid #$colrb2$ !important}html input[type=button]:focus,html input[type=submit]:focus,html input[type=reset]:focus,html input[type=image]:focus,html button:focus{border-color:#$colb1$ #$colb2$ #$colrb2$ !important}html input[type=radio]{background:none !important;border-color:#$colb1$ !important;border-width:0 !important}html img[src],html input[type=image]{opacity:1}html img[src]:hover,html input[type=image]:hover{opacity:1}html,html body{scrollbar-base-color:#$colb1$ !important;scrollbar-face-color:#$colb2$ !important;scrollbar-shadow-color:#$colhint$ !important;scrollbar-darkshadow-color:#$colhint$ !important;scrollbar-track-color:#$colrb1$ !important;scrollbar-arrow-color:#$colrb2$ !important;scrollbar-3dlight-color:#$colb1$ !important}';\n      var styleNode = document.createElement('style');\n      styleNode.type = 'text/css';\n      styleNode.appendChild(document.createTextNode(css));\n      var head = document.head || document.getElementsByTagName('head')[0];\n      head.appendChild(styleNode);\n    })(window.document);\n    for (var i = 0, frame; frame = window.frames[i]; i++) {\n      try {\n        applyNightMode(frame);\n      } catch (e) {}\n    }\n  };\n\n  applyNightMode(window);\n\n})();\n"));
						}
					}
					issu = false;
				}catch(Exception e){
					issu = false;
					if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/themepage.txt").equals("1")) {
						webview1.loadUrl(_replaceInstructions("javascript:(function() {\n\n  var applyNightMode = function(window) {\n    (function(document) {\n      var css = 'html{background:#$colbg$ !important}html *{background:none !important;color:#$coltext$ !important;border-color:#$colbg$ !important;border-width:0 !important}html a,html a *{color:#$coladd$ !important;text-decoration:underline !important}html a:visited,html a:visited *,html a:active,html a:active *{color:#$colhint$ !important}html a:hover,html a:hover *{color:#$colhint$ !important;background:#$colbg$ !important}html input,html select,html button,html textarea{background:#$colbg$ !important;border:1px solid #$colb1$ !important;border-top-color:#$colb2$ !important;border-bottom-color:#$colb1$ !important}html input[type=button],html input[type=submit],html input[type=reset],html input[type=image],html button{border-top-color:#$colb1$ !important;border-bottom-color:#$colb2$ !important}html input:focus,html select:focus,html option:focus,html button:focus,html textarea:focus{background:#$colbg$ !important;color:#$colfield$ !important;border-color:#$colb1$ #$colb2$ #$colrb1$ !important;outline:2px solid #$colrb2$ !important}html input[type=button]:focus,html input[type=submit]:focus,html input[type=reset]:focus,html input[type=image]:focus,html button:focus{border-color:#$colb1$ #$colb2$ #$colrb2$ !important}html input[type=radio]{background:none !important;border-color:#$colb1$ !important;border-width:0 !important}html img[src],html input[type=image]{opacity:1}html img[src]:hover,html input[type=image]:hover{opacity:1}html,html body{scrollbar-base-color:#$colb1$ !important;scrollbar-face-color:#$colb2$ !important;scrollbar-shadow-color:#$colhint$ !important;scrollbar-darkshadow-color:#$colhint$ !important;scrollbar-track-color:#$colrb1$ !important;scrollbar-arrow-color:#$colrb2$ !important;scrollbar-3dlight-color:#$colb1$ !important}';\n      var styleNode = document.createElement('style');\n      styleNode.type = 'text/css';\n      styleNode.appendChild(document.createTextNode(css));\n      var head = document.head || document.getElementsByTagName('head')[0];\n      head.appendChild(styleNode);\n    })(window.document);\n    for (var i = 0, frame; frame = window.frames[i]; i++) {\n      try {\n        applyNightMode(frame);\n      } catch (e) {}\n    }\n  };\n\n  applyNightMode(window);\n\n})();\n"));
					}
				}
				if (webview1.getUrl().equals("file:///storage/emulated/0/WeekBrowser/bookmark.html")) {
					webview1.loadUrl(designbmlcache);
				}
			}
		}
		if (webview2.getProgress() > 11) {
			if (ibml21) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/10001.txt")) == 1) {
					webview2.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/10001.txt")));
				}
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/10002.txt")) == 1) {
					webview2.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/10002.txt")));
				}
				ibml21 = false;
				try{
					for (int i = 0; i < (int)(sitepermis.size()); i++) {
						if (webview2.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
							switch(sitepermis.get((int)i).get("th").toString()) {
								case "1": {
									webview2.loadUrl(_replaceInstructions("javascript:(function() {\n\n  var applyNightMode = function(window) {\n    (function(document) {\n      var css = 'html{background:#$colbg$ !important}html *{background:none !important;color:#$coltext$ !important;border-color:#$colbg$ !important;border-width:0 !important}html a,html a *{color:#$coladd$ !important;text-decoration:underline !important}html a:visited,html a:visited *,html a:active,html a:active *{color:#$colhint$ !important}html a:hover,html a:hover *{color:#$colhint$ !important;background:#$colbg$ !important}html input,html select,html button,html textarea{background:#$colbg$ !important;border:1px solid #$colb1$ !important;border-top-color:#$colb2$ !important;border-bottom-color:#$colb1$ !important}html input[type=button],html input[type=submit],html input[type=reset],html input[type=image],html button{border-top-color:#$colb1$ !important;border-bottom-color:#$colb2$ !important}html input:focus,html select:focus,html option:focus,html button:focus,html textarea:focus{background:#$colbg$ !important;color:#$colfield$ !important;border-color:#$colb1$ #$colb2$ #$colrb1$ !important;outline:2px solid #$colrb2$ !important}html input[type=button]:focus,html input[type=submit]:focus,html input[type=reset]:focus,html input[type=image]:focus,html button:focus{border-color:#$colb1$ #$colb2$ #$colrb2$ !important}html input[type=radio]{background:none !important;border-color:#$colb1$ !important;border-width:0 !important}html img[src],html input[type=image]{opacity:1}html img[src]:hover,html input[type=image]:hover{opacity:1}html,html body{scrollbar-base-color:#$colb1$ !important;scrollbar-face-color:#$colb2$ !important;scrollbar-shadow-color:#$colhint$ !important;scrollbar-darkshadow-color:#$colhint$ !important;scrollbar-track-color:#$colrb1$ !important;scrollbar-arrow-color:#$colrb2$ !important;scrollbar-3dlight-color:#$colb1$ !important}';\n      var styleNode = document.createElement('style');\n      styleNode.type = 'text/css';\n      styleNode.appendChild(document.createTextNode(css));\n      var head = document.head || document.getElementsByTagName('head')[0];\n      head.appendChild(styleNode);\n    })(window.document);\n    for (var i = 0, frame; frame = window.frames[i]; i++) {\n      try {\n        applyNightMode(frame);\n      } catch (e) {}\n    }\n  };\n\n  applyNightMode(window);\n\n})();\n"));
									break;
								}
								case "2": {
									if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/themepage.txt").equals("1")) {
										webview2.loadUrl(_replaceInstructions("javascript:(function() {\n\n  var applyNightMode = function(window) {\n    (function(document) {\n      var css = 'html{background:#$colbg$ !important}html *{background:none !important;color:#$coltext$ !important;border-color:#$colbg$ !important;border-width:0 !important}html a,html a *{color:#$coladd$ !important;text-decoration:underline !important}html a:visited,html a:visited *,html a:active,html a:active *{color:#$colhint$ !important}html a:hover,html a:hover *{color:#$colhint$ !important;background:#$colbg$ !important}html input,html select,html button,html textarea{background:#$colbg$ !important;border:1px solid #$colb1$ !important;border-top-color:#$colb2$ !important;border-bottom-color:#$colb1$ !important}html input[type=button],html input[type=submit],html input[type=reset],html input[type=image],html button{border-top-color:#$colb1$ !important;border-bottom-color:#$colb2$ !important}html input:focus,html select:focus,html option:focus,html button:focus,html textarea:focus{background:#$colbg$ !important;color:#$colfield$ !important;border-color:#$colb1$ #$colb2$ #$colrb1$ !important;outline:2px solid #$colrb2$ !important}html input[type=button]:focus,html input[type=submit]:focus,html input[type=reset]:focus,html input[type=image]:focus,html button:focus{border-color:#$colb1$ #$colb2$ #$colrb2$ !important}html input[type=radio]{background:none !important;border-color:#$colb1$ !important;border-width:0 !important}html img[src],html input[type=image]{opacity:1}html img[src]:hover,html input[type=image]:hover{opacity:1}html,html body{scrollbar-base-color:#$colb1$ !important;scrollbar-face-color:#$colb2$ !important;scrollbar-shadow-color:#$colhint$ !important;scrollbar-darkshadow-color:#$colhint$ !important;scrollbar-track-color:#$colrb1$ !important;scrollbar-arrow-color:#$colrb2$ !important;scrollbar-3dlight-color:#$colb1$ !important}';\n      var styleNode = document.createElement('style');\n      styleNode.type = 'text/css';\n      styleNode.appendChild(document.createTextNode(css));\n      var head = document.head || document.getElementsByTagName('head')[0];\n      head.appendChild(styleNode);\n    })(window.document);\n    for (var i = 0, frame; frame = window.frames[i]; i++) {\n      try {\n        applyNightMode(frame);\n      } catch (e) {}\n    }\n  };\n\n  applyNightMode(window);\n\n})();\n"));
										if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/style.txt").equals("2")) {
											webview2.loadUrl("javascript:(function() {\n    var textFields = document.querySelectorAll('input[type=\"text\"], input[type=\"password\"], textarea');\n    textFields.forEach(function(field) {\n        field.style.setProperty('background-color', 'white', 'important');\n    });\n})();\n");
										}
									}
									break;
								}
								case "0": {
									 
									break;
								}
							}
							issu = true;
						}
					}
					if (!issu) {
						if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/themepage.txt").equals("1")) {
							webview2.loadUrl(_replaceInstructions("javascript:(function() {\n\n  var applyNightMode = function(window) {\n    (function(document) {\n      var css = 'html{background:#$colbg$ !important}html *{background:none !important;color:#$coltext$ !important;border-color:#$colbg$ !important;border-width:0 !important}html a,html a *{color:#$coladd$ !important;text-decoration:underline !important}html a:visited,html a:visited *,html a:active,html a:active *{color:#$colhint$ !important}html a:hover,html a:hover *{color:#$colhint$ !important;background:#$colbg$ !important}html input,html select,html button,html textarea{background:#$colbg$ !important;border:1px solid #$colb1$ !important;border-top-color:#$colb2$ !important;border-bottom-color:#$colb1$ !important}html input[type=button],html input[type=submit],html input[type=reset],html input[type=image],html button{border-top-color:#$colb1$ !important;border-bottom-color:#$colb2$ !important}html input:focus,html select:focus,html option:focus,html button:focus,html textarea:focus{background:#$colbg$ !important;color:#$colfield$ !important;border-color:#$colb1$ #$colb2$ #$colrb1$ !important;outline:2px solid #$colrb2$ !important}html input[type=button]:focus,html input[type=submit]:focus,html input[type=reset]:focus,html input[type=image]:focus,html button:focus{border-color:#$colb1$ #$colb2$ #$colrb2$ !important}html input[type=radio]{background:none !important;border-color:#$colb1$ !important;border-width:0 !important}html img[src],html input[type=image]{opacity:1}html img[src]:hover,html input[type=image]:hover{opacity:1}html,html body{scrollbar-base-color:#$colb1$ !important;scrollbar-face-color:#$colb2$ !important;scrollbar-shadow-color:#$colhint$ !important;scrollbar-darkshadow-color:#$colhint$ !important;scrollbar-track-color:#$colrb1$ !important;scrollbar-arrow-color:#$colrb2$ !important;scrollbar-3dlight-color:#$colb1$ !important}';\n      var styleNode = document.createElement('style');\n      styleNode.type = 'text/css';\n      styleNode.appendChild(document.createTextNode(css));\n      var head = document.head || document.getElementsByTagName('head')[0];\n      head.appendChild(styleNode);\n    })(window.document);\n    for (var i = 0, frame; frame = window.frames[i]; i++) {\n      try {\n        applyNightMode(frame);\n      } catch (e) {}\n    }\n  };\n\n  applyNightMode(window);\n\n})();\n"));
						}
					}
					issu = false;
				}catch(Exception e){
					issu = false;
					if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/themepage.txt").equals("1")) {
						webview2.loadUrl(_replaceInstructions("javascript:(function() {\n\n  var applyNightMode = function(window) {\n    (function(document) {\n      var css = 'html{background:#$colbg$ !important}html *{background:none !important;color:#$coltext$ !important;border-color:#$colbg$ !important;border-width:0 !important}html a,html a *{color:#$coladd$ !important;text-decoration:underline !important}html a:visited,html a:visited *,html a:active,html a:active *{color:#$colhint$ !important}html a:hover,html a:hover *{color:#$colhint$ !important;background:#$colbg$ !important}html input,html select,html button,html textarea{background:#$colbg$ !important;border:1px solid #$colb1$ !important;border-top-color:#$colb2$ !important;border-bottom-color:#$colb1$ !important}html input[type=button],html input[type=submit],html input[type=reset],html input[type=image],html button{border-top-color:#$colb1$ !important;border-bottom-color:#$colb2$ !important}html input:focus,html select:focus,html option:focus,html button:focus,html textarea:focus{background:#$colbg$ !important;color:#$colfield$ !important;border-color:#$colb1$ #$colb2$ #$colrb1$ !important;outline:2px solid #$colrb2$ !important}html input[type=button]:focus,html input[type=submit]:focus,html input[type=reset]:focus,html input[type=image]:focus,html button:focus{border-color:#$colb1$ #$colb2$ #$colrb2$ !important}html input[type=radio]{background:none !important;border-color:#$colb1$ !important;border-width:0 !important}html img[src],html input[type=image]{opacity:1}html img[src]:hover,html input[type=image]:hover{opacity:1}html,html body{scrollbar-base-color:#$colb1$ !important;scrollbar-face-color:#$colb2$ !important;scrollbar-shadow-color:#$colhint$ !important;scrollbar-darkshadow-color:#$colhint$ !important;scrollbar-track-color:#$colrb1$ !important;scrollbar-arrow-color:#$colrb2$ !important;scrollbar-3dlight-color:#$colb1$ !important}';\n      var styleNode = document.createElement('style');\n      styleNode.type = 'text/css';\n      styleNode.appendChild(document.createTextNode(css));\n      var head = document.head || document.getElementsByTagName('head')[0];\n      head.appendChild(styleNode);\n    })(window.document);\n    for (var i = 0, frame; frame = window.frames[i]; i++) {\n      try {\n        applyNightMode(frame);\n      } catch (e) {}\n    }\n  };\n\n  applyNightMode(window);\n\n})();\n"));
					}
				}
				if (webview2.getUrl().equals("file:///storage/emulated/0/WeekBrowser/bookmark.html")) {
					webview2.loadUrl(designbmlcache);
				}
			}
		}
		if (webview3.getProgress() > 11) {
			if (ibml31) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/10001.txt")) == 1) {
					webview3.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/10001.txt")));
				}
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/10002.txt")) == 1) {
					webview3.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/10002.txt")));
				}
				ibml31 = false;
				try{
					for (int i = 0; i < (int)(sitepermis.size()); i++) {
						if (webview3.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
							switch(sitepermis.get((int)i).get("th").toString()) {
								case "1": {
									webview3.loadUrl(_replaceInstructions("javascript:(function() {\n\n  var applyNightMode = function(window) {\n    (function(document) {\n      var css = 'html{background:#$colbg$ !important}html *{background:none !important;color:#$coltext$ !important;border-color:#$colbg$ !important;border-width:0 !important}html a,html a *{color:#$coladd$ !important;text-decoration:underline !important}html a:visited,html a:visited *,html a:active,html a:active *{color:#$colhint$ !important}html a:hover,html a:hover *{color:#$colhint$ !important;background:#$colbg$ !important}html input,html select,html button,html textarea{background:#$colbg$ !important;border:1px solid #$colb1$ !important;border-top-color:#$colb2$ !important;border-bottom-color:#$colb1$ !important}html input[type=button],html input[type=submit],html input[type=reset],html input[type=image],html button{border-top-color:#$colb1$ !important;border-bottom-color:#$colb2$ !important}html input:focus,html select:focus,html option:focus,html button:focus,html textarea:focus{background:#$colbg$ !important;color:#$colfield$ !important;border-color:#$colb1$ #$colb2$ #$colrb1$ !important;outline:2px solid #$colrb2$ !important}html input[type=button]:focus,html input[type=submit]:focus,html input[type=reset]:focus,html input[type=image]:focus,html button:focus{border-color:#$colb1$ #$colb2$ #$colrb2$ !important}html input[type=radio]{background:none !important;border-color:#$colb1$ !important;border-width:0 !important}html img[src],html input[type=image]{opacity:1}html img[src]:hover,html input[type=image]:hover{opacity:1}html,html body{scrollbar-base-color:#$colb1$ !important;scrollbar-face-color:#$colb2$ !important;scrollbar-shadow-color:#$colhint$ !important;scrollbar-darkshadow-color:#$colhint$ !important;scrollbar-track-color:#$colrb1$ !important;scrollbar-arrow-color:#$colrb2$ !important;scrollbar-3dlight-color:#$colb1$ !important}';\n      var styleNode = document.createElement('style');\n      styleNode.type = 'text/css';\n      styleNode.appendChild(document.createTextNode(css));\n      var head = document.head || document.getElementsByTagName('head')[0];\n      head.appendChild(styleNode);\n    })(window.document);\n    for (var i = 0, frame; frame = window.frames[i]; i++) {\n      try {\n        applyNightMode(frame);\n      } catch (e) {}\n    }\n  };\n\n  applyNightMode(window);\n\n})();\n"));
									break;
								}
								case "2": {
									if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/themepage.txt").equals("1")) {
										webview3.loadUrl(_replaceInstructions("javascript:(function() {\n\n  var applyNightMode = function(window) {\n    (function(document) {\n      var css = 'html{background:#$colbg$ !important}html *{background:none !important;color:#$coltext$ !important;border-color:#$colbg$ !important;border-width:0 !important}html a,html a *{color:#$coladd$ !important;text-decoration:underline !important}html a:visited,html a:visited *,html a:active,html a:active *{color:#$colhint$ !important}html a:hover,html a:hover *{color:#$colhint$ !important;background:#$colbg$ !important}html input,html select,html button,html textarea{background:#$colbg$ !important;border:1px solid #$colb1$ !important;border-top-color:#$colb2$ !important;border-bottom-color:#$colb1$ !important}html input[type=button],html input[type=submit],html input[type=reset],html input[type=image],html button{border-top-color:#$colb1$ !important;border-bottom-color:#$colb2$ !important}html input:focus,html select:focus,html option:focus,html button:focus,html textarea:focus{background:#$colbg$ !important;color:#$colfield$ !important;border-color:#$colb1$ #$colb2$ #$colrb1$ !important;outline:2px solid #$colrb2$ !important}html input[type=button]:focus,html input[type=submit]:focus,html input[type=reset]:focus,html input[type=image]:focus,html button:focus{border-color:#$colb1$ #$colb2$ #$colrb2$ !important}html input[type=radio]{background:none !important;border-color:#$colb1$ !important;border-width:0 !important}html img[src],html input[type=image]{opacity:1}html img[src]:hover,html input[type=image]:hover{opacity:1}html,html body{scrollbar-base-color:#$colb1$ !important;scrollbar-face-color:#$colb2$ !important;scrollbar-shadow-color:#$colhint$ !important;scrollbar-darkshadow-color:#$colhint$ !important;scrollbar-track-color:#$colrb1$ !important;scrollbar-arrow-color:#$colrb2$ !important;scrollbar-3dlight-color:#$colb1$ !important}';\n      var styleNode = document.createElement('style');\n      styleNode.type = 'text/css';\n      styleNode.appendChild(document.createTextNode(css));\n      var head = document.head || document.getElementsByTagName('head')[0];\n      head.appendChild(styleNode);\n    })(window.document);\n    for (var i = 0, frame; frame = window.frames[i]; i++) {\n      try {\n        applyNightMode(frame);\n      } catch (e) {}\n    }\n  };\n\n  applyNightMode(window);\n\n})();\n"));
									}
									break;
								}
								case "0": {
									 
									break;
								}
							}
							issu = true;
						}
					}
					if (!issu) {
						if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/themepage.txt").equals("1")) {
							webview3.loadUrl(_replaceInstructions("javascript:(function() {\n\n  var applyNightMode = function(window) {\n    (function(document) {\n      var css = 'html{background:#$colbg$ !important}html *{background:none !important;color:#$coltext$ !important;border-color:#$colbg$ !important;border-width:0 !important}html a,html a *{color:#$coladd$ !important;text-decoration:underline !important}html a:visited,html a:visited *,html a:active,html a:active *{color:#$colhint$ !important}html a:hover,html a:hover *{color:#$colhint$ !important;background:#$colbg$ !important}html input,html select,html button,html textarea{background:#$colbg$ !important;border:1px solid #$colb1$ !important;border-top-color:#$colb2$ !important;border-bottom-color:#$colb1$ !important}html input[type=button],html input[type=submit],html input[type=reset],html input[type=image],html button{border-top-color:#$colb1$ !important;border-bottom-color:#$colb2$ !important}html input:focus,html select:focus,html option:focus,html button:focus,html textarea:focus{background:#$colbg$ !important;color:#$colfield$ !important;border-color:#$colb1$ #$colb2$ #$colrb1$ !important;outline:2px solid #$colrb2$ !important}html input[type=button]:focus,html input[type=submit]:focus,html input[type=reset]:focus,html input[type=image]:focus,html button:focus{border-color:#$colb1$ #$colb2$ #$colrb2$ !important}html input[type=radio]{background:none !important;border-color:#$colb1$ !important;border-width:0 !important}html img[src],html input[type=image]{opacity:1}html img[src]:hover,html input[type=image]:hover{opacity:1}html,html body{scrollbar-base-color:#$colb1$ !important;scrollbar-face-color:#$colb2$ !important;scrollbar-shadow-color:#$colhint$ !important;scrollbar-darkshadow-color:#$colhint$ !important;scrollbar-track-color:#$colrb1$ !important;scrollbar-arrow-color:#$colrb2$ !important;scrollbar-3dlight-color:#$colb1$ !important}';\n      var styleNode = document.createElement('style');\n      styleNode.type = 'text/css';\n      styleNode.appendChild(document.createTextNode(css));\n      var head = document.head || document.getElementsByTagName('head')[0];\n      head.appendChild(styleNode);\n    })(window.document);\n    for (var i = 0, frame; frame = window.frames[i]; i++) {\n      try {\n        applyNightMode(frame);\n      } catch (e) {}\n    }\n  };\n\n  applyNightMode(window);\n\n})();\n"));
						}
					}
					issu = false;
				}catch(Exception e){
					issu = false;
					if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/themepage.txt").equals("1")) {
						webview3.loadUrl(_replaceInstructions("javascript:(function() {\n\n  var applyNightMode = function(window) {\n    (function(document) {\n      var css = 'html{background:#$colbg$ !important}html *{background:none !important;color:#$coltext$ !important;border-color:#$colbg$ !important;border-width:0 !important}html a,html a *{color:#$coladd$ !important;text-decoration:underline !important}html a:visited,html a:visited *,html a:active,html a:active *{color:#$colhint$ !important}html a:hover,html a:hover *{color:#$colhint$ !important;background:#$colbg$ !important}html input,html select,html button,html textarea{background:#$colbg$ !important;border:1px solid #$colb1$ !important;border-top-color:#$colb2$ !important;border-bottom-color:#$colb1$ !important}html input[type=button],html input[type=submit],html input[type=reset],html input[type=image],html button{border-top-color:#$colb1$ !important;border-bottom-color:#$colb2$ !important}html input:focus,html select:focus,html option:focus,html button:focus,html textarea:focus{background:#$colbg$ !important;color:#$colfield$ !important;border-color:#$colb1$ #$colb2$ #$colrb1$ !important;outline:2px solid #$colrb2$ !important}html input[type=button]:focus,html input[type=submit]:focus,html input[type=reset]:focus,html input[type=image]:focus,html button:focus{border-color:#$colb1$ #$colb2$ #$colrb2$ !important}html input[type=radio]{background:none !important;border-color:#$colb1$ !important;border-width:0 !important}html img[src],html input[type=image]{opacity:1}html img[src]:hover,html input[type=image]:hover{opacity:1}html,html body{scrollbar-base-color:#$colb1$ !important;scrollbar-face-color:#$colb2$ !important;scrollbar-shadow-color:#$colhint$ !important;scrollbar-darkshadow-color:#$colhint$ !important;scrollbar-track-color:#$colrb1$ !important;scrollbar-arrow-color:#$colrb2$ !important;scrollbar-3dlight-color:#$colb1$ !important}';\n      var styleNode = document.createElement('style');\n      styleNode.type = 'text/css';\n      styleNode.appendChild(document.createTextNode(css));\n      var head = document.head || document.getElementsByTagName('head')[0];\n      head.appendChild(styleNode);\n    })(window.document);\n    for (var i = 0, frame; frame = window.frames[i]; i++) {\n      try {\n        applyNightMode(frame);\n      } catch (e) {}\n    }\n  };\n\n  applyNightMode(window);\n\n})();\n"));
					}
				}
				if (webview3.getUrl().equals("file:///storage/emulated/0/WeekBrowser/bookmark.html")) {
					webview3.loadUrl(designbmlcache);
				}
			}
		}
		if (webview4.getProgress() > 11) {
			if (ibml41) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/10001.txt")) == 1) {
					webview4.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/10001.txt")));
				}
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/10002.txt")) == 1) {
					webview4.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/10002.txt")));
				}
				ibml41 = false;
				try{
					for (int i = 0; i < (int)(sitepermis.size()); i++) {
						if (webview4.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
							switch(sitepermis.get((int)i).get("th").toString()) {
								case "1": {
									webview4.loadUrl(_replaceInstructions("javascript:(function() {\n\n  var applyNightMode = function(window) {\n    (function(document) {\n      var css = 'html{background:#$colbg$ !important}html *{background:none !important;color:#$coltext$ !important;border-color:#$colbg$ !important;border-width:0 !important}html a,html a *{color:#$coladd$ !important;text-decoration:underline !important}html a:visited,html a:visited *,html a:active,html a:active *{color:#$colhint$ !important}html a:hover,html a:hover *{color:#$colhint$ !important;background:#$colbg$ !important}html input,html select,html button,html textarea{background:#$colbg$ !important;border:1px solid #$colb1$ !important;border-top-color:#$colb2$ !important;border-bottom-color:#$colb1$ !important}html input[type=button],html input[type=submit],html input[type=reset],html input[type=image],html button{border-top-color:#$colb1$ !important;border-bottom-color:#$colb2$ !important}html input:focus,html select:focus,html option:focus,html button:focus,html textarea:focus{background:#$colbg$ !important;color:#$colfield$ !important;border-color:#$colb1$ #$colb2$ #$colrb1$ !important;outline:2px solid #$colrb2$ !important}html input[type=button]:focus,html input[type=submit]:focus,html input[type=reset]:focus,html input[type=image]:focus,html button:focus{border-color:#$colb1$ #$colb2$ #$colrb2$ !important}html input[type=radio]{background:none !important;border-color:#$colb1$ !important;border-width:0 !important}html img[src],html input[type=image]{opacity:1}html img[src]:hover,html input[type=image]:hover{opacity:1}html,html body{scrollbar-base-color:#$colb1$ !important;scrollbar-face-color:#$colb2$ !important;scrollbar-shadow-color:#$colhint$ !important;scrollbar-darkshadow-color:#$colhint$ !important;scrollbar-track-color:#$colrb1$ !important;scrollbar-arrow-color:#$colrb2$ !important;scrollbar-3dlight-color:#$colb1$ !important}';\n      var styleNode = document.createElement('style');\n      styleNode.type = 'text/css';\n      styleNode.appendChild(document.createTextNode(css));\n      var head = document.head || document.getElementsByTagName('head')[0];\n      head.appendChild(styleNode);\n    })(window.document);\n    for (var i = 0, frame; frame = window.frames[i]; i++) {\n      try {\n        applyNightMode(frame);\n      } catch (e) {}\n    }\n  };\n\n  applyNightMode(window);\n\n})();\n"));
									break;
								}
								case "2": {
									if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/themepage.txt").equals("1")) {
										webview4.loadUrl(_replaceInstructions("javascript:(function() {\n\n  var applyNightMode = function(window) {\n    (function(document) {\n      var css = 'html{background:#$colbg$ !important}html *{background:none !important;color:#$coltext$ !important;border-color:#$colbg$ !important;border-width:0 !important}html a,html a *{color:#$coladd$ !important;text-decoration:underline !important}html a:visited,html a:visited *,html a:active,html a:active *{color:#$colhint$ !important}html a:hover,html a:hover *{color:#$colhint$ !important;background:#$colbg$ !important}html input,html select,html button,html textarea{background:#$colbg$ !important;border:1px solid #$colb1$ !important;border-top-color:#$colb2$ !important;border-bottom-color:#$colb1$ !important}html input[type=button],html input[type=submit],html input[type=reset],html input[type=image],html button{border-top-color:#$colb1$ !important;border-bottom-color:#$colb2$ !important}html input:focus,html select:focus,html option:focus,html button:focus,html textarea:focus{background:#$colbg$ !important;color:#$colfield$ !important;border-color:#$colb1$ #$colb2$ #$colrb1$ !important;outline:2px solid #$colrb2$ !important}html input[type=button]:focus,html input[type=submit]:focus,html input[type=reset]:focus,html input[type=image]:focus,html button:focus{border-color:#$colb1$ #$colb2$ #$colrb2$ !important}html input[type=radio]{background:none !important;border-color:#$colb1$ !important;border-width:0 !important}html img[src],html input[type=image]{opacity:1}html img[src]:hover,html input[type=image]:hover{opacity:1}html,html body{scrollbar-base-color:#$colb1$ !important;scrollbar-face-color:#$colb2$ !important;scrollbar-shadow-color:#$colhint$ !important;scrollbar-darkshadow-color:#$colhint$ !important;scrollbar-track-color:#$colrb1$ !important;scrollbar-arrow-color:#$colrb2$ !important;scrollbar-3dlight-color:#$colb1$ !important}';\n      var styleNode = document.createElement('style');\n      styleNode.type = 'text/css';\n      styleNode.appendChild(document.createTextNode(css));\n      var head = document.head || document.getElementsByTagName('head')[0];\n      head.appendChild(styleNode);\n    })(window.document);\n    for (var i = 0, frame; frame = window.frames[i]; i++) {\n      try {\n        applyNightMode(frame);\n      } catch (e) {}\n    }\n  };\n\n  applyNightMode(window);\n\n})();\n"));
									}
									break;
								}
								case "0": {
									 
									break;
								}
							}
							issu = true;
						}
					}
					if (!issu) {
						if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/themepage.txt").equals("1")) {
							webview4.loadUrl(_replaceInstructions("javascript:(function() {\n\n  var applyNightMode = function(window) {\n    (function(document) {\n      var css = 'html{background:#$colbg$ !important}html *{background:none !important;color:#$coltext$ !important;border-color:#$colbg$ !important;border-width:0 !important}html a,html a *{color:#$coladd$ !important;text-decoration:underline !important}html a:visited,html a:visited *,html a:active,html a:active *{color:#$colhint$ !important}html a:hover,html a:hover *{color:#$colhint$ !important;background:#$colbg$ !important}html input,html select,html button,html textarea{background:#$colbg$ !important;border:1px solid #$colb1$ !important;border-top-color:#$colb2$ !important;border-bottom-color:#$colb1$ !important}html input[type=button],html input[type=submit],html input[type=reset],html input[type=image],html button{border-top-color:#$colb1$ !important;border-bottom-color:#$colb2$ !important}html input:focus,html select:focus,html option:focus,html button:focus,html textarea:focus{background:#$colbg$ !important;color:#$colfield$ !important;border-color:#$colb1$ #$colb2$ #$colrb1$ !important;outline:2px solid #$colrb2$ !important}html input[type=button]:focus,html input[type=submit]:focus,html input[type=reset]:focus,html input[type=image]:focus,html button:focus{border-color:#$colb1$ #$colb2$ #$colrb2$ !important}html input[type=radio]{background:none !important;border-color:#$colb1$ !important;border-width:0 !important}html img[src],html input[type=image]{opacity:1}html img[src]:hover,html input[type=image]:hover{opacity:1}html,html body{scrollbar-base-color:#$colb1$ !important;scrollbar-face-color:#$colb2$ !important;scrollbar-shadow-color:#$colhint$ !important;scrollbar-darkshadow-color:#$colhint$ !important;scrollbar-track-color:#$colrb1$ !important;scrollbar-arrow-color:#$colrb2$ !important;scrollbar-3dlight-color:#$colb1$ !important}';\n      var styleNode = document.createElement('style');\n      styleNode.type = 'text/css';\n      styleNode.appendChild(document.createTextNode(css));\n      var head = document.head || document.getElementsByTagName('head')[0];\n      head.appendChild(styleNode);\n    })(window.document);\n    for (var i = 0, frame; frame = window.frames[i]; i++) {\n      try {\n        applyNightMode(frame);\n      } catch (e) {}\n    }\n  };\n\n  applyNightMode(window);\n\n})();\n"));
						}
					}
					issu = false;
				}catch(Exception e){
					issu = false;
					if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/themepage.txt").equals("1")) {
						webview4.loadUrl(_replaceInstructions("javascript:(function() {\n\n  var applyNightMode = function(window) {\n    (function(document) {\n      var css = 'html{background:#$colbg$ !important}html *{background:none !important;color:#$coltext$ !important;border-color:#$colbg$ !important;border-width:0 !important}html a,html a *{color:#$coladd$ !important;text-decoration:underline !important}html a:visited,html a:visited *,html a:active,html a:active *{color:#$colhint$ !important}html a:hover,html a:hover *{color:#$colhint$ !important;background:#$colbg$ !important}html input,html select,html button,html textarea{background:#$colbg$ !important;border:1px solid #$colb1$ !important;border-top-color:#$colb2$ !important;border-bottom-color:#$colb1$ !important}html input[type=button],html input[type=submit],html input[type=reset],html input[type=image],html button{border-top-color:#$colb1$ !important;border-bottom-color:#$colb2$ !important}html input:focus,html select:focus,html option:focus,html button:focus,html textarea:focus{background:#$colbg$ !important;color:#$colfield$ !important;border-color:#$colb1$ #$colb2$ #$colrb1$ !important;outline:2px solid #$colrb2$ !important}html input[type=button]:focus,html input[type=submit]:focus,html input[type=reset]:focus,html input[type=image]:focus,html button:focus{border-color:#$colb1$ #$colb2$ #$colrb2$ !important}html input[type=radio]{background:none !important;border-color:#$colb1$ !important;border-width:0 !important}html img[src],html input[type=image]{opacity:1}html img[src]:hover,html input[type=image]:hover{opacity:1}html,html body{scrollbar-base-color:#$colb1$ !important;scrollbar-face-color:#$colb2$ !important;scrollbar-shadow-color:#$colhint$ !important;scrollbar-darkshadow-color:#$colhint$ !important;scrollbar-track-color:#$colrb1$ !important;scrollbar-arrow-color:#$colrb2$ !important;scrollbar-3dlight-color:#$colb1$ !important}';\n      var styleNode = document.createElement('style');\n      styleNode.type = 'text/css';\n      styleNode.appendChild(document.createTextNode(css));\n      var head = document.head || document.getElementsByTagName('head')[0];\n      head.appendChild(styleNode);\n    })(window.document);\n    for (var i = 0, frame; frame = window.frames[i]; i++) {\n      try {\n        applyNightMode(frame);\n      } catch (e) {}\n    }\n  };\n\n  applyNightMode(window);\n\n})();\n"));
					}
				}
				if (webview4.getUrl().equals("file:///storage/emulated/0/WeekBrowser/bookmark.html")) {
					webview4.loadUrl(designbmlcache);
				}
			}
		}
		if (webview5.getProgress() > 11) {
			if (ibml51) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/10001.txt")) == 1) {
					webview5.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/10001.txt")));
				}
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/10002.txt")) == 1) {
					webview5.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/10002.txt")));
				}
				ibml51 = false;
				try{
					for (int i = 0; i < (int)(sitepermis.size()); i++) {
						if (webview5.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
							switch(sitepermis.get((int)i).get("th").toString()) {
								case "1": {
									webview5.loadUrl(_replaceInstructions("javascript:(function() {\n\n  var applyNightMode = function(window) {\n    (function(document) {\n      var css = 'html{background:#$colbg$ !important}html *{background:none !important;color:#$coltext$ !important;border-color:#$colbg$ !important;border-width:0 !important}html a,html a *{color:#$coladd$ !important;text-decoration:underline !important}html a:visited,html a:visited *,html a:active,html a:active *{color:#$colhint$ !important}html a:hover,html a:hover *{color:#$colhint$ !important;background:#$colbg$ !important}html input,html select,html button,html textarea{background:#$colbg$ !important;border:1px solid #$colb1$ !important;border-top-color:#$colb2$ !important;border-bottom-color:#$colb1$ !important}html input[type=button],html input[type=submit],html input[type=reset],html input[type=image],html button{border-top-color:#$colb1$ !important;border-bottom-color:#$colb2$ !important}html input:focus,html select:focus,html option:focus,html button:focus,html textarea:focus{background:#$colbg$ !important;color:#$colfield$ !important;border-color:#$colb1$ #$colb2$ #$colrb1$ !important;outline:2px solid #$colrb2$ !important}html input[type=button]:focus,html input[type=submit]:focus,html input[type=reset]:focus,html input[type=image]:focus,html button:focus{border-color:#$colb1$ #$colb2$ #$colrb2$ !important}html input[type=radio]{background:none !important;border-color:#$colb1$ !important;border-width:0 !important}html img[src],html input[type=image]{opacity:1}html img[src]:hover,html input[type=image]:hover{opacity:1}html,html body{scrollbar-base-color:#$colb1$ !important;scrollbar-face-color:#$colb2$ !important;scrollbar-shadow-color:#$colhint$ !important;scrollbar-darkshadow-color:#$colhint$ !important;scrollbar-track-color:#$colrb1$ !important;scrollbar-arrow-color:#$colrb2$ !important;scrollbar-3dlight-color:#$colb1$ !important}';\n      var styleNode = document.createElement('style');\n      styleNode.type = 'text/css';\n      styleNode.appendChild(document.createTextNode(css));\n      var head = document.head || document.getElementsByTagName('head')[0];\n      head.appendChild(styleNode);\n    })(window.document);\n    for (var i = 0, frame; frame = window.frames[i]; i++) {\n      try {\n        applyNightMode(frame);\n      } catch (e) {}\n    }\n  };\n\n  applyNightMode(window);\n\n})();\n"));
									break;
								}
								case "2": {
									if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/themepage.txt").equals("1")) {
										webview5.loadUrl(_replaceInstructions("javascript:(function() {\n\n  var applyNightMode = function(window) {\n    (function(document) {\n      var css = 'html{background:#$colbg$ !important}html *{background:none !important;color:#$coltext$ !important;border-color:#$colbg$ !important;border-width:0 !important}html a,html a *{color:#$coladd$ !important;text-decoration:underline !important}html a:visited,html a:visited *,html a:active,html a:active *{color:#$colhint$ !important}html a:hover,html a:hover *{color:#$colhint$ !important;background:#$colbg$ !important}html input,html select,html button,html textarea{background:#$colbg$ !important;border:1px solid #$colb1$ !important;border-top-color:#$colb2$ !important;border-bottom-color:#$colb1$ !important}html input[type=button],html input[type=submit],html input[type=reset],html input[type=image],html button{border-top-color:#$colb1$ !important;border-bottom-color:#$colb2$ !important}html input:focus,html select:focus,html option:focus,html button:focus,html textarea:focus{background:#$colbg$ !important;color:#$colfield$ !important;border-color:#$colb1$ #$colb2$ #$colrb1$ !important;outline:2px solid #$colrb2$ !important}html input[type=button]:focus,html input[type=submit]:focus,html input[type=reset]:focus,html input[type=image]:focus,html button:focus{border-color:#$colb1$ #$colb2$ #$colrb2$ !important}html input[type=radio]{background:none !important;border-color:#$colb1$ !important;border-width:0 !important}html img[src],html input[type=image]{opacity:1}html img[src]:hover,html input[type=image]:hover{opacity:1}html,html body{scrollbar-base-color:#$colb1$ !important;scrollbar-face-color:#$colb2$ !important;scrollbar-shadow-color:#$colhint$ !important;scrollbar-darkshadow-color:#$colhint$ !important;scrollbar-track-color:#$colrb1$ !important;scrollbar-arrow-color:#$colrb2$ !important;scrollbar-3dlight-color:#$colb1$ !important}';\n      var styleNode = document.createElement('style');\n      styleNode.type = 'text/css';\n      styleNode.appendChild(document.createTextNode(css));\n      var head = document.head || document.getElementsByTagName('head')[0];\n      head.appendChild(styleNode);\n    })(window.document);\n    for (var i = 0, frame; frame = window.frames[i]; i++) {\n      try {\n        applyNightMode(frame);\n      } catch (e) {}\n    }\n  };\n\n  applyNightMode(window);\n\n})();\n"));
									}
									break;
								}
								case "0": {
									 
									break;
								}
							}
							issu = true;
						}
					}
					if (!issu) {
						if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/themepage.txt").equals("1")) {
							webview5.loadUrl(_replaceInstructions("javascript:(function() {\n\n  var applyNightMode = function(window) {\n    (function(document) {\n      var css = 'html{background:#$colbg$ !important}html *{background:none !important;color:#$coltext$ !important;border-color:#$colbg$ !important;border-width:0 !important}html a,html a *{color:#$coladd$ !important;text-decoration:underline !important}html a:visited,html a:visited *,html a:active,html a:active *{color:#$colhint$ !important}html a:hover,html a:hover *{color:#$colhint$ !important;background:#$colbg$ !important}html input,html select,html button,html textarea{background:#$colbg$ !important;border:1px solid #$colb1$ !important;border-top-color:#$colb2$ !important;border-bottom-color:#$colb1$ !important}html input[type=button],html input[type=submit],html input[type=reset],html input[type=image],html button{border-top-color:#$colb1$ !important;border-bottom-color:#$colb2$ !important}html input:focus,html select:focus,html option:focus,html button:focus,html textarea:focus{background:#$colbg$ !important;color:#$colfield$ !important;border-color:#$colb1$ #$colb2$ #$colrb1$ !important;outline:2px solid #$colrb2$ !important}html input[type=button]:focus,html input[type=submit]:focus,html input[type=reset]:focus,html input[type=image]:focus,html button:focus{border-color:#$colb1$ #$colb2$ #$colrb2$ !important}html input[type=radio]{background:none !important;border-color:#$colb1$ !important;border-width:0 !important}html img[src],html input[type=image]{opacity:1}html img[src]:hover,html input[type=image]:hover{opacity:1}html,html body{scrollbar-base-color:#$colb1$ !important;scrollbar-face-color:#$colb2$ !important;scrollbar-shadow-color:#$colhint$ !important;scrollbar-darkshadow-color:#$colhint$ !important;scrollbar-track-color:#$colrb1$ !important;scrollbar-arrow-color:#$colrb2$ !important;scrollbar-3dlight-color:#$colb1$ !important}';\n      var styleNode = document.createElement('style');\n      styleNode.type = 'text/css';\n      styleNode.appendChild(document.createTextNode(css));\n      var head = document.head || document.getElementsByTagName('head')[0];\n      head.appendChild(styleNode);\n    })(window.document);\n    for (var i = 0, frame; frame = window.frames[i]; i++) {\n      try {\n        applyNightMode(frame);\n      } catch (e) {}\n    }\n  };\n\n  applyNightMode(window);\n\n})();\n"));
						}
					}
					issu = false;
				}catch(Exception e){
					issu = false;
					if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/themepage.txt").equals("1")) {
						webview5.loadUrl(_replaceInstructions("javascript:(function() {\n\n  var applyNightMode = function(window) {\n    (function(document) {\n      var css = 'html{background:#$colbg$ !important}html *{background:none !important;color:#$coltext$ !important;border-color:#$colbg$ !important;border-width:0 !important}html a,html a *{color:#$coladd$ !important;text-decoration:underline !important}html a:visited,html a:visited *,html a:active,html a:active *{color:#$colhint$ !important}html a:hover,html a:hover *{color:#$colhint$ !important;background:#$colbg$ !important}html input,html select,html button,html textarea{background:#$colbg$ !important;border:1px solid #$colb1$ !important;border-top-color:#$colb2$ !important;border-bottom-color:#$colb1$ !important}html input[type=button],html input[type=submit],html input[type=reset],html input[type=image],html button{border-top-color:#$colb1$ !important;border-bottom-color:#$colb2$ !important}html input:focus,html select:focus,html option:focus,html button:focus,html textarea:focus{background:#$colbg$ !important;color:#$colfield$ !important;border-color:#$colb1$ #$colb2$ #$colrb1$ !important;outline:2px solid #$colrb2$ !important}html input[type=button]:focus,html input[type=submit]:focus,html input[type=reset]:focus,html input[type=image]:focus,html button:focus{border-color:#$colb1$ #$colb2$ #$colrb2$ !important}html input[type=radio]{background:none !important;border-color:#$colb1$ !important;border-width:0 !important}html img[src],html input[type=image]{opacity:1}html img[src]:hover,html input[type=image]:hover{opacity:1}html,html body{scrollbar-base-color:#$colb1$ !important;scrollbar-face-color:#$colb2$ !important;scrollbar-shadow-color:#$colhint$ !important;scrollbar-darkshadow-color:#$colhint$ !important;scrollbar-track-color:#$colrb1$ !important;scrollbar-arrow-color:#$colrb2$ !important;scrollbar-3dlight-color:#$colb1$ !important}';\n      var styleNode = document.createElement('style');\n      styleNode.type = 'text/css';\n      styleNode.appendChild(document.createTextNode(css));\n      var head = document.head || document.getElementsByTagName('head')[0];\n      head.appendChild(styleNode);\n    })(window.document);\n    for (var i = 0, frame; frame = window.frames[i]; i++) {\n      try {\n        applyNightMode(frame);\n      } catch (e) {}\n    }\n  };\n\n  applyNightMode(window);\n\n})();\n"));
					}
				}
				if (webview5.getUrl().equals("file:///storage/emulated/0/WeekBrowser/bookmark.html")) {
					webview5.loadUrl(designbmlcache);
				}
			}
		}
		if (webview6.getProgress() > 11) {
			if (ibml61) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/10001.txt")) == 1) {
					webview6.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/10001.txt")));
				}
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/10002.txt")) == 1) {
					webview6.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/10002.txt")));
				}
				ibml61 = false;
				try{
					for (int i = 0; i < (int)(sitepermis.size()); i++) {
						if (webview6.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
							switch(sitepermis.get((int)i).get("th").toString()) {
								case "1": {
									webview6.loadUrl(_replaceInstructions("javascript:(function() {\n\n  var applyNightMode = function(window) {\n    (function(document) {\n      var css = 'html{background:#$colbg$ !important}html *{background:none !important;color:#$coltext$ !important;border-color:#$colbg$ !important;border-width:0 !important}html a,html a *{color:#$coladd$ !important;text-decoration:underline !important}html a:visited,html a:visited *,html a:active,html a:active *{color:#$colhint$ !important}html a:hover,html a:hover *{color:#$colhint$ !important;background:#$colbg$ !important}html input,html select,html button,html textarea{background:#$colbg$ !important;border:1px solid #$colb1$ !important;border-top-color:#$colb2$ !important;border-bottom-color:#$colb1$ !important}html input[type=button],html input[type=submit],html input[type=reset],html input[type=image],html button{border-top-color:#$colb1$ !important;border-bottom-color:#$colb2$ !important}html input:focus,html select:focus,html option:focus,html button:focus,html textarea:focus{background:#$colbg$ !important;color:#$colfield$ !important;border-color:#$colb1$ #$colb2$ #$colrb1$ !important;outline:2px solid #$colrb2$ !important}html input[type=button]:focus,html input[type=submit]:focus,html input[type=reset]:focus,html input[type=image]:focus,html button:focus{border-color:#$colb1$ #$colb2$ #$colrb2$ !important}html input[type=radio]{background:none !important;border-color:#$colb1$ !important;border-width:0 !important}html img[src],html input[type=image]{opacity:1}html img[src]:hover,html input[type=image]:hover{opacity:1}html,html body{scrollbar-base-color:#$colb1$ !important;scrollbar-face-color:#$colb2$ !important;scrollbar-shadow-color:#$colhint$ !important;scrollbar-darkshadow-color:#$colhint$ !important;scrollbar-track-color:#$colrb1$ !important;scrollbar-arrow-color:#$colrb2$ !important;scrollbar-3dlight-color:#$colb1$ !important}';\n      var styleNode = document.createElement('style');\n      styleNode.type = 'text/css';\n      styleNode.appendChild(document.createTextNode(css));\n      var head = document.head || document.getElementsByTagName('head')[0];\n      head.appendChild(styleNode);\n    })(window.document);\n    for (var i = 0, frame; frame = window.frames[i]; i++) {\n      try {\n        applyNightMode(frame);\n      } catch (e) {}\n    }\n  };\n\n  applyNightMode(window);\n\n})();\n"));
									break;
								}
								case "2": {
									if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/themepage.txt").equals("1")) {
										webview6.loadUrl(_replaceInstructions("javascript:(function() {\n\n  var applyNightMode = function(window) {\n    (function(document) {\n      var css = 'html{background:#$colbg$ !important}html *{background:none !important;color:#$coltext$ !important;border-color:#$colbg$ !important;border-width:0 !important}html a,html a *{color:#$coladd$ !important;text-decoration:underline !important}html a:visited,html a:visited *,html a:active,html a:active *{color:#$colhint$ !important}html a:hover,html a:hover *{color:#$colhint$ !important;background:#$colbg$ !important}html input,html select,html button,html textarea{background:#$colbg$ !important;border:1px solid #$colb1$ !important;border-top-color:#$colb2$ !important;border-bottom-color:#$colb1$ !important}html input[type=button],html input[type=submit],html input[type=reset],html input[type=image],html button{border-top-color:#$colb1$ !important;border-bottom-color:#$colb2$ !important}html input:focus,html select:focus,html option:focus,html button:focus,html textarea:focus{background:#$colbg$ !important;color:#$colfield$ !important;border-color:#$colb1$ #$colb2$ #$colrb1$ !important;outline:2px solid #$colrb2$ !important}html input[type=button]:focus,html input[type=submit]:focus,html input[type=reset]:focus,html input[type=image]:focus,html button:focus{border-color:#$colb1$ #$colb2$ #$colrb2$ !important}html input[type=radio]{background:none !important;border-color:#$colb1$ !important;border-width:0 !important}html img[src],html input[type=image]{opacity:1}html img[src]:hover,html input[type=image]:hover{opacity:1}html,html body{scrollbar-base-color:#$colb1$ !important;scrollbar-face-color:#$colb2$ !important;scrollbar-shadow-color:#$colhint$ !important;scrollbar-darkshadow-color:#$colhint$ !important;scrollbar-track-color:#$colrb1$ !important;scrollbar-arrow-color:#$colrb2$ !important;scrollbar-3dlight-color:#$colb1$ !important}';\n      var styleNode = document.createElement('style');\n      styleNode.type = 'text/css';\n      styleNode.appendChild(document.createTextNode(css));\n      var head = document.head || document.getElementsByTagName('head')[0];\n      head.appendChild(styleNode);\n    })(window.document);\n    for (var i = 0, frame; frame = window.frames[i]; i++) {\n      try {\n        applyNightMode(frame);\n      } catch (e) {}\n    }\n  };\n\n  applyNightMode(window);\n\n})();\n"));
									}
									break;
								}
								case "0": {
									 
									break;
								}
							}
							issu = true;
						}
					}
					if (!issu) {
						if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/themepage.txt").equals("1")) {
							webview6.loadUrl(_replaceInstructions("javascript:(function() {\n\n  var applyNightMode = function(window) {\n    (function(document) {\n      var css = 'html{background:#$colbg$ !important}html *{background:none !important;color:#$coltext$ !important;border-color:#$colbg$ !important;border-width:0 !important}html a,html a *{color:#$coladd$ !important;text-decoration:underline !important}html a:visited,html a:visited *,html a:active,html a:active *{color:#$colhint$ !important}html a:hover,html a:hover *{color:#$colhint$ !important;background:#$colbg$ !important}html input,html select,html button,html textarea{background:#$colbg$ !important;border:1px solid #$colb1$ !important;border-top-color:#$colb2$ !important;border-bottom-color:#$colb1$ !important}html input[type=button],html input[type=submit],html input[type=reset],html input[type=image],html button{border-top-color:#$colb1$ !important;border-bottom-color:#$colb2$ !important}html input:focus,html select:focus,html option:focus,html button:focus,html textarea:focus{background:#$colbg$ !important;color:#$colfield$ !important;border-color:#$colb1$ #$colb2$ #$colrb1$ !important;outline:2px solid #$colrb2$ !important}html input[type=button]:focus,html input[type=submit]:focus,html input[type=reset]:focus,html input[type=image]:focus,html button:focus{border-color:#$colb1$ #$colb2$ #$colrb2$ !important}html input[type=radio]{background:none !important;border-color:#$colb1$ !important;border-width:0 !important}html img[src],html input[type=image]{opacity:1}html img[src]:hover,html input[type=image]:hover{opacity:1}html,html body{scrollbar-base-color:#$colb1$ !important;scrollbar-face-color:#$colb2$ !important;scrollbar-shadow-color:#$colhint$ !important;scrollbar-darkshadow-color:#$colhint$ !important;scrollbar-track-color:#$colrb1$ !important;scrollbar-arrow-color:#$colrb2$ !important;scrollbar-3dlight-color:#$colb1$ !important}';\n      var styleNode = document.createElement('style');\n      styleNode.type = 'text/css';\n      styleNode.appendChild(document.createTextNode(css));\n      var head = document.head || document.getElementsByTagName('head')[0];\n      head.appendChild(styleNode);\n    })(window.document);\n    for (var i = 0, frame; frame = window.frames[i]; i++) {\n      try {\n        applyNightMode(frame);\n      } catch (e) {}\n    }\n  };\n\n  applyNightMode(window);\n\n})();\n"));
						}
					}
					issu = false;
				}catch(Exception e){
					issu = false;
					if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/themepage.txt").equals("1")) {
						webview6.loadUrl(_replaceInstructions("javascript:(function() {\n\n  var applyNightMode = function(window) {\n    (function(document) {\n      var css = 'html{background:#$colbg$ !important}html *{background:none !important;color:#$coltext$ !important;border-color:#$colbg$ !important;border-width:0 !important}html a,html a *{color:#$coladd$ !important;text-decoration:underline !important}html a:visited,html a:visited *,html a:active,html a:active *{color:#$colhint$ !important}html a:hover,html a:hover *{color:#$colhint$ !important;background:#$colbg$ !important}html input,html select,html button,html textarea{background:#$colbg$ !important;border:1px solid #$colb1$ !important;border-top-color:#$colb2$ !important;border-bottom-color:#$colb1$ !important}html input[type=button],html input[type=submit],html input[type=reset],html input[type=image],html button{border-top-color:#$colb1$ !important;border-bottom-color:#$colb2$ !important}html input:focus,html select:focus,html option:focus,html button:focus,html textarea:focus{background:#$colbg$ !important;color:#$colfield$ !important;border-color:#$colb1$ #$colb2$ #$colrb1$ !important;outline:2px solid #$colrb2$ !important}html input[type=button]:focus,html input[type=submit]:focus,html input[type=reset]:focus,html input[type=image]:focus,html button:focus{border-color:#$colb1$ #$colb2$ #$colrb2$ !important}html input[type=radio]{background:none !important;border-color:#$colb1$ !important;border-width:0 !important}html img[src],html input[type=image]{opacity:1}html img[src]:hover,html input[type=image]:hover{opacity:1}html,html body{scrollbar-base-color:#$colb1$ !important;scrollbar-face-color:#$colb2$ !important;scrollbar-shadow-color:#$colhint$ !important;scrollbar-darkshadow-color:#$colhint$ !important;scrollbar-track-color:#$colrb1$ !important;scrollbar-arrow-color:#$colrb2$ !important;scrollbar-3dlight-color:#$colb1$ !important}';\n      var styleNode = document.createElement('style');\n      styleNode.type = 'text/css';\n      styleNode.appendChild(document.createTextNode(css));\n      var head = document.head || document.getElementsByTagName('head')[0];\n      head.appendChild(styleNode);\n    })(window.document);\n    for (var i = 0, frame; frame = window.frames[i]; i++) {\n      try {\n        applyNightMode(frame);\n      } catch (e) {}\n    }\n  };\n\n  applyNightMode(window);\n\n})();\n"));
					}
				}
				if (webview6.getUrl().equals("file:///storage/emulated/0/WeekBrowser/bookmark.html")) {
					webview6.loadUrl(designbmlcache);
				}
			}
		}
	}
	
	
	public String _block() {
		return ("javascript:(function() {     var elements = document.querySelectorAll('*');     var elementsToRemove = [];     var patterns = [".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Blockad/patterns.txt").concat("];     var exceptions = [".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Blockad/exceptions.txt").concat("];      elements.forEach(function(element) {         var elementId = element.id.toLowerCase();         var elementSrc = element.getAttribute('src') ? element.getAttribute('src').toLowerCase() : '';         var elementHref = element.getAttribute('href') ? element.getAttribute('href').toLowerCase() : '';         var elementTitle = element.getAttribute('title') ? element.getAttribute('title').toLowerCase() : '';         var isAdContent = false;         var isExceptionFound = false;          if ((elementSrc.length > 0 && elementSrc.length <= 4) ||             (elementHref.length > 0 && elementHref.length <= 4) ||             (elementTitle.length > 0 && elementTitle.length <= 4)) {             elementsToRemove.push(element);         } else {             patterns.forEach(function(pattern) {                 if ((new RegExp(\"\\\\b\" + pattern.source + \"\\\\b\")).test(elementId) ||                     (new RegExp(\"\\\\b\" + pattern.source + \"\\\\b\")).test(elementSrc) ||                     (new RegExp(\"\\\\b\" + pattern.source + \"\\\\b\")).test(elementHref) ||                     (new RegExp(\"\\\\b\" + pattern.source + \"\\\\b\")).test(elementTitle)) {                     exceptions.forEach(function(ex) {                         if ((new RegExp(\"\\\\b\" + ex + \"\\\\b\")).test(elementId) ||                             (new RegExp(\"\\\\b\" + ex + \"\\\\b\")).test(elementSrc) ||                             (new RegExp(\"\\\\b\" + ex + \"\\\\b\")).test(elementHref) ||                             (new RegExp(\"\\\\b\" + ex + \"\\\\b\")).test(elementTitle)) {                             isExceptionFound = true;                         }                     });                      if (!isExceptionFound) {                         isAdContent = true;                     }                 }             });              if (isAdContent) {                 elementsToRemove.push(element);             }         }     });      elementsToRemove.forEach(function(element) {         element.remove();     });      var elements2 = document.querySelectorAll('".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Blockad/legacyblock.txt").concat("');     elements2.forEach(function(elem) {         elem.remove();     }); })(); ")))))));
	}
	
	
	public void _extrb() {
	}
	private String getFileExtensionFromMimeType(String mimeType) {
		    String[] parts = mimeType.split("/");
		    if (parts.length == 2) {
			        return parts[1];
			    }
		    return null;
	}
	
	private ValueCallback<Uri> mUploadMessage;
	public ValueCallback<Uri[]> uploadMessage;
	public static final int REQUEST_SELECT_FILE = 100;
	
	private final static int FILECHOOSER_RESULTCODE = 1;
	
	private void openInOtherApps(String url) {
		    Intent other = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
		    PackageManager packageManager = getPackageManager();
		    List<ResolveInfo> resolveInfoList = packageManager.queryIntentActivities(other, 0);
		
		    List<Intent> targetIntents = new ArrayList<>();
		    for (ResolveInfo resolveInfo : resolveInfoList) {
			        String packageName = resolveInfo.activityInfo.packageName;
			        if (!getPackageName().toString().equals(packageName)) {
				            Intent targetIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
				            targetIntent.setComponent(new ComponentName(packageName, resolveInfo.activityInfo.name));
				            targetIntents.add(targetIntent);
				        }
			    }
		
		    if (!targetIntents.isEmpty()) {
			        Intent chooserIntent = Intent.createChooser(targetIntents.remove(0), "Відкрити через...");
			        chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, targetIntents.toArray(new Parcelable[0]));
			        startActivity(chooserIntent);
			    } else {
			        Toast.makeText(this, "Немає доступних програм для відкриття цього сайту", Toast.LENGTH_SHORT).show();
			        
			        // Можна показати повідомлення користувачу або інший відповідний крок
			    }
	}
	
	
	{
	}
	
	
	public void _buttonsizeset() {
		back.getLayoutParams().width = (int) ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density * 1.27));
		back.getLayoutParams().height = (int) (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density);
		back.setTextSize( Float.parseFloat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) / 2.5f);
		back.requestLayout();
		
		pgup.getLayoutParams().width = (int) ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density * 1.27));
		pgup.getLayoutParams().height = (int) (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density);
		pgup.setTextSize( Float.parseFloat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) / 2.5f);
		pgup.requestLayout();
		
		forward.getLayoutParams().width = (int) ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density * 1.27));
		forward.getLayoutParams().height = (int) (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density);
		forward.setTextSize( Float.parseFloat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) / 2.5f);
		forward.requestLayout();
		
		pgdn.getLayoutParams().width = (int) ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density * 1.27));
		pgdn.getLayoutParams().height = (int) (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density);
		pgdn.setTextSize( Float.parseFloat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) / 2.5f);
		pgdn.requestLayout();
		
		//════════
		
		bookmarks.getLayoutParams().width = (int) ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density * 1.27));
		bookmarks.getLayoutParams().height = (int) (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density);
		bookmarks.setTextSize( Float.parseFloat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) / 2.5f);
		bookmarks.requestLayout();
		
		histori.getLayoutParams().width = (int) ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density * 1.27));
		histori.getLayoutParams().height = (int) (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density);
		histori.setTextSize( Float.parseFloat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) / 2.5f);
		histori.requestLayout();
		
		home.getLayoutParams().width = (int) ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density * 1.27));
		home.getLayoutParams().height = (int) (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density);
		home.setTextSize( Float.parseFloat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) / 2.5f);
		home.requestLayout();
		
		tabs.getLayoutParams().width = (int) ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density * 1.27));
		tabs.getLayoutParams().height = (int) (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density);
		tabs.setTextSize( Float.parseFloat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) / 2.5f);
		tabs.requestLayout();
		
		//════════════════════════════════
		
		dual.getLayoutParams().width = (int) ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density * 1.27));
		dual.getLayoutParams().height = (int) (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density);
		dual.setTextSize( Float.parseFloat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) / 2.5f);
		dual.requestLayout();
		
		skipvideo.getLayoutParams().width = (int) ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density * 1.27));
		skipvideo.getLayoutParams().height = (int) (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density);
		skipvideo.setTextSize( Float.parseFloat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) / 2.5f);
		skipvideo.requestLayout();
		
		pagesearch.getLayoutParams().width = (int) ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density * 1.27));
		pagesearch.getLayoutParams().height = (int) (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density);
		pagesearch.setTextSize( Float.parseFloat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) / 2.5f);
		pagesearch.requestLayout();
		
		coordinates.getLayoutParams().width = (int) ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density * 1.27));
		coordinates.getLayoutParams().height = (int) (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density);
		coordinates.setTextSize( Float.parseFloat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) / 2.5f);
		coordinates.requestLayout();
		
		//════════
		
		/*addshortcut.getLayoutParams().width = (int) ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density * 1.27));
addshortcut.getLayoutParams().height = (int) (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density);
addshortcut.setTextSize( Float.parseFloat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) / 2.5f);
addshortcut.requestLayout();*/
		
		hide.getLayoutParams().width = (int) ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density * 1.27));
		hide.getLayoutParams().height = (int) (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density);
		hide.setTextSize( Float.parseFloat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) / 2.5f);
		hide.requestLayout();
		
		openpanel.getLayoutParams().width = (int) ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density * 1.27));
		openpanel.getLayoutParams().height = (int) (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density);
		openpanel.setTextSize( Float.parseFloat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) / 2.5f);
		openpanel.requestLayout();
		
		refresh.getLayoutParams().width = (int) ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density * 1.27));
		refresh.getLayoutParams().height = (int) (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density);
		refresh.setTextSize( Float.parseFloat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) / 2.5f);
		refresh.requestLayout();
		
		 button1.getLayoutParams().width = (int) ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density * 1.27));
		button1.getLayoutParams().height = (int) (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density);
		button1.setTextSize( Float.parseFloat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) / 2.5f);
		button1.requestLayout();
		
		button3.getLayoutParams().width = (int) ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density * 1.27));
		button3.getLayoutParams().height = (int) (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density);
		button3.setTextSize( Float.parseFloat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) / 2.5f);
		button3.requestLayout();
		
		widthp1.getLayoutParams().width = (int) ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density * 1.27));
		widthp1.getLayoutParams().height = (int) (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density);
		widthp1.setTextSize( Float.parseFloat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) / 2.5f);
		widthp1.requestLayout();
		
		widthm1.getLayoutParams().width = (int) ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density * 1.27));
		widthm1.getLayoutParams().height = (int) (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density);
		widthm1.setTextSize( Float.parseFloat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) / 2.5f);
		widthm1.requestLayout();
		
		
		heightp1.getLayoutParams().width = (int) ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density * 1.27));
		heightp1.getLayoutParams().height = (int) (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density);
		heightp1.setTextSize( Float.parseFloat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) / 2.5f);
		heightp1.requestLayout();
		
		heightm1.getLayoutParams().width = (int) ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density * 1.27));
		heightm1.getLayoutParams().height = (int) (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density);
		heightm1.setTextSize( Float.parseFloat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) / 2.5f);
		heightm1.requestLayout();
		
		
		
		
	}
	
	
	public void _swipe() {
		autocomplete1.setOnFocusChangeListener(new OnFocusChangeListener() { @Override public void onFocusChange(View v, boolean hasFocus) {
						  if (hasFocus) { 
					
					focused = true;
						} 
						 else { 
					focused = false;
						} } });
		timer = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						toggleKeyboardListener();
						if ((kbd && focused) && selected) {
							((EditText)autocomplete1).setMaxLines((int)5);
						}
						else {
							((EditText)autocomplete1).setMaxLines((int)1);
						}
						switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
							case "0": {
								if (kbd && focused) {
									if (!selected) {
										((EditText)autocomplete1).selectAll();
										selected = true;
									}
								}
								else {
									autocomplete1.setText(webview1.getUrl());
									selected = false;
								}
								break;
							}
							case "1": {
								if (kbd && focused) {
									if (!selected) {
										((EditText)autocomplete1).selectAll();
										selected = true;
									}
								}
								else {
									autocomplete1.setText(webview2.getUrl());
									
									selected = false;
								}
								break;
							}
							case "2": {
								if (kbd && focused) {
									if (!selected) {
										((EditText)autocomplete1).selectAll();
										selected = true;
									}
								}
								else {
									autocomplete1.setText(webview3.getUrl());
									
									selected = false;
								}
								break;
							}
							case "3": {
								if (kbd && focused) {
									if (!selected) {
										((EditText)autocomplete1).selectAll();
										selected = true;
									}
								}
								else {
									autocomplete1.setText(webview4.getUrl());
									
									selected = false;
								}
								break;
							}
							case "4": {
								if (kbd && focused) {
									if (!selected) {
										((EditText)autocomplete1).selectAll();
										selected = true;
									}
								}
								else {
									autocomplete1.setText(webview5.getUrl());
									
									selected = false;
								}
								break;
							}
							case "5": {
								if (kbd && focused) {
									if (!selected) {
										((EditText)autocomplete1).selectAll();
										selected = true;
									}
								}
								else {
									autocomplete1.setText(webview6.getUrl());
									
									selected = false;
								}
								break;
							}
						}
						if (kbd && !focused) {
							linear1.setVisibility(View.GONE);
							
							linear5.setVisibility(View.GONE);
							getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
							        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
							        | View.SYSTEM_UI_FLAG_IMMERSIVE);
							isshowpan = false;
						}
						else {
							if (!isshowpan) {
								linear1.setVisibility(View.VISIBLE);
								if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/NavPan.txt").equals("1")) {
									linear5.setVisibility(View.VISIBLE);
								}
								getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
								
								isshowpan = true;
							}
						}
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(timer, (int)(199), (int)(200));
		_onscroll(webview1);
		_onscroll(webview2);
		_onscroll(webview3);
		_onscroll(webview4);
		_onscroll(webview5);
		_onscroll(webview6);
	}private ViewTreeObserver.OnGlobalLayoutListener listener;
	
	public void toggleKeyboardListener() {
		    final View activityRootView = getWindow().getDecorView().getRootView();
		
		    if (listener != null) {
			        activityRootView.getViewTreeObserver().removeOnGlobalLayoutListener(listener);
			    }
		
		    listener = new ViewTreeObserver.OnGlobalLayoutListener() {
			        @Override
			        public void onGlobalLayout() {
				            Rect r = new Rect();
				            activityRootView.getWindowVisibleDisplayFrame(r);
				            int screenHeight = activityRootView.getRootView().getHeight();
				
				            // Розрахунок різниці між висотою екрану і видимою областю екрану
				            int heightDifference = screenHeight - (r.bottom - r.top);
				
				            if (heightDifference > screenHeight * 0.15) {
					                // Клавіатура відображена на екрані
					                kbd = true;
					            } else {
					                // Клавіатура прихована
					                kbd = false;
					            }
				        }
			    };
		
		    activityRootView.getViewTreeObserver().addOnGlobalLayoutListener(listener);
	}
	{
	}
	
	
	public void _savewindowparam() {
		try{
			windowpos = new Gson().fromJson(FileUtil.readFile("/storage/emulated/0/WeekBrowser/windows.json"), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			windowpos.get((int)6).put("w", ((is1window) ? ("1") : ("0")));
			if (is1window) {
				windowpos.get((int)0).put("e", ((linwebview1.getVisibility() == View.VISIBLE) ? ("1") : ("0")));
				windowpos.get((int)1).put("e", ((linwebview2.getVisibility() == View.VISIBLE) ? ("1") : ("0")));
				windowpos.get((int)2).put("e", ((linwebview3.getVisibility() == View.VISIBLE) ? ("1") : ("0")));
				windowpos.get((int)3).put("e", ((linwebview4.getVisibility() == View.VISIBLE) ? ("1") : ("0")));
				windowpos.get((int)4).put("e", ((linwebview5.getVisibility() == View.VISIBLE) ? ("1") : ("0")));
				windowpos.get((int)5).put("e", ((linwebview6.getVisibility() == View.VISIBLE) ? ("1") : ("0")));
				windowpos.get((int)0).put("px", String.valueOf((long)((linwebview1.getX()/tabscontainer.getWidth()*4)+0.5)));
				windowpos.get((int)1).put("px", String.valueOf((long)((linwebview2.getX()/tabscontainer.getWidth()*4)+0.5)));
				windowpos.get((int)2).put("px", String.valueOf((long)((linwebview3.getX()/tabscontainer.getWidth()*4)+0.5)));
				windowpos.get((int)3).put("px", String.valueOf((long)((linwebview4.getX()/tabscontainer.getWidth()*4)+0.5)));
				windowpos.get((int)4).put("px", String.valueOf((long)((linwebview5.getX()/tabscontainer.getWidth()*4)+0.5)));
				windowpos.get((int)5).put("px", String.valueOf((long)((linwebview6.getX()/tabscontainer.getWidth()*4)+0.5)));
				windowpos.get((int)0).put("py", String.valueOf((long)((linwebview1.getY()/tabscontainer.getHeight()*4)+0.5)));
				windowpos.get((int)1).put("py", String.valueOf((long)((linwebview2.getY()/tabscontainer.getHeight()*4)+0.5)));
				windowpos.get((int)2).put("py", String.valueOf((long)((linwebview3.getY()/tabscontainer.getHeight()*4)+0.5)));
				windowpos.get((int)3).put("py", String.valueOf((long)((linwebview4.getY()/tabscontainer.getHeight()*4)+0.5)));
				windowpos.get((int)4).put("py", String.valueOf((long)((linwebview5.getY()/tabscontainer.getHeight()*4)+0.5)));
				windowpos.get((int)5).put("py", String.valueOf((long)((linwebview6.getY()/tabscontainer.getHeight()*4)+0.5)));
				windowpos.get((int)0).put("sx", String.valueOf((long)(width1)));
				windowpos.get((int)1).put("sx", String.valueOf((long)(width2)));
				windowpos.get((int)2).put("sx", String.valueOf((long)(width3)));
				windowpos.get((int)3).put("sx", String.valueOf((long)(width4)));
				windowpos.get((int)4).put("sx", String.valueOf((long)(width5)));
				windowpos.get((int)5).put("sx", String.valueOf((long)(width6)));
				windowpos.get((int)0).put("sy", String.valueOf((long)(height1)));
				windowpos.get((int)1).put("sy", String.valueOf((long)(height2)));
				windowpos.get((int)2).put("sy", String.valueOf((long)(height3)));
				windowpos.get((int)3).put("sy", String.valueOf((long)(height4)));
				windowpos.get((int)4).put("sy", String.valueOf((long)(height5)));
				windowpos.get((int)5).put("sy", String.valueOf((long)(height6)));
			}
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/windows.json", new Gson().toJson(windowpos));
		}catch(Exception e){
			 
		}
	}
	
	
	public void _restorewindowparam() {
		windowpos = new Gson().fromJson(FileUtil.readFile("/storage/emulated/0/WeekBrowser/windows.json"), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		is1window = windowpos.get((int)6).get("w").toString().equals("1");
		if (is1window) {
			if (!wininit) {
				linwebview1.setOnTouchListener(new OnTouchListener() {
					    PointF DownPT = new PointF();
					    PointF StartPT = new PointF();
					
					    @Override
					    public boolean onTouch(View v, MotionEvent event) {
						        int eid = event.getAction();
						        switch (eid) {
							            case MotionEvent.ACTION_MOVE:
							                PointF mv = new PointF(event.getX() - DownPT.x, event.getY() - DownPT.y);
							                linwebview1.setX((int) (StartPT.x + mv.x));
							                linwebview1.setY((int) (StartPT.y + mv.y));
							                StartPT = new PointF(linwebview1.getX(), linwebview1.getY());
							                break;
							            case MotionEvent.ACTION_DOWN:
							                DownPT.x = event.getX();
							                DownPT.y = event.getY();
							                StartPT = new PointF(linwebview1.getX(), linwebview1.getY());
							                is1touch = true;// При дотику встановлюємо is1touch в true
							                break;
							            case MotionEvent.ACTION_UP:
							                is1touch = false; tab1.performClick();_savewindowparam();// При відпусканні встановлюємо is1touch в false
							                break;
							            default:
							                break;
							        }
						        return true;
						    }
				});
				
				// Повторіть блок коду для кожного linwebviewN від 2 до 6, замінюючи номери
				// Наприклад, код для linwebview2:
				
				linwebview2.setOnTouchListener(new OnTouchListener() {
					    PointF DownPT = new PointF();
					    PointF StartPT = new PointF();
					
					    @Override
					    public boolean onTouch(View v, MotionEvent event) {
						        int eid = event.getAction();
						        switch (eid) {
							            case MotionEvent.ACTION_MOVE:
							                PointF mv = new PointF(event.getX() - DownPT.x, event.getY() - DownPT.y);
							                linwebview2.setX((int) (StartPT.x + mv.x));
							                linwebview2.setY((int) (StartPT.y + mv.y));
							                StartPT = new PointF(linwebview2.getX(), linwebview2.getY());
							                break;
							            case MotionEvent.ACTION_DOWN:
							                DownPT.x = event.getX();
							                DownPT.y = event.getY();
							                StartPT = new PointF(linwebview2.getX(), linwebview2.getY());
							                is2touch = true;// При дотику встановлюємо is2touch в true
							                break;
							            case MotionEvent.ACTION_UP:
							                is2touch = false;tab2.performClick();_savewindowparam(); // При відпусканні встановлюємо is2touch в false
							                break;
							            default:
							                break;
							        }
						        return true;
						    }
				});
				
				// Повторіть цей код для кожного linwebviewN від 3 до 6, замінюючи номери
				// linwebview3, linwebview4, linwebview5, linwebview6
				// Запишіть блок коду для кожного linwebviewN
				linwebview3.setOnTouchListener(new OnTouchListener() {
					    PointF DownPT = new PointF();
					    PointF StartPT = new PointF();
					
					    @Override
					    public boolean onTouch(View v, MotionEvent event) {
						        int eid = event.getAction();
						        switch (eid) {
							            case MotionEvent.ACTION_MOVE:
							                PointF mv = new PointF(event.getX() - DownPT.x, event.getY() - DownPT.y);
							                linwebview3.setX((int) (StartPT.x + mv.x));
							                linwebview3.setY((int) (StartPT.y + mv.y));
							                StartPT = new PointF(linwebview3.getX(), linwebview3.getY());
							                break;
							            case MotionEvent.ACTION_DOWN:
							                DownPT.x = event.getX();
							                DownPT.y = event.getY();
							                StartPT = new PointF(linwebview3.getX(), linwebview3.getY());
							                is3touch = true;// При дотику встановлюємо is3touch в true
							                break;
							            case MotionEvent.ACTION_UP:
							                is3touch = false;tab3.performClick();_savewindowparam(); // При відпусканні встановлюємо is3touch в false
							                break;
							            default:
							                break;
							        }
						        return true;
						    }
				});
				
				linwebview4.setOnTouchListener(new OnTouchListener() {
					    PointF DownPT = new PointF();
					    PointF StartPT = new PointF();
					
					    @Override
					    public boolean onTouch(View v, MotionEvent event) {
						        int eid = event.getAction();
						        switch (eid) {
							            case MotionEvent.ACTION_MOVE:
							                PointF mv = new PointF(event.getX() - DownPT.x, event.getY() - DownPT.y);
							                linwebview4.setX((int) (StartPT.x + mv.x));
							                linwebview4.setY((int) (StartPT.y + mv.y));
							                StartPT = new PointF(linwebview4.getX(), linwebview4.getY());
							                break;
							            case MotionEvent.ACTION_DOWN:
							                DownPT.x = event.getX();
							                DownPT.y = event.getY();
							                StartPT = new PointF(linwebview4.getX(), linwebview4.getY());
							                is4touch = true;// При дотику встановлюємо is4touch в true
							                break;
							            case MotionEvent.ACTION_UP:
							                is4touch = false;tab4.performClick(); _savewindowparam();// При відпусканні встановлюємо is4touch в false
							                break;
							            default:
							                break;
							        }
						        return true;
						    }
				});
				
				
				linwebview5.setOnTouchListener(new OnTouchListener() {
					    PointF DownPT = new PointF();
					    PointF StartPT = new PointF();
					
					    @Override
					    public boolean onTouch(View v, MotionEvent event) {
						        int eid = event.getAction();
						        switch (eid) {
							            case MotionEvent.ACTION_MOVE:
							                PointF mv = new PointF(event.getX() - DownPT.x, event.getY() - DownPT.y);
							                linwebview5.setX((int) (StartPT.x + mv.x));
							                linwebview5.setY((int) (StartPT.y + mv.y));
							                StartPT = new PointF(linwebview5.getX(), linwebview5.getY());
							                break;
							            case MotionEvent.ACTION_DOWN:
							                DownPT.x = event.getX();
							                DownPT.y = event.getY();
							                StartPT = new PointF(linwebview5.getX(), linwebview5.getY());
							                is5touch = true; // При дотику встановлюємо is5touch в true
							                break;
							            case MotionEvent.ACTION_UP:
							                is5touch = false; tab5.performClick();_savewindowparam();// При відпусканні встановлюємо is5touch в false
							                break;
							            default:
							                break;
							        }
						        return true;
						    }
				});
				
				linwebview6.setOnTouchListener(new OnTouchListener() {
					    PointF DownPT = new PointF();
					    PointF StartPT = new PointF();
					
					    @Override
					    public boolean onTouch(View v, MotionEvent event) {
						        int eid = event.getAction();
						        switch (eid) {
							            case MotionEvent.ACTION_MOVE:
							                PointF mv = new PointF(event.getX() - DownPT.x, event.getY() - DownPT.y);
							                linwebview6.setX((int) (StartPT.x + mv.x));
							                linwebview6.setY((int) (StartPT.y + mv.y));
							                StartPT = new PointF(linwebview6.getX(), linwebview6.getY());
							                break;
							            case MotionEvent.ACTION_DOWN:
							                DownPT.x = event.getX();
							                DownPT.y = event.getY();
							                StartPT = new PointF(linwebview6.getX(), linwebview6.getY());
							                is6touch = true;// При дотику встановлюємо is6touch в true
							                break;
							            case MotionEvent.ACTION_UP:
							                is6touch = false;tab6.performClick();_savewindowparam(); // При відпусканні встановлюємо is6touch в false
							                break;
							            default:
							                break;
							        }
						        return true;
						    }
				});
				
				wininit = true;
			}
			_setTopPadding(linwebview1, 30);
			linwebview1.getLayoutParams().width = (int)width1;
			linwebview1.getLayoutParams().height = (int)height1;
			((LinearLayout.LayoutParams) linwebview1.getLayoutParams()).weight = 0; // або будь-яке інше значення, яке вам потрібно
			
			linwebview1.requestLayout();
			_setTopPadding(linwebview2, 30);
			linwebview2.getLayoutParams().width = (int)width2;
			linwebview2.getLayoutParams().height = (int)height2;
			((LinearLayout.LayoutParams) linwebview2.getLayoutParams()).weight = 0; // або будь-яке інше значення, яке вам потрібно
			
			linwebview2.requestLayout();
			_setTopPadding(linwebview3, 30);
			linwebview3.getLayoutParams().width = (int)width3;
			linwebview3.getLayoutParams().height = (int)height3;
			((LinearLayout.LayoutParams) linwebview3.getLayoutParams()).weight = 0; // або будь-яке інше значення, яке вам потрібно
			
			linwebview3.requestLayout();
			_setTopPadding(linwebview4, 30);
			linwebview4.getLayoutParams().width = (int)width4;
			linwebview4.getLayoutParams().height = (int)height4;
			((LinearLayout.LayoutParams) linwebview4.getLayoutParams()).weight = 0; // або будь-яке інше значення, яке вам потрібно
			
			linwebview4.requestLayout();
			_setTopPadding(linwebview5, 30);
			linwebview5.getLayoutParams().width = (int)width5;
			linwebview5.getLayoutParams().height = (int)height5;
			((LinearLayout.LayoutParams) linwebview5.getLayoutParams()).weight = 0; // або будь-яке інше значення, яке вам потрібно
			
			linwebview5.requestLayout();
			_setTopPadding(linwebview6, 30);
			linwebview6.getLayoutParams().width = (int)width6;
			linwebview6.getLayoutParams().height = (int)height6;
			((LinearLayout.LayoutParams) linwebview6.getLayoutParams()).weight = 0; // або будь-яке інше значення, яке вам потрібно
			
			linwebview6.requestLayout();
			windowsmanager.setVisibility(View.VISIBLE);
			width1 = Integer.parseInt(windowpos.get((int)0).get("sx").toString());
			width2 = Integer.parseInt(windowpos.get((int)1).get("sx").toString());
			width3 = Integer.parseInt(windowpos.get((int)2).get("sx").toString());
			width4 = Integer.parseInt(windowpos.get((int)3).get("sx").toString());
			width5 = Integer.parseInt(windowpos.get((int)4).get("sx").toString());
			width6 = Integer.parseInt(windowpos.get((int)5).get("sx").toString());
			height1 = Integer.parseInt(windowpos.get((int)0).get("sy").toString());
			height2 = Integer.parseInt(windowpos.get((int)1).get("sy").toString());
			height3 = Integer.parseInt(windowpos.get((int)2).get("sy").toString());
			height4 = Integer.parseInt(windowpos.get((int)3).get("sy").toString());
			height5 = Integer.parseInt(windowpos.get((int)4).get("sy").toString());
			height6 = Integer.parseInt(windowpos.get((int)5).get("sy").toString());
			th1 = Integer.parseInt(windowpos.get((int)0).get("py").toString());
			th2 = Integer.parseInt(windowpos.get((int)1).get("py").toString());
			th3 = Integer.parseInt(windowpos.get((int)2).get("py").toString());
			th4 = Integer.parseInt(windowpos.get((int)3).get("py").toString());
			th5 = Integer.parseInt(windowpos.get((int)4).get("py").toString());
			th6 = Integer.parseInt(windowpos.get((int)5).get("py").toString());
			ti1 = Integer.parseInt(windowpos.get((int)0).get("px").toString());
			ti2 = Integer.parseInt(windowpos.get((int)1).get("px").toString());
			ti3 = Integer.parseInt(windowpos.get((int)2).get("px").toString());
			ti4 = Integer.parseInt(windowpos.get((int)3).get("px").toString());
			ti5 = Integer.parseInt(windowpos.get((int)4).get("px").toString());
			ti6 = Integer.parseInt(windowpos.get((int)5).get("px").toString());
			if (windowpos.get((int)0).get("e").toString().equals("1")) {
				linwebview1.setVisibility(View.VISIBLE);
			}
			else {
				linwebview1.setVisibility(View.GONE);
			}
			if (windowpos.get((int)1).get("e").toString().equals("1")) {
				linwebview2.setVisibility(View.VISIBLE);
			}
			else {
				linwebview2.setVisibility(View.GONE);
			}
			if (windowpos.get((int)2).get("e").toString().equals("1")) {
				linwebview3.setVisibility(View.VISIBLE);
			}
			else {
				linwebview3.setVisibility(View.GONE);
			}
			if (windowpos.get((int)3).get("e").toString().equals("1")) {
				linwebview4.setVisibility(View.VISIBLE);
			}
			else {
				linwebview4.setVisibility(View.GONE);
			}
			if (windowpos.get((int)4).get("e").toString().equals("1")) {
				linwebview5.setVisibility(View.VISIBLE);
			}
			else {
				linwebview5.setVisibility(View.GONE);
			}
			if (windowpos.get((int)5).get("e").toString().equals("1")) {
				linwebview6.setVisibility(View.VISIBLE);
			}
			else {
				linwebview6.setVisibility(View.GONE);
			}
			try{
				linwebview1.setY((int)th1 * (int)(tabscontainer.getHeight() / 4));
				linwebview2.setY((int)th2 * (int)(tabscontainer.getHeight() / 4));
				linwebview3.setY((int)th3 * (int)(tabscontainer.getHeight() / 4));
				linwebview4.setY((int)th4 * (int)(tabscontainer.getHeight() / 4));
				linwebview5.setY((int)th5 * (int)(tabscontainer.getHeight() / 4));
				linwebview6.setY((int)th6 * (int)(tabscontainer.getHeight() / 4));
				linwebview1.setX((int)ti1 * (int)(tabscontainer.getWidth() / 4));
				linwebview2.setX((int)ti2 * (int)(tabscontainer.getWidth() / 4));
				linwebview3.setX((int)ti3 * (int)(tabscontainer.getWidth() / 4));
				linwebview4.setX((int)ti4 * (int)(tabscontainer.getWidth() / 4));
				linwebview5.setX((int)ti5 * (int)(tabscontainer.getWidth() / 4));
				linwebview6.setX((int)ti6 * (int)(tabscontainer.getWidth() / 4));
				linwebview1.setX(((int)linwebview1.getX() / (int)(tabscontainer.getWidth() / 4)) * (int)(tabscontainer.getWidth() / 4));
				linwebview1.setY( ((int)linwebview1.getY() / (int)(tabscontainer.getHeight() / 4)) * (int)(tabscontainer.getHeight() / 4));
				linwebview2.setX(((int)linwebview2.getX() / (int)(tabscontainer.getWidth() / 4)) * (int)(tabscontainer.getWidth() / 4));
				linwebview2.setY( ((int)linwebview2.getY() / (int)(tabscontainer.getHeight() / 4)) * (int)(tabscontainer.getHeight() / 4));
				linwebview3.setX(((int)linwebview3.getX() / (int)(tabscontainer.getWidth() / 4)) * (int)(tabscontainer.getWidth() / 4));
				linwebview3.setY( ((int)linwebview3.getY() / (int)(tabscontainer.getHeight() / 4)) * (int)(tabscontainer.getHeight() / 4));
				linwebview4.setX(((int)linwebview4.getX() / (int)(tabscontainer.getWidth() / 4)) * (int)(tabscontainer.getWidth() / 4));
				linwebview4.setY( ((int)linwebview4.getY() / (int)(tabscontainer.getHeight() / 4)) * (int)(tabscontainer.getHeight() / 4));
				linwebview5.setX(((int)linwebview5.getX() / (int)(tabscontainer.getWidth() / 4)) * (int)(tabscontainer.getWidth() / 4));
				linwebview5.setY( ((int)linwebview5.getY() / (int)(tabscontainer.getHeight() / 4)) * (int)(tabscontainer.getHeight() / 4));
				linwebview6.setX(((int)linwebview6.getX() / (int)(tabscontainer.getWidth() / 4)) * (int)(tabscontainer.getWidth() / 4));
				linwebview6.setY( ((int)linwebview6.getY() / (int)(tabscontainer.getHeight() / 4)) * (int)(tabscontainer.getHeight() / 4));
				
			}catch(Exception e){
				 
			}
		}
		else {
			_setTopPadding(linwebview1, 0);
			linwebview1.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
			linwebview1.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
			((LinearLayout.LayoutParams) linwebview1.getLayoutParams()).weight = 1; // або будь-яке інше значення, яке вам потрібно
			linwebview1.requestLayout();
			linwebview1.setX(0);
			linwebview1.setY(0);
			_setTopPadding(linwebview2, 0);
			linwebview2.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
			linwebview2.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
			((LinearLayout.LayoutParams) linwebview2.getLayoutParams()).weight = 1; // або будь-яке інше значення, яке вам потрібно
			linwebview2.requestLayout();
			linwebview2.setX(0);
			linwebview2.setY(0);
			_setTopPadding(linwebview3, 0);
			linwebview3.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
			linwebview3.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
			((LinearLayout.LayoutParams) linwebview3.getLayoutParams()).weight = 1; // або будь-яке інше значення, яке вам потрібно
			linwebview3.requestLayout();
			linwebview3.setX(0);
			linwebview3.setY(0);
			_setTopPadding(linwebview4, 0);
			linwebview4.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
			linwebview4.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
			((LinearLayout.LayoutParams) linwebview4.getLayoutParams()).weight = 1; // або будь-яке інше значення, яке вам потрібно
			linwebview4.requestLayout();
			linwebview4.setX(0);
			linwebview4.setY(0);
			_setTopPadding(linwebview5, 0);
			linwebview5.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
			linwebview5.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
			((LinearLayout.LayoutParams) linwebview5.getLayoutParams()).weight = 1; // або будь-яке інше значення, яке вам потрібно
			linwebview5.requestLayout();
			linwebview5.setX(0);
			linwebview5.setY(0);
			_setTopPadding(linwebview6, 0);
			linwebview6.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
			linwebview6.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
			((LinearLayout.LayoutParams) linwebview6.getLayoutParams()).weight = 1; // або будь-яке інше значення, яке вам потрібно
			linwebview6.requestLayout();
			linwebview6.setX(0);
			linwebview6.setY(0);
			windowsmanager.setVisibility(View.GONE);
			_Reopentab();
		}
	}
	
	
	public String _getwindowpos() {
		return (windowpos.get((int)0).get("e").toString().concat(windowpos.get((int)0).get("px").toString().concat(windowpos.get((int)0).get("py").toString().concat(windowpos.get((int)0).get("sx").toString().concat(windowpos.get((int)0).get("sy").toString())))).concat(windowpos.get((int)1).get("e").toString().concat(windowpos.get((int)1).get("px").toString().concat(windowpos.get((int)1).get("py").toString().concat(windowpos.get((int)1).get("sx").toString().concat(windowpos.get((int)1).get("sy").toString())))).concat(windowpos.get((int)2).get("e").toString().concat(windowpos.get((int)2).get("px").toString().concat(windowpos.get((int)2).get("py").toString().concat(windowpos.get((int)2).get("sx").toString().concat(windowpos.get((int)2).get("sy").toString())))).concat(windowpos.get((int)3).get("e").toString().concat(windowpos.get((int)3).get("px").toString().concat(windowpos.get((int)3).get("py").toString().concat(windowpos.get((int)3).get("sx").toString().concat(windowpos.get((int)3).get("sy").toString())))).concat(windowpos.get((int)4).get("e").toString().concat(windowpos.get((int)4).get("px").toString().concat(windowpos.get((int)4).get("py").toString().concat(windowpos.get((int)4).get("sx").toString().concat(windowpos.get((int)4).get("sy").toString())))).concat(windowpos.get((int)5).get("e").toString().concat(windowpos.get((int)5).get("px").toString().concat(windowpos.get((int)5).get("py").toString().concat(windowpos.get((int)5).get("sx").toString().concat(windowpos.get((int)5).get("sy").toString()))))))))));
	}
	
	
	public String _clearram() {
		return ("javascript:(function() {\n    var elements = document.querySelectorAll('*');\n    for (var i = 0; i < elements.length; i++) {\n        elements[i].style.border = 'none';\n        elements[i].style.boxShadow = 'none';\n        elements[i].style.transition = 'none';\n        elements[i].style.animation = 'none';\n        elements[i].style.backgroundImage = 'none';\n        elements[i].style.textShadow = 'none';\n    }\n})();\n");
	}
	
	
	public void _onscroll(final WebView _w) {
		_w.setOnTouchListener(new View.OnTouchListener() {
			    private float startY;
			
			    @Override
			    public boolean onTouch(View v, MotionEvent event) {
				        switch (event.getAction()) {
					            case MotionEvent.ACTION_DOWN:
					                startY = event.getRawY();
					                break;
					            case MotionEvent.ACTION_UP:
					                float endY = event.getRawY();
					                float touchSlop = ViewConfiguration.get(_w.getContext()).getScaledTouchSlop();
													isshowed=false;local1=false;local2=false;
													if(swipetorefresh){
														_refreshh();swipetorefresh=false;}
					                if (Math.abs(startY - endY) < touchSlop) {
						                    if(is1window)
						                    // Це був простий дотик
						                    {if (_w == webview1) {
								                        tab1.performClick();
								                    } else if (_w == webview2) {
								                        tab2.performClick();
								                    } else if (_w == webview3) {
								                        tab3.performClick();
								                    } else if (_w == webview4) {
								                        tab4.performClick();
								                    } else if (_w == webview5) {
								                        tab5.performClick();
								                    } else if (_w == webview6) {
								                        tab6.performClick();
								                    }
							                }}
					                break;
					            case MotionEvent.ACTION_MOVE:
					                float currentY = event.getRawY();
					                if (startY+SketchwareUtil.getDip(getApplicationContext(), (int)(50)) < currentY) {
						
						if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/HidePanels.txt").equals("1") && !is1window) {
							linear1.setVisibility(View.VISIBLE);
							if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/NavPan.txt").equals("1")) {
								linear5.setVisibility(View.VISIBLE);
							}
							getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
							
							isnotchfullscreen = false;
						}
						if (!local2 && (ALLOWSWIPE && !is1window)) {
							switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
								case "0": {
									if (webview1.getScrollY() == 0) {
										isshowed = true;
										local1 = true;
									}
									break;
								}
								case "1": {
									if (webview2.getScrollY() == 0) {
										isshowed = true;
										local1 = true;
									}
									break;
								}
								case "2": {
									if (webview3.getScrollY() == 0) {
										isshowed = true;
										local1 = true;
									}
									break;
								}
								case "3": {
									if (webview4.getScrollY() == 0) {
										isshowed = true;
										local1 = true;
									}
									break;
								}
								case "4": {
									if (webview5.getScrollY() == 0) {
										isshowed = true;
										local1 = true;
									}
									break;
								}
								case "5": {
									if (webview6.getScrollY() == 0) {
										isshowed = true;
										local1 = true;
									}
									break;
								}
							}
						}
						local2 = true;
						if ((startY+SketchwareUtil.getDip(getApplicationContext(), (int)(250)) < currentY && local1) && ALLOWSWIPE) {
							swipetorefresh = true;
						}
						else {
							swipetorefresh = false;
						}
						                } else if (startY-SketchwareUtil.getDip(getApplicationContext(), (int)(50)) > currentY) {
						                    
						if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/HidePanels.txt").equals("1") && !is1window) {
							linear1.setVisibility(View.GONE);
							
							linear5.setVisibility(View.GONE);
							getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_FULLSCREEN
							        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
							        | View.SYSTEM_UI_FLAG_IMMERSIVE);
							isnotchfullscreen = true;
						}
						 }
					                break;
					        }
				        return false; // Повертаємо false, щоб інші обробники подій дотику також були викликані, якщо вони є
				    }
		});
		
	}
	
	
	public void _clearonexit() {
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Autoclean/search.txt").equals("1")) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/search.txt", "[weekbrowser]");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Autoclean/cache.txt").equals("1")) {
			webview1.clearCache(true);
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Autoclean/cookie.txt").equals("1")) {
			CookieManager.getInstance().removeAllCookies(null);
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Autoclean/form.txt").equals("1")) {
			webview1.clearFormData();
		}
	}
	
	
	public void _extrc() {
	}
	public boolean isAdblEnabled() {
		    return adbl;
	}
	
	public static void setupWebView(WebView webView, Activity activity) {
		    // Вимкнення відкриття посилань в сторонніх браузерах
		    webView.setWebViewClient(new MyWebViewClient(activity));
		    
		    // Додання WebChromeClient для підтримки JavaScript та інших можливостей
		    webView.setWebChromeClient(new CustomWebClient(activity));
		    webView.addJavascriptInterface(new JavaScriptInterface(activity), "AndroidInterface");
		//    setupLongClickHandler(webView);
		    
	}
	
	/*private static void setupLongClickHandler(final WebView webView) {
    webView.setOnLongClickListener(new View.OnLongClickListener() {
        @Override
        public boolean onLongClick(View v) {
            webView.evaluateJavascript(
                "(function() {" +
                "    alert('Start');" +
                "    function addContextMenuListener(document) {" +
                "        if (!document.contextMenuListenerAdded) {" +
                "            document.contextMenuListenerAdded = true;" +
                "            document.addEventListener('contextmenu', function(e) {" +
                "                if (true) {" + //чи увімкнено суперменю
                "                    alert('Context menu event detected');" +
                "                    e.preventDefault();" +
                "                    var element = e.target;" +
                "                    alert('Target element: ' + element.tagName);" +
                "                    var elementCode = element.outerHTML;" +
                "                    var elementText = element.innerText;" +
                "                    var elementSrc = element.src || '';" +
                "                    var elementHref = '';" +
                "                    if (element.tagName === 'A') {" +
                "                        elementHref = element.href;" +
                "                    } else {" +
                "                        var parent = element.closest('a');" +
                "                        if (parent) {" +
                "                            elementHref = parent.href;" +
                "                        }" +
                "                    }" +
                "                    var data = {" +
                "                        code: elementCode," +
                "                        text: elementText," +
                "                        src: elementSrc," +
                "                        href: elementHref" +
                "                    };" +
                "                    alert('Data prepared: ' + JSON.stringify(data));" +
                "                    window.AndroidInterface.processElementInfo(JSON.stringify(data));" +
                "                }" +
                "            });" +
                "        }" +
                "    }" +
                "    function addListenersToIframes(document) {" +
                "        var iframes = document.querySelectorAll('iframe');" +
                "        iframes.forEach(function(iframe) {" +
                "            try {" +
                "                var iframeDoc = iframe.contentDocument || iframe.contentWindow.document;" +
                "                if (iframeDoc) {" +
                "                    addContextMenuListener(iframeDoc);" +
                "                }" +
                "            } catch (e) {" +
                "                console.error('Error accessing iframe content: ', e);" +
                "                alert('Error accessing iframe content: ' + e.message);" +
                "            }" +
                "        });" +
                "    }" +
                "    addContextMenuListener(document);" +
                "    addListenersToIframes(document);" +
                "})();",
                null
            );
            return true;
        }
    });
}
*/
	{
	}
	
	
	public void _refreshh() {
		switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
			case "0": {
				webview1.loadUrl(webview1.getUrl());
				break;
			}
			case "1": {
				webview2.loadUrl(webview2.getUrl());
				break;
			}
			case "2": {
				webview3.loadUrl(webview3.getUrl());
				break;
			}
			case "3": {
				webview4.loadUrl(webview4.getUrl());
				break;
			}
			case "4": {
				webview5.loadUrl(webview5.getUrl());
				break;
			}
			case "5": {
				webview6.loadUrl(webview6.getUrl());
				break;
			}
		}
	}
	
	
	public void _swipeset() {
		try{
			switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt")) {
				case "0": {
					for (int i = 0; i < (int)(sitepermis.size()); i++) {
						if (webview1.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
							switch(sitepermis.get((int)i).get("sr").toString()) {
								case "1": {
									ALLOWSWIPE = true;
									break;
								}
								case "2": {
									if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Swipetorefresh.txt").equals("1")) {
										ALLOWSWIPE = true;
									}
									else {
										ALLOWSWIPE = false;
									}
									break;
								}
								case "0": {
									ALLOWSWIPE = false;
									break;
								}
							}
							issu = true;
						}
					}
					if (!issu) {
						if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Swipetorefresh.txt").equals("1")) {
							ALLOWSWIPE = true;
						}
						else {
							ALLOWSWIPE = false;
						}
					}
					issu = false;
					break;
				}
				case "1": {
					for (int i = 0; i < (int)(sitepermis.size()); i++) {
						if (webview2.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
							switch(sitepermis.get((int)i).get("sr").toString()) {
								case "1": {
									ALLOWSWIPE = true;
									break;
								}
								case "2": {
									if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Swipetorefresh.txt").equals("1")) {
										ALLOWSWIPE = true;
									}
									else {
										ALLOWSWIPE = false;
									}
									break;
								}
								case "0": {
									ALLOWSWIPE = false;
									break;
								}
							}
							issu = true;
						}
					}
					if (!issu) {
						if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Swipetorefresh.txt").equals("1")) {
							ALLOWSWIPE = true;
						}
						else {
							ALLOWSWIPE = false;
						}
					}
					issu = false;
					break;
				}
				case "2": {
					for (int i = 0; i < (int)(sitepermis.size()); i++) {
						if (webview3.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
							switch(sitepermis.get((int)i).get("sr").toString()) {
								case "1": {
									ALLOWSWIPE = true;
									break;
								}
								case "2": {
									if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Swipetorefresh.txt").equals("1")) {
										ALLOWSWIPE = true;
									}
									else {
										ALLOWSWIPE = false;
									}
									break;
								}
								case "0": {
									ALLOWSWIPE = false;
									break;
								}
							}
							issu = true;
						}
					}
					if (!issu) {
						if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Swipetorefresh.txt").equals("1")) {
							ALLOWSWIPE = true;
						}
						else {
							ALLOWSWIPE = false;
						}
					}
					issu = false;
					break;
				}
				case "3": {
					for (int i = 0; i < (int)(sitepermis.size()); i++) {
						if (webview4.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
							switch(sitepermis.get((int)i).get("sr").toString()) {
								case "1": {
									ALLOWSWIPE = true;
									break;
								}
								case "2": {
									if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Swipetorefresh.txt").equals("1")) {
										ALLOWSWIPE = true;
									}
									else {
										ALLOWSWIPE = false;
									}
									break;
								}
								case "0": {
									ALLOWSWIPE = false;
									break;
								}
							}
							issu = true;
						}
					}
					if (!issu) {
						if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Swipetorefresh.txt").equals("1")) {
							ALLOWSWIPE = true;
						}
						else {
							ALLOWSWIPE = false;
						}
					}
					issu = false;
					break;
				}
				case "4": {
					for (int i = 0; i < (int)(sitepermis.size()); i++) {
						if (webview5.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
							switch(sitepermis.get((int)i).get("sr").toString()) {
								case "1": {
									ALLOWSWIPE = true;
									break;
								}
								case "2": {
									if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Swipetorefresh.txt").equals("1")) {
										ALLOWSWIPE = true;
									}
									else {
										ALLOWSWIPE = false;
									}
									break;
								}
								case "0": {
									ALLOWSWIPE = false;
									break;
								}
							}
							issu = true;
						}
					}
					if (!issu) {
						if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Swipetorefresh.txt").equals("1")) {
							ALLOWSWIPE = true;
						}
						else {
							ALLOWSWIPE = false;
						}
					}
					issu = false;
					break;
				}
				case "5": {
					for (int i = 0; i < (int)(sitepermis.size()); i++) {
						if (webview6.getUrl().contains(sitepermis.get((int)i).get("url").toString())) {
							switch(sitepermis.get((int)i).get("sr").toString()) {
								case "1": {
									ALLOWSWIPE = true;
									break;
								}
								case "2": {
									if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Swipetorefresh.txt").equals("1")) {
										ALLOWSWIPE = true;
									}
									else {
										ALLOWSWIPE = false;
									}
									break;
								}
								case "0": {
									ALLOWSWIPE = false;
									break;
								}
							}
							issu = true;
						}
					}
					if (!issu) {
						if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Swipetorefresh.txt").equals("1")) {
							ALLOWSWIPE = true;
						}
						else {
							ALLOWSWIPE = false;
						}
					}
					issu = false;
					break;
				}
			}
		}catch(Exception e){
			 
		}
	}
	
	
	public void _fonts() {
		back.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/icon.ttf"), 0);
		forward.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/icon.ttf"), 0);
		pgup.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/icon.ttf"), 0);
		pgdn.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/icon.ttf"), 0);
		bookmarks.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/icon.ttf"), 0);
		home.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/icon.ttf"), 0);
		histori.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/icon.ttf"), 0);
		tabs.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/icon.ttf"), 0);
		dual.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/icon.ttf"), 0);
		skipvideo.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/icon.ttf"), 0);
		pagesearch.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/icon.ttf"), 0);
		coordinates.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/icon.ttf"), 0);
		addshortcut.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/icon.ttf"), 0);
		sup.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/icon.ttf"), 0);
		sdown.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/icon.ttf"), 0);
		hide.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/icon.ttf"), 0);
		refresh.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/icon.ttf"), 0);
		button1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/icon.ttf"), 0);
		openpanel.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/icon.ttf"), 0);
		button3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/icon.ttf"), 0);
	}
	
	
	public void _ifex2() {
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bg.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/bg.txt", FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/bg.txt"));
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bgcol.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/bgcol.txt", FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/bg.txt"));
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bgblend.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/bgblend.txt", "normal");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bgblur.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/bgblur.txt", "0.0");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bgbright.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/bgbright.txt", "1.0");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bgcontr.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/bgcontr.txt", "1.0");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bghue.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/bghue.txt", "0");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bginvert.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/bginvert.txt", "0.0");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bgopacity.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/bgopacity.txt", "0.0");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bgsatur.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/bgsatur.txt", "1.0");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bgsepia.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/bgsepia.txt", "0.0");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bgsize.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/bgsize.txt", "cover");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bgstrokecolor.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/bgstrokecolor.txt", "FF0000FF");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bgstrokesize.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/bgstrokesize.txt", "0.0");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bgstrokestyle.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/bgstrokestyle.txt", "solid");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textalign.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/textalign.txt", "left");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textblur.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/textblur.txt", "0.0");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textbordercolor.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/textbordercolor.txt", "FF0000FF");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textbordersize.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/textbordersize.txt", "0.0");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textborderstyle.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/textborderstyle.txt", "solid");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textbright.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/textbright.txt", "1.0");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textcontr.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/textcontr.txt", "1.0");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textfont.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/textfont.txt", "sans");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/texthue.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/texthue.txt", "0");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textinvert.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/textinvert.txt", "0.0");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textline.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/textline.txt", "1.3");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textopacity.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/textopacity.txt", "1.0");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textsatur.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/textsatur.txt", "1.0");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textsepia.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/textsepia.txt", "0.0");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textshadowb.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/textshadowb.txt", "0.0");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textshadowblend.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/textshadowblend.txt", "normal");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textshadowc.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/textshadowc.txt", "FF0000FF");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textshadowx.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/textshadowx.txt", "0.0");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textshadowy.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/textshadowy.txt", "0.0");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textsize.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/textsize.txt", "20");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textstrokecolor.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/textstrokecolor.txt", "FF0000FF");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textstyle.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/textstyle.txt", "initial");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/texttrans.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/texttrans.txt", "initial");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textweight.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/css/textweight.txt", "500");
		}
		FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Blockad/videopatterns.txt", "Пропустити через|Реклама •|Реклама закінчиться|Реклама [0-9]");
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Blockad/skipvideoad.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Blockad/skipvideoad.txt", "1");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache/bmkdsgn.txt").isEmpty()) {
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/cache/bmkdsgn.txt", "javascript:(function() {\n    var backgroundDiv = document.createElement('div');\n    backgroundDiv.style.position = 'fixed';\n    backgroundDiv.style.top = '0';\n    backgroundDiv.style.left = '0';\n    backgroundDiv.style.width = '100%';\n    backgroundDiv.style.height = '100%';\n    backgroundDiv.style.zIndex = '-1';\n    backgroundDiv.style.backgroundColor = '#".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bgcol.txt").concat("';\n    document.body.appendChild(backgroundDiv);\n\n    var blurDiv = document.createElement('div');\n    blurDiv.style.position = 'fixed';\n    blurDiv.style.top = '0';\n    blurDiv.style.left = '0';\n    blurDiv.style.width = '100%';\n    blurDiv.style.height = '100%';\n    blurDiv.style.backgroundColor = '#".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/bg.txt").concat("';\n    blurDiv.style.backgroundImage = 'url(file://".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bgimage.txt").concat(")';\n    blurDiv.style.backgroundSize = '".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bgsize.txt").concat("';\n    blurDiv.style.filter = 'blur(".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bgblur.txt").concat("px) hue-rotate(".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bghue.txt").concat("deg) invert(".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bginvert.txt").concat(") contrast(")))))))))))))).concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bgcontr.txt").concat(") brightness(".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bgbright.txt").concat(") sepia(".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bgsepia.txt").concat(") saturate(".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bgsatur.txt").concat("")))))))).concat("".concat("".concat("".concat("".concat("".concat(") opacity(".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bgopacity.txt").concat(")';\n    blurDiv.style.mixBlendMode = '")))))))).concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bgblend.txt").concat("';\n    blurDiv.style.zIndex = '-2';\n    backgroundDiv.appendChild(blurDiv);\n\n    var contentElements = document.querySelectorAll('font');\n    contentElements.forEach(function(element) {\n        \n        element.style.lineHeight = '".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textline.txt").concat("';\n        element.style.fontFamily = '".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textfont.txt").concat("';\n        element.style.fontSize = '".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textsize.txt").concat("px';\n        element.style.fontWeight = '".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textweight.txt").concat("';\n        element.style.textTransform = '".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/texttrans.txt").concat("';\n        element.style.fontStyle = '")).concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textstyle.txt").concat("';\n        element.style.filter = 'blur(".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textblur.txt")).concat("px) hue-rotate(".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/texthue.txt").concat("deg) invert(".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textinvert.txt").concat(") contrast("))))).concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textcontr.txt").concat(") brightness(")))))))))))))).concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textbright.txt").concat(") sepia(".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textsepia.txt").concat(") saturate(".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textsatur.txt").concat("".concat("")))).concat("".concat("".concat("".concat("".concat(") opacity(".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textopacity.txt"))))).concat(")';\n        element.style.textShadow = '".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textshadowx.txt").concat("px ".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textshadowy.txt")))))))))).concat("px ".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textshadowb.txt")).concat("px #".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textshadowc.txt"))).concat("';\n        element.style.mixBlendMode = '").concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textshadowblend.txt").concat("';\n        element.style.border = '").concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textbordersize.txt").concat("px ")).concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textborderstyle.txt")).concat(" #"))).concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textbordercolor.txt").concat("';\n        element.style.webkitTextStroke = '").concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textstrokesize.txt")).concat("px #".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textstrokecolor.txt")))).concat("';\n        \n    });\n    document.body.style.border = '".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bgstrokesize.txt")).concat("px ".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bgstrokestyle.txt")).concat(" #").concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/bgstrokecolor.txt")).concat("';\n    document.body.style.textAlign = '".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/css/textalign.txt").concat("';\n})();"))))));
		}
	}
	
	
	public void _monet() {
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/monet/on.txt").equals("1")) {
			if (!_selcol("bg").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/bg.txt", _selcol("bg"));
			}
			if (!_selcol("buttontext").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt", _selcol("buttontext"));
			}
			if (!_selcol("redbuttontext").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt", _selcol("redbuttontext"));
			}
			if (!_selcol("buttonbg1").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg.txt", _selcol("buttonbg1"));
			}
			if (!_selcol("buttonbg1").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg.txt", _selcol("redbuttonbg1"));
			}
			if (!_selcol("buttonbg2").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg2.txt", _selcol("buttonbg2"));
			}
			if (!_selcol("redbuttonbg2").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg2.txt", _selcol("redbuttonbg2"));
			}
			if (!_selcol("text").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt", _selcol("text"));
			}
			if (!_selcol("text").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/textfield.txt", _selcol("text"));
			}
			if (!_selcol("additional").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt", _selcol("additional"));
			}
			if (!_selcol("hint").isEmpty()) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt", _selcol("hint"));
			}
		}
	}
	
	
	public String _selcol(final String _col) {
		try{
			switch(FileUtil.readFile("/storage/emulated/0/WeekBrowser/monet/".concat(_col.concat(".txt")))) {
				case "n110": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_neutral1_10)).toUpperCase();
					break;
				}
				case "n150": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_neutral1_50)).toUpperCase();
					break;
				}
				case "n1100": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_neutral1_100)).toUpperCase();
					break;
				}
				case "n1200": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_neutral1_200)).toUpperCase();
					break;
				}
				case "n1300": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_neutral1_300)).toUpperCase();
					break;
				}
				case "n1400": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_neutral1_400)).toUpperCase();
					break;
				}
				case "n1500": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_neutral1_500)).toUpperCase();
					break;
				}
				case "n1600": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_neutral1_600)).toUpperCase();
					break;
				}
				case "n1700": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_neutral1_700)).toUpperCase();
					break;
				}
				case "n1800": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_neutral1_800)).toUpperCase();
					break;
				}
				case "n1900": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_neutral1_900)).toUpperCase();
					break;
				}
				case "n210": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_neutral2_10)).toUpperCase();
					break;
				}
				case "n250": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_neutral2_50)).toUpperCase();
					break;
				}
				case "n2100": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_neutral2_100)).toUpperCase();
					break;
				}
				case "n2200": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_neutral2_200)).toUpperCase();
					break;
				}
				case "n2300": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_neutral2_300)).toUpperCase();
					break;
				}
				case "n2400": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_neutral2_400)).toUpperCase();
					break;
				}
				case "n2500": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_neutral2_500)).toUpperCase();
					break;
				}
				case "n2600": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_neutral2_600)).toUpperCase();
					break;
				}
				case "n2700": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_neutral2_700)).toUpperCase();
					break;
				}
				case "n2800": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_neutral2_800)).toUpperCase();
					break;
				}
				case "n2900": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_neutral2_900)).toUpperCase();
					break;
				}
				case "a110": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent1_10)).toUpperCase();
					break;
				}
				case "a150": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent1_50)).toUpperCase();
					break;
				}
				case "a1100": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent1_100)).toUpperCase();
					break;
				}
				case "a1200": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent1_200)).toUpperCase();
					break;
				}
				case "a1300": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent1_300)).toUpperCase();
					break;
				}
				case "a1400": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent1_400)).toUpperCase();
					break;
				}
				case "a1500": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent1_500)).toUpperCase();
					break;
				}
				case "a1600": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent1_600)).toUpperCase();
					break;
				}
				case "a1700": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent1_700)).toUpperCase();
					break;
				}
				case "a1800": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent1_800)).toUpperCase();
					break;
				}
				case "a1900": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent1_900)).toUpperCase();
					break;
				}
				case "a210": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent2_10)).toUpperCase();
					break;
				}
				case "a250": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent2_50)).toUpperCase();
					break;
				}
				case "a2100": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent2_100)).toUpperCase();
					break;
				}
				case "a2200": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent2_200)).toUpperCase();
					break;
				}
				case "a2300": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent2_300)).toUpperCase();
					break;
				}
				case "a2400": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent2_400)).toUpperCase();
					break;
				}
				case "a2500": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent2_500)).toUpperCase();
					break;
				}
				case "a2600": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent2_600)).toUpperCase();
					break;
				}
				case "a2700": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent2_700)).toUpperCase();
					break;
				}
				case "a2800": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent2_800)).toUpperCase();
					break;
				}
				case "a2900": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent2_900)).toUpperCase();
					break;
				}
				case "a310": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent3_10)).toUpperCase();
					break;
				}
				case "a350": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent3_50)).toUpperCase();
					break;
				}
				case "a3100": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent3_100)).toUpperCase();
					break;
				}
				case "a3200": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent3_200)).toUpperCase();
					break;
				}
				case "a3300": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent3_300)).toUpperCase();
					break;
				}
				case "a3400": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent3_400)).toUpperCase();
					break;
				}
				case "a3500": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent3_500)).toUpperCase();
					break;
				}
				case "a3600": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent3_600)).toUpperCase();
					break;
				}
				case "a3700": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent3_700)).toUpperCase();
					break;
				}
				case "a3800": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent3_800)).toUpperCase();
					break;
				}
				case "a3900": {
					fffff = Integer.toHexString(getResources().getColor(android.R.color.system_accent3_900)).toUpperCase();
					break;
				}
				case "no": {
					fffff = "";
					break;
				}
			}
		}catch(Exception e){
			SketchwareUtil.showMessage(getApplicationContext(), "Ой");
		}
		return (fffff);
	}
	
	
	public void _download(final WebView _w) {
		_w.setDownloadListener(new DownloadListener() {
			    @Override
			    public void onDownloadStart(String url, String userAgent, String contentDisposition,
			                                final String mimeType, long contentLength) {
				        final String finalUrl = url;
				        final String finalUserAgent = userAgent;
				        final String fileName = URLUtil.guessFileName(url, contentDisposition, mimeType);
				        final String fileSize = (contentLength > 0) ? android.text.format.Formatter.formatFileSize(getApplicationContext(), contentLength) : "Невідомий розмір";
				
				        // Створення діалогового вікна
				        AlertDialog.Builder builder = new AlertDialog.Builder(_w.getContext());
				        builder.setTitle("Завантаження файлу");
				        builder.setMessage("Назва: " + fileName + "\n\nФормат: " + mimeType + "\n\nРозмір: " + fileSize);
				        builder.setPositiveButton("Завантажити", new DialogInterface.OnClickListener() {
					            @Override
					            public void onClick(DialogInterface dialog, int which) {
						                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(finalUrl));
						                request.setMimeType(mimeType);
						                String cookies = CookieManager.getInstance().getCookie(finalUrl);
						                request.addRequestHeader("cookie", cookies);
						                request.addRequestHeader("User-Agent", finalUserAgent);
						                request.setDescription("Завантаження файлу");
						                request.setTitle(fileName);
						                request.allowScanningByMediaScanner();
						                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
						                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
						                DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
						                dm.enqueue(request);
						                Toast.makeText(getApplicationContext(), "Завантаження файлу...", Toast.LENGTH_LONG).show();
						            }
					        });
				        builder.setNegativeButton("Скасувати", new DialogInterface.OnClickListener() {
					            @Override
					            public void onClick(DialogInterface dialog, int which) {
						                // Закриваємо діалогове вікно без додаткових дій
						                dialog.dismiss();
						            }
					        });
				        builder.show();
				    }
		});
		
		timer = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Supermenu.txt").equals("1")) {
							_w.evaluateJavascript(
							    "var isSupermenu2705200527 = true;",
							    null
							);
							
						}
						else {
							_w.evaluateJavascript(
							    "var isSupermenu2705200527 = false;",
							    null
							);
							
						}
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(timer, (int)(499), (int)(500));
	}
	
	
	public void _onpagestart(final WebView _w) {
		if (_w.equals(webview1)) {
			    ibml1=true;
		} else if (_w.equals(webview2)) {
			    ibml21=true;
		} else if (_w.equals(webview3)) {
			    ibml31=true;
		} else if (_w.equals(webview4)) {
			    ibml41=true;
		} else if (_w.equals(webview5)) {
			    ibml51=true;
		} else if (_w.equals(webview6)) {
			    ibml61=true;
		} 
		_jsset();
		_Blockad();
		_swipeset();
		try{
			new histor().execute(_w.getUrl());
			if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/PC.txt")) == 1) {
				_w.setInitialScale(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*5);_w.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/currentpc.txt"));
			}
			else {
				_w.setInitialScale(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/dp.txt"))*10);_w.getSettings().setUserAgentString(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Useragents/current.txt"));
			}
			if (!info.contains("Немає")) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/incognito.txt")) == 1) {
					if (android.os.Build.VERSION.SDK_INT >= 21) { CookieManager.getInstance().setAcceptThirdPartyCookies(_w, false); } else { CookieManager.getInstance().setAcceptCookie(false); }
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 0) {
						_w.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 1) {
							_w.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 2) {
								_w.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
							}
							else {
								_w.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
							}
						}
					}
				}
				else {
					if (android.os.Build.VERSION.SDK_INT >= 21) { CookieManager.getInstance().setAcceptThirdPartyCookies(_w, true); } else { CookieManager.getInstance().setAcceptCookie(true); }
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 0) {
						_w.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 1) {
							_w.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 2) {
								_w.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
							}
							else {
								_w.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
							}
						}
					}
				}
			}
			if (_w.getUrl().equals("")) {
				_w.loadUrl(FileUtil.readFile("/storage/emulated/0/WeekBrowser/firstpage.txt"));
			}
			if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/autofirstpage.txt").equals("1") && (!_w.getUrl().equals("about:blank") && FileUtil.readFile("/storage/emulated/0/WeekBrowser/incognito.txt").equals("0"))) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/firstpage.txt", _w.getUrl());
			}
		}catch(Exception e){
			FileUtil.writeFile("/storage/emulated/0/WeekBrowser/firstpage.txt", "file:///storage/emulated/0/WeekBrowser/bookmark.html");
		}
		_Reopentab();
		try{
			if (!(_w.getUrl().contains("http://") || (_w.getUrl().contains("https://") || (_w.getUrl().contains("file://") || _w.getUrl().contains("about:"))))) {
				intent.setAction(Intent.ACTION_VIEW);
				if (_w.getUrl().contains("intent://")) {
					intent.setData(Uri.parse(_w.getUrl().replace("intent://", "")));
				}
				else {
					intent.setData(Uri.parse(_w.getUrl()));
				}
				_w.stopLoading();
				startActivity(intent);
			}
			if (_w.getUrl().startsWith("https://multilink.weekbrowser.com/")) {
				intent.setClass(getApplicationContext(), IntentActivity.class);
				intent.setData(Uri.parse(_w.getUrl()));
				startActivity(intent);
			}
		}catch(Exception e){
			 
		}
		_setcolofuttons();
	}
	
	
	public void _onpagefinish(final WebView _w) {
		if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/1.txt")) == 1) {
			_w.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/1.txt")));
		}
		if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/2.txt")) == 1) {
			_w.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/2.txt")));
		}
		if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/3.txt")) == 1) {
			_w.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/3.txt")));
		}
		if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/4.txt")) == 1) {
			_w.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/4.txt")));
		}
		if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/5.txt")) == 1) {
			_w.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/5.txt")));
		}
		if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/6.txt")) == 1) {
			_w.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/6.txt")));
		}
		_Reopentab();
		new histor2().execute(_w.getTitle());
		_w.evaluateJavascript(
		    "var isSupermenu2705200527 = false;" +
		    "(function() {" +
		    "    function handleContextMenu(e, doc) {" +
		    "        if (isSupermenu2705200527) {" +
		    "            e.preventDefault();" +
		    "            var element = e.target;" +
		    "            var elementCode = element.outerHTML;" +
		    "            var elementText = element.innerText;" +
		    "            var elementSrc = element.src || '';" +
		    "            var elementHref = '';" +
		    "            var pageText = document.body.innerText;" +
		    "            var pageCode = document.documentElement.outerHTML;"+
		    "            var purl = window.location.href;" +
		    "            if (element.tagName === 'A') {" +
		    "                elementHref = element.href;" +
		    "            } else {" +
		    "                var parent = element.closest('a');" +
		    "                if (parent) {" +
		    "                    elementHref = parent.href;" +
		    "                }" +
		    "            }" +
		    "            var data = {" +
		    "                code: elementCode," +
		    "                text: elementText," +
		    "                src: elementSrc," +
		    "                href: elementHref," +
		    "                wtext: pageText," +
		    "                wcode: pageCode," +
		    "                url: purl" +
		    "            };" +
		    "            window.AndroidInterface.processElementInfo(JSON.stringify(data));" +
		    "        }" +
		    "    }" +
		    "    function addContextMenuListener(doc) {" +
		    "        if (!doc.contextMenuListenerAdded) {" +
		    "            doc.contextMenuListenerAdded = true;" +
		    "            doc.addEventListener('contextmenu', function(e) {" +
		    "                if (isSupermenu2705200527) {" +
		    "                    handleContextMenu(e, doc);" +
		    "                }" +
		    "            }, true);" + // Use capture phase
		    "            var style = doc.createElement('style');" +
		    "            style.type = 'text/css';" +
		    "            style.innerHTML = '* { user-select: ' + (isSupermenu2705200527 ? 'none !important' : 'auto !important') + '; }';" +
		    "            doc.head.appendChild(style);" +
		    "        }" +
		    "    }" +
		    "    function addListenersToIframes(doc) {" +
		    "        var iframes = doc.querySelectorAll('iframe');" +
		    "        iframes.forEach(function(iframe) {" +
		    "            try {" +
		    "                var iframeDoc = iframe.contentDocument || iframe.contentWindow.document;" +
		    "                if (iframeDoc && !iframeDoc.contextMenuListenerAdded) {" +
		    "                    addContextMenuListener(iframeDoc);" +
		    "                    var observer = new MutationObserver(function(mutations) {" +
		    "                        mutations.forEach(function(mutation) {" +
		    "                            if (mutation.addedNodes.length > 0) {" +
		    "                                addContextMenuListener(iframeDoc);" +
		    "                            }" +
		    "                        });" +
		    "                    });" +
		    "                    observer.observe(iframeDoc.body, { childList: true, subtree: true });" +
		    "                    iframe.contentWindow.addEventListener('contextmenu', function(e) {" +
		    "                        if (isSupermenu2705200527) {" +
		    "                            handleContextMenu(e, iframeDoc);" +
		    "                        }" +
		    "                    }, true);" + // Use capture phase
		    "                }" +
		    "            } catch (e) {" +
		    "                console.error('Error accessing iframe content: ', e);" +
		    "            }" +
		    "        });" +
		    "    }" +
		    "    function initialize() {" +
		    "        addContextMenuListener(document);" +
		    "        addListenersToIframes(document);" +
		    "        var observer = new MutationObserver(function(mutations) {" +
		    "            mutations.forEach(function(mutation) {" +
		    "                mutation.addedNodes.forEach(function(node) {" +
		    "                    if (node.nodeName === 'IFRAME') {" +
		    "                        try {" +
		    "                            var iframeDoc = node.contentDocument || node.contentWindow.document;" +
		    "                            if (iframeDoc) {" +
		    "                                addContextMenuListener(iframeDoc);" +
		    "                                addListenersToIframes(iframeDoc);" +
		    "                            }" +
		    "                        } catch (e) {" +
		    "                            console.error('Error accessing iframe content: ', e);" +
		    "                        }" +
		    "                    }" +
		    "                });" +
		    "                addContextMenuListener(document);" +
		    "                addListenersToIframes(document);" +
		    "            });" +
		    "        });" +
		    "        observer.observe(document.body, { childList: true, subtree: true });" +
		    "    }" +
		    "    if (document.readyState === 'loading') {" +
		    "        document.addEventListener('DOMContentLoaded', initialize);" +
		    "    } else {" +
		    "        initialize();" +
		    "    }" +
		    "})();",
		    null
		);
		
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Blockad/skipvideoad.txt").equals("1")) {
			_w.loadUrl("javascript:(function() {\n    var adsSkipped = false;\n\n    function skipAds() {\n        var videos = document.querySelectorAll('video, [src*=\".mp4\"], [src*=\".webm\"], [src*=\".ogv\"], [type*=\"video\"]');\n        for (var i = 0; i < videos.length; i++) {\n            var video = videos[i];\n            if (typeof video.currentTime !== 'undefined') {\n                video.currentTime = 65535;\n            }\n        }\n    }\n\n    function checkForKeywords() {\n        var regex = /".concat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Blockad/videopatterns.txt").concat("/;\n        var found = regex.test(document.body.innerText);\n        if (found && !adsSkipped) {\n            adsSkipped = true;\n            setTimeout(function() {\n                adsSkipped = false;\n            }, 2000); \n            skipAds();\n        }\n    }\n\n    function hasVideo() {\n        return document.querySelector('video') || document.querySelector('[src*=\".mp4\"]') || document.querySelector('[src*=\".webm\"]') || document.querySelector('[src*=\".ogv\"]') || document.querySelector('[type*=\"video\"]');\n    }\n\n    if (hasVideo()) {\n        var observer = new MutationObserver(function(mutations) {\n            mutations.forEach(function(mutation) {\n                if (mutation.type === 'childList' || mutation.type === 'characterData') {\n                    checkForKeywords();\n                }\n            });\n        });\n\n        var config = { childList: true, subtree: true, characterData: true, characterDataOldValue: true };\n\n        observer.observe(document.body, config);\n\n        checkForKeywords();\n    }\n})();\n")));
		}
	}
	
	
	public boolean _adblck(final WebView _w) {
		if (_w.equals(webview1)) {
			    return adbl;
		} else if (_w.equals(webview2)) {
			return adbl2;
		} else if (_w.equals(webview3)) {
			    return adbl3;
		} else if (_w.equals(webview4)) {
			return adbl4;
		} else if (_w.equals(webview5)) {
			return adbl5;
		} else if (_w.equals(webview6)) {
			return adbl6;
		} else {return false;}
	}
	
	
	public boolean _isaccess() {
		return (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Blockad/blockredir.txt").equals("1"));
	}
	
	
	public boolean _issuperm() {
		return (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Supermenu.txt").equals("1"));
	}
	
	
	public void _adsblocked() {
		adsblockedd++;
	}
	
	
	public void _accessdenied(final String _reg) {
		SketchwareUtil.showMessage(getApplicationContext(), "Цей сайт заблоковано блокувальником реклами.\n\n".concat(_reg));
	}
	
	
	public void _onpagefail(final WebView _w, final String _e) {
		SketchwareUtil.showMessage(getApplicationContext(), _e);
		if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/1.txt")) == 1) {
			_w.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/1.txt")));
		}
		if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/2.txt")) == 1) {
			_w.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/2.txt")));
		}
		if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/3.txt")) == 1) {
			_w.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/3.txt")));
		}
		if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/4.txt")) == 1) {
			_w.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/4.txt")));
		}
		if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/5.txt")) == 1) {
			_w.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/5.txt")));
		}
		if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/state/6.txt")) == 1) {
			_w.loadUrl(_replaceInstructions(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Bookmarklets/6.txt")));
		}
		_Reopentab();
		new histor2().execute(_w.getTitle());
		_w.evaluateJavascript(
		    "var isSupermenu2705200527 = false;" +
		    "(function() {" +
		    "    function handleContextMenu(e, doc) {" +
		    "        if (isSupermenu2705200527) {" +
		    "            e.preventDefault();" +
		    "            var element = e.target;" +
		    "            var elementCode = element.outerHTML;" +
		    "            var elementText = element.innerText;" +
		    "            var elementSrc = element.src || '';" +
		    "            var elementHref = '';" +
		    "            if (element.tagName === 'A') {" +
		    "                elementHref = element.href;" +
		    "            } else {" +
		    "                var parent = element.closest('a');" +
		    "                if (parent) {" +
		    "                    elementHref = parent.href;" +
		    "                }" +
		    "            }" +
		    "            var data = {" +
		    "                code: elementCode," +
		    "                text: elementText," +
		    "                src: elementSrc," +
		    "                href: elementHref" +
		   // "                wtext:" +
		    "            };" +
		    "            window.AndroidInterface.processElementInfo(JSON.stringify(data));" +
		    "        }" +
		    "    }" +
		    "    function addContextMenuListener(doc) {" +
		    "        if (!doc.contextMenuListenerAdded) {" +
		    "            doc.contextMenuListenerAdded = true;" +
		    "            doc.addEventListener('contextmenu', function(e) {" +
		    "                if (isSupermenu2705200527) {" +
		    "                    handleContextMenu(e, doc);" +
		    "                }" +
		    "            }, true);" + // Use capture phase
		    "            var style = doc.createElement('style');" +
		    "            style.type = 'text/css';" +
		    "            style.innerHTML = '* { user-select: ' + (isSupermenu2705200527 ? 'none !important' : 'auto !important') + '; }';" +
		    "            doc.head.appendChild(style);" +
		    "        }" +
		    "    }" +
		    "    function addListenersToIframes(doc) {" +
		    "        var iframes = doc.querySelectorAll('iframe');" +
		    "        iframes.forEach(function(iframe) {" +
		    "            try {" +
		    "                var iframeDoc = iframe.contentDocument || iframe.contentWindow.document;" +
		    "                if (iframeDoc && !iframeDoc.contextMenuListenerAdded) {" +
		    "                    addContextMenuListener(iframeDoc);" +
		    "                    var observer = new MutationObserver(function(mutations) {" +
		    "                        mutations.forEach(function(mutation) {" +
		    "                            if (mutation.addedNodes.length > 0) {" +
		    "                                addContextMenuListener(iframeDoc);" +
		    "                            }" +
		    "                        });" +
		    "                    });" +
		    "                    observer.observe(iframeDoc.body, { childList: true, subtree: true });" +
		    "                    iframe.contentWindow.addEventListener('contextmenu', function(e) {" +
		    "                        if (isSupermenu2705200527) {" +
		    "                            handleContextMenu(e, iframeDoc);" +
		    "                        }" +
		    "                    }, true);" + // Use capture phase
		    "                }" +
		    "            } catch (e) {" +
		    "                console.error('Error accessing iframe content: ', e);" +
		    "            }" +
		    "        });" +
		    "    }" +
		    "    function initialize() {" +
		    "        addContextMenuListener(document);" +
		    "        addListenersToIframes(document);" +
		    "        var observer = new MutationObserver(function(mutations) {" +
		    "            mutations.forEach(function(mutation) {" +
		    "                mutation.addedNodes.forEach(function(node) {" +
		    "                    if (node.nodeName === 'IFRAME') {" +
		    "                        try {" +
		    "                            var iframeDoc = node.contentDocument || node.contentWindow.document;" +
		    "                            if (iframeDoc) {" +
		    "                                addContextMenuListener(iframeDoc);" +
		    "                                addListenersToIframes(iframeDoc);" +
		    "                            }" +
		    "                        } catch (e) {" +
		    "                            console.error('Error accessing iframe content: ', e);" +
		    "                        }" +
		    "                    }" +
		    "                });" +
		    "                addContextMenuListener(document);" +
		    "                addListenersToIframes(document);" +
		    "            });" +
		    "        });" +
		    "        observer.observe(document.body, { childList: true, subtree: true });" +
		    "    }" +
		    "    if (document.readyState === 'loading') {" +
		    "        document.addEventListener('DOMContentLoaded', initialize);" +
		    "    } else {" +
		    "        initialize();" +
		    "    }" +
		    "})();",
		    null
		);
		
		_w.loadUrl(_replaceInstructions("javascript:(function() {\n\n  var applyNightMode = function(window) {\n    (function(document) {\n      var css = 'html{background:#$colbg$ !important}html *{background:none !important;color:#$coltext$ !important;border-color:#$colbg$ !important;border-width:0 !important}html a,html a *{color:#$coladd$ !important;text-decoration:underline !important}html a:visited,html a:visited *,html a:active,html a:active *{color:#$colhint$ !important}html a:hover,html a:hover *{color:#$colhint$ !important;background:#$colbg$ !important}html input,html select,html button,html textarea{background:#$colbg$ !important;border:1px solid #$colb1$ !important;border-top-color:#$colb2$ !important;border-bottom-color:#$colb1$ !important}html input[type=button],html input[type=submit],html input[type=reset],html input[type=image],html button{border-top-color:#$colb1$ !important;border-bottom-color:#$colb2$ !important}html input:focus,html select:focus,html option:focus,html button:focus,html textarea:focus{background:#$colbg$ !important;color:#$colfield$ !important;border-color:#$colb1$ #$colb2$ #$colrb1$ !important;outline:2px solid #$colrb2$ !important}html input[type=button]:focus,html input[type=submit]:focus,html input[type=reset]:focus,html input[type=image]:focus,html button:focus{border-color:#$colb1$ #$colb2$ #$colrb2$ !important}html input[type=radio]{background:none !important;border-color:#$colb1$ !important;border-width:0 !important}html img[src],html input[type=image]{opacity:1}html img[src]:hover,html input[type=image]:hover{opacity:1}html,html body{scrollbar-base-color:#$colb1$ !important;scrollbar-face-color:#$colb2$ !important;scrollbar-shadow-color:#$colhint$ !important;scrollbar-darkshadow-color:#$colhint$ !important;scrollbar-track-color:#$colrb1$ !important;scrollbar-arrow-color:#$colrb2$ !important;scrollbar-3dlight-color:#$colb1$ !important}';\n      var styleNode = document.createElement('style');\n      styleNode.type = 'text/css';\n      styleNode.appendChild(document.createTextNode(css));\n      var head = document.head || document.getElementsByTagName('head')[0];\n      head.appendChild(styleNode);\n    })(window.document);\n    for (var i = 0, frame; frame = window.frames[i]; i++) {\n      try {\n        applyNightMode(frame);\n      } catch (e) {}\n    }\n  };\n\n  applyNightMode(window);\n\n})();\n"));
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}