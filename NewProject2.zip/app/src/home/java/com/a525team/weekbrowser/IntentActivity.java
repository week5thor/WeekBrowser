package com.a525team.weekbrowser;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class IntentActivity extends Activity {
	
	private String filePath = "";
	private String content = "";
	private boolean isfree = false;
	
	private ArrayList<String> skin = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> tab = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> window = new ArrayList<>();
	
	private LinearLayout linear1;
	private TextView textview1;
	
	private Intent thema = new Intent();
	private Intent intent2 = new Intent();
	private AlertDialog.Builder d;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.intent);
		initialize(_savedInstanceState);
		
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			||checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
			} else {
				initializeLogic();
			}
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		if(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt"))==0)
		{if ( Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {setTheme(android.R.style.Theme_Holo_Light);}else {setTheme(android.R.style.Theme_Black);}}
		
		else if(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt"))==1||Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt"))==2)
		{if ( Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {setTheme(android.R.style.Theme_Holo);}else {setTheme(android.R.style.Theme_Black);}
		} else{String filePath = "/storage/emulated/0/WeekBrowser/CustomTheme/style.txt";
				        String themeValue = FileUtil.readFile(filePath);
				
				        if (themeValue.equals("1") || (themeValue.equals("3") || themeValue.equals("5")) && Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB) {
						            setTheme(android.R.style.Theme_Black);
						        } else if (themeValue.equals("2") || (themeValue.equals("4") || themeValue.equals("6")) && Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB) {
						            setTheme(android.R.style.Theme_Light);
						        } else if (themeValue.equals("3") || (themeValue.equals("5")) && Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
						            setTheme(android.R.style.Theme_Holo);
						        } else if (themeValue.equals("4") || (themeValue.equals("6")) && Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
						            setTheme(android.R.style.Theme_Holo_Light);
						        } else if (themeValue.equals("5")) {
						            setTheme(android.R.style.Theme_Material);
						        } else if (themeValue.equals("6")) {
						            setTheme(android.R.style.Theme_Material_Light);
						        }}
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.intent);
		linear1 = findViewById(R.id.linear1);
		textview1 = findViewById(R.id.textview1);
		d = new AlertDialog.Builder(this);
	}
	
	private void initializeLogic() {
		intent2 = getIntent();
		if (intent2 != null && intent2.getData() != null) {
			    Uri fileUri = intent2.getData();
			    filePath = fileUri.getPath();
		}
		
		if ((!filePath.isEmpty() && filePath.matches("^.*[.]wesk$")) && filePath.contains("/storage")) {
			content = FileUtil.readFile(filePath);
			if (!content.equals("")) {
				skin = new Gson().fromJson(content, new TypeToken<ArrayList<String>>(){}.getType());
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/bg.txt", skin.get((int)(0)));
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg.txt", skin.get((int)(1)));
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg2.txt", skin.get((int)(2)));
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg.txt", skin.get((int)(3)));
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg2.txt", skin.get((int)(4)));
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt", skin.get((int)(5)));
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/textfield.txt", skin.get((int)(6)));
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt", skin.get((int)(7)));
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt", skin.get((int)(8)));
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt", skin.get((int)(9)));
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt", skin.get((int)(10)));
				try{
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/style.txt", skin.get((int)(11)));
				}catch(Exception e){
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/style.txt", "3");
				}
				try{
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/roundness.txt", skin.get((int)(12)));
				}catch(Exception e){
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/roundness.txt", "0");
				}
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt", "3");
				thema.setClass(getApplicationContext(), SettingsActivity.class);
				startActivity(thema);
				finish();
			}
		}
		if ((!filePath.isEmpty() && filePath.matches("^.*[.]skin$")) && filePath.contains("/storage")) {
			content = FileUtil.readFile(filePath);
			if (!content.equals("")) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/bg.txt", extractColor(content, "KeyboardBackgroundStartColor="));
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg.txt", extractColor(content, "KeyBackEndColor="));
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg2.txt", extractColor(content, "KeyBackStartColor="));
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg.txt", extractColor(content, "SpecKeyBackEndColor="));
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg2.txt", extractColor(content, "SpecKeyBackStartColor="));
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt", extractColor(content, "KeyTextColor="));
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/textfield.txt", extractColor(content, "KeyTextColor="));
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt", extractColor(content, "SpecKeyTextColor="));
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt", extractColor(content, "KeySymbolColor="));
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt", extractColor(content, "KeyTextColor="));
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt", extractColor(content, "SpecKeyTextColor="));
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/roundness.txt", extractColo(content, "KeyBackCornerX="));
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt", "3");
				thema.setClass(getApplicationContext(), SettingsActivity.class);
				startActivity(thema);
				finish();
			}
		}
		tab = new Gson().fromJson(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Tabs.json"), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		if (!FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/sametab")) {
			if (!intent2.getData().toString().isEmpty() && !intent2.getData().toString().startsWith("https://multilink.weekbrowser.com/")) {
				for (int i = 0; i < (int)(6); i++) {
					if (tab.get((int)i).get("url").toString().equals("about:blank")) {
						tab.get((int)i).put("name", "🌚🌞🌝");
						tab.get((int)i).put("url", intent2.getData().toString());
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Tabs.json", new Gson().toJson(tab));
						if (!FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/bgtab")) {
							FileUtil.writeFile("/storage/emulated/0/WeekBrowser/activeTab.txt", String.valueOf((long)(i)));
						}
						isfree = true;
						break;
					}
					else {
						
					}
				}
				FileUtil.deleteFile("/storage/emulated/0/WeekBrowser/bgtab");
				if (isfree) {
					thema.setClass(getApplicationContext(), MainActivity.class);
					startActivity(thema);
					finish();
				}
				if (!isfree) {
					d.setTitle("НЕМАЄ ВІЛЬНИХ СЛОТІВ");
					d.setMessage("Всі слоти вкладок зайняті. Відкрити посилання у останньому слоті?");
					d.setCancelable(false);
					d.setPositiveButton("ТАК", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							tab.get((int)5).put("name", "🌚🌞🌝");
							tab.get((int)5).put("url", intent2.getData().toString());
							FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Tabs.json", new Gson().toJson(tab));
							FileUtil.writeFile("/storage/emulated/0/WeekBrowser/activeTab.txt", "5");
							thema.setClass(getApplicationContext(), MainActivity.class);
							startActivity(thema);
							finish();
						}
					});
					d.setNegativeButton("НІ", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							finish();
						}
					});
					d.create().show();
				}
			}
		}
		else {
			if (!intent2.getData().toString().startsWith("https://multilink.weekbrowser.com/")) {
				tab.get((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt"))).put("name", "🌚🌞🌝");
				tab.get((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/activeTab.txt"))).put("url", intent2.getData().toString());
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Tabs.json", new Gson().toJson(tab));
				FileUtil.deleteFile("/storage/emulated/0/WeekBrowser/sametab");
				thema.setClass(getApplicationContext(), MainActivity.class);
				startActivity(thema);
				finish();
			}
		}
		if (!intent2.getData().toString().isEmpty() && intent2.getData().toString().startsWith("https://multilink.weekbrowser.com/")) {
			d.setTitle("ПОПЕРЕДЖЕННЯ");
			d.setMessage("Якщо натиснете \"ОК\", Ваші попередні вкладки пропадуть, і заміняться на сайти з мультипосилання. Ви хочете відкрити його?");
			d.setPositiveButton("Так", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					String[] subLinks = intent2.getData().toString().split("%%%%%");
					        // Отримання потрібних підпосилань і їх обробка
					        tab.get((int)0).put("url", subLinks[1]);
					        tab.get((int)1).put("url", subLinks[2]);
					        tab.get((int)2).put("url", subLinks[3]);
					        tab.get((int)3).put("url", subLinks[4]);
					        tab.get((int)4).put("url", subLinks[5]);
					        tab.get((int)5).put("url", subLinks[6]);
					        
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Tabs.json", new Gson().toJson(tab));
					window = new Gson().fromJson(FileUtil.readFile("/storage/emulated/0/WeekBrowser/windows.json"), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					try{
						window.get((int)0).put("e", subLinks[7].charAt(0));
						window.get((int)0).put("px", subLinks[7].charAt(1));
						window.get((int)0).put("py", subLinks[7].charAt(2));
						window.get((int)0).put("sx", subLinks[7].charAt(3));
						window.get((int)0).put("sy", subLinks[7].charAt(4));
						window.get((int)1).put("e", subLinks[7].charAt(5));
						window.get((int)1).put("px", subLinks[7].charAt(6));
						window.get((int)1).put("py", subLinks[7].charAt(7));
						window.get((int)1).put("sx", subLinks[7].charAt(8));
						window.get((int)1).put("sy", subLinks[7].charAt(9));
						window.get((int)2).put("e", subLinks[7].charAt(10));
						window.get((int)2).put("px", subLinks[7].charAt(11));
						window.get((int)2).put("py", subLinks[7].charAt(12));
						window.get((int)2).put("sx", subLinks[7].charAt(13));
						window.get((int)2).put("sy", subLinks[7].charAt(14));
						window.get((int)3).put("e", subLinks[7].charAt(15));
						window.get((int)3).put("px", subLinks[7].charAt(16));
						window.get((int)3).put("py", subLinks[7].charAt(17));
						window.get((int)3).put("sx", subLinks[7].charAt(18));
						window.get((int)3).put("sy", subLinks[7].charAt(19));
						window.get((int)4).put("e", subLinks[7].charAt(20));
						window.get((int)4).put("px", subLinks[7].charAt(21));
						window.get((int)4).put("py", subLinks[7].charAt(22));
						window.get((int)4).put("sx", subLinks[7].charAt(23));
						window.get((int)4).put("sy", subLinks[7].charAt(24));
						window.get((int)5).put("e", subLinks[7].charAt(25));
						window.get((int)5).put("px", subLinks[7].charAt(26));
						window.get((int)5).put("py", subLinks[7].charAt(27));
						window.get((int)5).put("sx", subLinks[7].charAt(28));
						window.get((int)5).put("sy", subLinks[7].charAt(29));
						window.get((int)6).put("w", "1");
					}catch(Exception e){
						window = new Gson().fromJson(FileUtil.readFile("/storage/emulated/0/WeekBrowser/windows.json"), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
						window.get((int)6).put("w", "0");
					}
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/windows.json", new Gson().toJson(window));
					thema.setClass(getApplicationContext(), MainActivity.class);
					/*
thema.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
*/
					startActivity(thema);
					finish();
				}
			});
			d.setNegativeButton("Ні", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					finish();
				}
			});
			d.create().show();
		}
	}
	
	public void _extra() {
	}
	    public static String extractColor(String inputText, String prefix) {
		        String regex = prefix + "0x" + "([a-fA-F0-9]+)";
		        
		        Pattern pattern = Pattern.compile(regex);
		        Matcher matcher = pattern.matcher(inputText);
		        
		        if (matcher.find()) {
			            return matcher.group(1);
			        } else {
			           regex = prefix + "#" + "([a-fA-F0-9]+)";
			        
			        pattern = Pattern.compile(regex);
			        matcher = pattern.matcher(inputText);
			        
			        if (matcher.find()) {
				            return matcher.group(1);
				        } else {return null;} 
			        }
		    }
	
	public static String extractColo(String inputText, String prefix) {
		        String regex = prefix + "([a-fA-F0-9]+)";
		        
		        Pattern pattern = Pattern.compile(regex);
		        Matcher matcher = pattern.matcher(inputText);
		        
		        if (matcher.find()) {
			            return matcher.group(1);
			        } else {
			        return null;
			        }
		    }
	
	{
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}