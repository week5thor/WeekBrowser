package com.a525team.weekbrowser;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.regex.*;
import org.json.*;

public class CustomthemeActivity extends Activity {
	
	public final int REQ_CD_F = 101;
	
	private double r = 0;
	private double g = 0;
	private double b = 0;
	private double a = 0;
	private String lol = "";
	private boolean isColorpast = false;
	private String nam = "";
	private String testd = "";
	private String doyou = "";
	private String no = "";
	private String yes = "";
	
	private ArrayList<String> skin = new ArrayList<>();
	private ArrayList<String> languag = new ArrayList<>();
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private TextView textview2;
	private TextView hintt;
	private Button importt;
	private AutoCompleteTextView name;
	private Button export;
	private TextView textview4;
	private HorizontalScrollView hscroll1;
	private TextView textview5;
	private HorizontalScrollView hscroll2;
	private TextView stl;
	private TextView hinttt;
	private SeekBar style;
	private LinearLayout linear5;
	private LinearLayout linear8;
	private Button colorbutton;
	private LinearLayout linear9;
	private Button monet;
	private TextView hint2;
	private TextView stdtxt;
	private CheckBox checkbox1;
	private RadioGroup radiogroup1;
	private LinearLayout linear2;
	private EditText bg;
	private TextView textview8;
	private EditText button1;
	private EditText button2;
	private TextView textview9;
	private EditText red1;
	private EditText red2;
	private EditText corner;
	private LinearLayout linear3;
	private EditText text;
	private EditText textfield;
	private EditText additional;
	private EditText hint;
	private EditText buttontext;
	private EditText redbuttontext;
	private LinearLayout linear4;
	private LinearLayout linear7;
	private SeekBar red;
	private SeekBar green;
	private SeekBar blue;
	private SeekBar alpha;
	private Button colorpicked;
	private TextView color;
	private Button copy;
	private Button temproarystd;
	private Button refresh;
	private RadioButton radiobutton1;
	private RadioButton radiobutton2;
	
	private Intent j = new Intent();
	private AlertDialog.Builder d;
	private Intent f = new Intent(Intent.ACTION_GET_CONTENT);
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.customtheme);
		initialize(_savedInstanceState);
		
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			||checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
			} else {
				initializeLogic();
			}
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		if(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt"))==0)
		{if ( Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {setTheme(android.R.style.Theme_Holo_Light);}else {setTheme(android.R.style.Theme_Black);}}
		
		else if(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt"))==1||Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt"))==2)
		{if ( Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {setTheme(android.R.style.Theme_Holo);}else {setTheme(android.R.style.Theme_Black);}
		} else{String filePath = "/storage/emulated/0/WeekBrowser/CustomTheme/style.txt";
				        String themeValue = FileUtil.readFile(filePath);
				
				        if (themeValue.equals("1") || (themeValue.equals("3") || themeValue.equals("5")) && Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB) {
						            setTheme(android.R.style.Theme_Black);
						        } else if (themeValue.equals("2") || (themeValue.equals("4") || themeValue.equals("6")) && Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB) {
						            setTheme(android.R.style.Theme_Light);
						        } else if (themeValue.equals("3") || (themeValue.equals("5")) && Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
						            setTheme(android.R.style.Theme_Holo);
						        } else if (themeValue.equals("4") || (themeValue.equals("6")) && Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
						            setTheme(android.R.style.Theme_Holo_Light);
						        } else if (themeValue.equals("5")) {
						            setTheme(android.R.style.Theme_Material);
						        } else if (themeValue.equals("6")) {
						            setTheme(android.R.style.Theme_Material_Light);
						        }}
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.customtheme);
		vscroll1 = findViewById(R.id.vscroll1);
		linear1 = findViewById(R.id.linear1);
		textview2 = findViewById(R.id.textview2);
		hintt = findViewById(R.id.hintt);
		importt = findViewById(R.id.importt);
		name = findViewById(R.id.name);
		export = findViewById(R.id.export);
		textview4 = findViewById(R.id.textview4);
		hscroll1 = findViewById(R.id.hscroll1);
		textview5 = findViewById(R.id.textview5);
		hscroll2 = findViewById(R.id.hscroll2);
		stl = findViewById(R.id.stl);
		hinttt = findViewById(R.id.hinttt);
		style = findViewById(R.id.style);
		linear5 = findViewById(R.id.linear5);
		linear8 = findViewById(R.id.linear8);
		colorbutton = findViewById(R.id.colorbutton);
		linear9 = findViewById(R.id.linear9);
		monet = findViewById(R.id.monet);
		hint2 = findViewById(R.id.hint2);
		stdtxt = findViewById(R.id.stdtxt);
		checkbox1 = findViewById(R.id.checkbox1);
		radiogroup1 = findViewById(R.id.radiogroup1);
		linear2 = findViewById(R.id.linear2);
		bg = findViewById(R.id.bg);
		textview8 = findViewById(R.id.textview8);
		button1 = findViewById(R.id.button1);
		button2 = findViewById(R.id.button2);
		textview9 = findViewById(R.id.textview9);
		red1 = findViewById(R.id.red1);
		red2 = findViewById(R.id.red2);
		corner = findViewById(R.id.corner);
		linear3 = findViewById(R.id.linear3);
		text = findViewById(R.id.text);
		textfield = findViewById(R.id.textfield);
		additional = findViewById(R.id.additional);
		hint = findViewById(R.id.hint);
		buttontext = findViewById(R.id.buttontext);
		redbuttontext = findViewById(R.id.redbuttontext);
		linear4 = findViewById(R.id.linear4);
		linear7 = findViewById(R.id.linear7);
		red = findViewById(R.id.red);
		green = findViewById(R.id.green);
		blue = findViewById(R.id.blue);
		alpha = findViewById(R.id.alpha);
		colorpicked = findViewById(R.id.colorpicked);
		color = findViewById(R.id.color);
		copy = findViewById(R.id.copy);
		temproarystd = findViewById(R.id.temproarystd);
		refresh = findViewById(R.id.refresh);
		radiobutton1 = findViewById(R.id.radiobutton1);
		radiobutton2 = findViewById(R.id.radiobutton2);
		d = new AlertDialog.Builder(this);
		f.setType("*/*");
		f.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		
		importt.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(f, REQ_CD_F);
			}
		});
		
		name.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				nam = _charSeq;
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		export.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (nam.equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "ПОМИЛКА! БУДЬТЕ УВАЖНІШІ, НЕМАЄ НАЗВИ СКІНА!");
				}
				else {
					skin.clear();
					skin.add(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/bg.txt"));
					skin.add(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg.txt"));
					skin.add(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg2.txt"));
					skin.add(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg.txt"));
					skin.add(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg2.txt"));
					skin.add(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"));
					skin.add(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/textfield.txt"));
					skin.add(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt"));
					skin.add(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt"));
					skin.add(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"));
					skin.add(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"));
					skin.add(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/style.txt"));
					skin.add(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/roundness.txt"));
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CUSTOMSKINLIBRARY/".concat(nam.concat(".wesk")), new Gson().toJson(skin));
					SketchwareUtil.showMessage(getApplicationContext(), "СКІН ЗБЕРЕЖЕНО У:\n/storage/emulated/0/WeekBrowser/CUSTOMSKINLIBRARY");
				}
			}
		});
		
		style.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged(SeekBar _param1, int _param2, boolean _param3) {
				final int _progressValue = _param2;
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/style.txt", String.valueOf((long)(style.getProgress() + 2)));
				switch((int)style.getProgress()) {
					case ((int)0): {
						stl.setText("Android 1");
						break;
					}
					case ((int)1): {
						try{
							stl.setText("Holo ".concat(languag.get((int)(96))));
						}catch(Exception e){
							if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
								stl.setText("Holo Dark");
							}
							else {
								stl.setText("Holo Темний");
							}
						}
						break;
					}
					case ((int)2): {
						try{
							stl.setText("Holo ".concat(languag.get((int)(97))));
						}catch(Exception e){
							if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
								stl.setText("Holo Light");
							}
							else {
								stl.setText("Holo Світлий");
							}
						}
						break;
					}
					case ((int)3): {
						try{
							stl.setText("Material ".concat(languag.get((int)(96))));
						}catch(Exception e){
							if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
								stl.setText("Material Dark");
							}
							else {
								stl.setText("Material Темний");
							}
						}
						break;
					}
					case ((int)4): {
						try{
							stl.setText("Material ".concat(languag.get((int)(97))));
						}catch(Exception e){
							if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
								stl.setText("Material Light");
							}
							else {
								stl.setText("Material Світлий");
							}
						}
						break;
					}
					default: {
						stl.setText("???");
						break;
					}
				}
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar _param1) {
				
			}
			
			@Override
			public void onStopTrackingTouch(SeekBar _param2) {
				
			}
		});
		
		colorbutton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (isColorpast) {
					isColorpast = false;
					try{
						colorbutton.setText(languag.get((int)(100)));
					}catch(Exception e){
						if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
							colorbutton.setText("AFTER CLICK HERE CLICK ON TEXTAREA FOR PASTE COLOR FROM COLORPICKER");
						}
						else {
							colorbutton.setText("ПІСЛЯ НАТИСКАННЯ СЮДИ НАТИСКАЙТЕ НА ТЕКСТОВЕ ПОЛЕ, І ТУДИ ВСТАВИТЬСЯ КОЛІР, ЯКИЙ ВИ НАКРУТИЛИ В ПАЛІТРІ");
						}
					}
				}
				else {
					isColorpast = true;
					try{
						colorbutton.setText(languag.get((int)(101)));
					}catch(Exception e){
						if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
							colorbutton.setText("AFTER CLICK HERE YOU MAY TYPE A COLOR DIRECTLY FROM KEYBARD AGAIN");
						}
						else {
							colorbutton.setText("ПІСЛЯ НАТИСКАННЯ СЮДИ ВИ ЗНОВУ ЗМОЖЕТЕ НАБРАТИ КОЛІР ПРЯМІСІНЬКО З КЛАВІАТУРИ");
						}
					}
				}
			}
		});
		
		monet.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				j.setClass(getApplicationContext(), MonetActivity.class);
				startActivity(j);
			}
		});
		
		hint2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				try{
					testd = languag.get((int)(105));
				}catch(Exception e){
					if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
						testd = "TEST DIALOG";
					}
					else {
						testd = "ТЕСТОВИЙ ДІАЛОГ";
					}
				}
				try{
					doyou = languag.get((int)(106));
				}catch(Exception e){
					if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
						doyou = "Are you sure to want make nothing?";
					}
					else {
						doyou = "Ви впевнені, що хочете зробити нічого?";
					}
				}
				try{
					yes = languag.get((int)(108));
				}catch(Exception e){
					if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
						yes = "YES";
					}
					else {
						yes = "ТАК";
					}
				}
				try{
					no = languag.get((int)(107));
				}catch(Exception e){
					if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
						no = "NO";
					}
					else {
						no = "НІ";
					}
				}
				d.setTitle(testd);
				d.setMessage(doyou);
				d.setPositiveButton(yes, new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				d.setNegativeButton(no, new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				d.create().show();
			}
		});
		
		bg.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (isColorpast) {
					bg.setText(color.getText().toString());
				}
			}
		});
		
		bg.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/bg.txt", _charSeq);
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (isColorpast) {
					button1.setText(color.getText().toString());
				}
			}
		});
		
		button1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg.txt", _charSeq);
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (isColorpast) {
					button2.setText(color.getText().toString());
				}
			}
		});
		
		button2.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg2.txt", _charSeq);
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		red1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (isColorpast) {
					red1.setText(color.getText().toString());
				}
			}
		});
		
		red1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg.txt", _charSeq);
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		red2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (isColorpast) {
					red2.setText(color.getText().toString());
				}
			}
		});
		
		red2.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg2.txt", _charSeq);
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		corner.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/roundness.txt", _charSeq);
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		text.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (isColorpast) {
					text.setText(color.getText().toString());
				}
			}
		});
		
		text.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt", _charSeq);
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		textfield.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (isColorpast) {
					textfield.setText(color.getText().toString());
				}
			}
		});
		
		textfield.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/textfield.txt", _charSeq);
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		additional.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (isColorpast) {
					additional.setText(color.getText().toString());
				}
			}
		});
		
		additional.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt", _charSeq);
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		hint.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (isColorpast) {
					hint.setText(color.getText().toString());
				}
			}
		});
		
		hint.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt", _charSeq);
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		buttontext.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (isColorpast) {
					buttontext.setText(color.getText().toString());
				}
			}
		});
		
		buttontext.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt", _charSeq);
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		redbuttontext.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (isColorpast) {
					redbuttontext.setText(color.getText().toString());
				}
			}
		});
		
		redbuttontext.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt", _charSeq);
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		red.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged(SeekBar _param1, int _param2, boolean _param3) {
				final int _progressValue = _param2;
				r = _progressValue;
				color.setText(_toHexStr(alpha.getProgress()).concat(_toHexStr(red.getProgress()).concat(_toHexStr(green.getProgress()).concat(_toHexStr(blue.getProgress())))));
				colorpicked.setBackgroundColor((int)Long.parseLong(color.getText().toString(),16));
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar _param1) {
				
			}
			
			@Override
			public void onStopTrackingTouch(SeekBar _param2) {
				
			}
		});
		
		green.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged(SeekBar _param1, int _param2, boolean _param3) {
				final int _progressValue = _param2;
				g = _progressValue;
				color.setText(_toHexStr(alpha.getProgress()).concat(_toHexStr(red.getProgress()).concat(_toHexStr(green.getProgress()).concat(_toHexStr(blue.getProgress())))));
				colorpicked.setBackgroundColor((int)Long.parseLong(color.getText().toString(),16));
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar _param1) {
				
			}
			
			@Override
			public void onStopTrackingTouch(SeekBar _param2) {
				
			}
		});
		
		blue.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged(SeekBar _param1, int _param2, boolean _param3) {
				final int _progressValue = _param2;
				b = _progressValue;
				color.setText(_toHexStr(alpha.getProgress()).concat(_toHexStr(red.getProgress()).concat(_toHexStr(green.getProgress()).concat(_toHexStr(blue.getProgress())))));
				colorpicked.setBackgroundColor((int)Long.parseLong(color.getText().toString(),16));
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar _param1) {
				
			}
			
			@Override
			public void onStopTrackingTouch(SeekBar _param2) {
				
			}
		});
		
		alpha.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged(SeekBar _param1, int _param2, boolean _param3) {
				final int _progressValue = _param2;
				a = _progressValue;
				color.setText(_toHexStr(alpha.getProgress()).concat(_toHexStr(red.getProgress()).concat(_toHexStr(green.getProgress()).concat(_toHexStr(blue.getProgress())))));
				colorpicked.setBackgroundColor((int)Long.parseLong(color.getText().toString(),16));
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar _param1) {
				
			}
			
			@Override
			public void onStopTrackingTouch(SeekBar _param2) {
				
			}
		});
		
		colorpicked.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		color.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", color.getText().toString()));
			}
		});
		
		copy.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.writeFile("/storage/emulated/0/ColorPicker/intent.txt", "com.a525team.weekbrowser");
				j = getPackageManager().getLaunchIntentForPackage("com.a525team.colorpicker");
				startActivity(j);
			}
		});
		
		temproarystd.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				copy.setBackgroundColor(0xFF33B5E5);
				refresh.setBackgroundColor(0xFFB71C1C);
				temproarystd.setBackgroundColor(0xFF33B5E5);
				colorbutton.setBackgroundColor(0xFF33B5E5);
				monet.setBackgroundColor(0xFF33B5E5);
				getWindow().getDecorView().setBackgroundColor(Color.parseColor("#111111"));
				colorbutton.setTextColor(0xFF000000);
				copy.setTextColor(0xFF000000);
				temproarystd.setTextColor(0xFF000000);
				monet.setTextColor(0xFF000000);
				refresh.setTextColor(0xFFFFFFFF);
				bg.setTextColor(0xFFFFFFFF);
				button1.setTextColor(0xFFFFFFFF);
				button2.setTextColor(0xFFFFFFFF);
				red1.setTextColor(0xFFFFFFFF);
				red2.setTextColor(0xFFFFFFFF);
				textfield.setTextColor(0xFFFFFFFF);
				text.setTextColor(0xFFFFFFFF);
				additional.setTextColor(0xFFFFFFFF);
				hint.setTextColor(0xFFFFFFFF);
				corner.setTextColor(0xFFFFFFFF);
				buttontext.setTextColor(0xFFFFFFFF);
				name.setTextColor(0xFFFFFFFF);
				name.setHintTextColor(0xFFBDBDBD);
				redbuttontext.setTextColor(0xFFFFFFFF);
				bg.setHintTextColor(0xFFBDBDBD);
				button2.setHintTextColor(0xFFBDBDBD);
				corner.setHintTextColor(0xFFBDBDBD);
				red1.setHintTextColor(0xFFBDBDBD);
				red2.setHintTextColor(0xFFBDBDBD);
				text.setHintTextColor(0xFFBDBDBD);
				textfield.setHintTextColor(0xFFBDBDBD);
				hint.setHintTextColor(0xFFBDBDBD);
				additional.setHintTextColor(0xFFBDBDBD);
				buttontext.setHintTextColor(0xFFBDBDBD);
				export.setBackgroundColor(0xFF33B5E5);
				export.setTextColor(0xFF000000);
				importt.setBackgroundColor(0xFF33B5E5);
				importt.setTextColor(0xFF000000);
				button1.setHintTextColor(0xFFBDBDBD);
				textview2.setTextColor(0xFFFFFFFF);
				textview4.setTextColor(0xFFFFFFFF);
				textview5.setTextColor(0xFFFFFFFF);
				textview8.setTextColor(0xFFFFFFFF);
				textview9.setTextColor(0xFFFFFFFF);
				color.setTextColor(0xFFFFFFFF);
				hintt.setTextColor(0xFFBDBDBD);
				hint2.setTextColor(0xFFBDBDBD);
				stdtxt.setTextColor(0xFFFFFFFF);
				checkbox1.setTextColor(0xFFFFFFFF);
				radiobutton1.setTextColor(0xFFFFFFFF);
				radiobutton2.setTextColor(0xFFFFFFFF);
				stl.setTextColor(0xFFFFFFFF);
				hinttt.setTextColor(0xFFBDBDBD);
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/style.txt")) < 3) {
					bg.setTextColor(0xFF000000);
					button1.setTextColor(0xFF000000);
					button2.setTextColor(0xFF000000);
					red1.setTextColor(0xFF000000);
					red2.setTextColor(0xFF000000);
					text.setTextColor(0xFF000000);
					textfield.setTextColor(0xFF000000);
					additional.setTextColor(0xFF000000);
					hint.setTextColor(0xFF000000);
					buttontext.setTextColor(0xFF000000);
					redbuttontext.setTextColor(0xFF000000);
					corner.setTextColor(0xFF000000);
				}
			}
		});
		
		refresh.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/CustomTheme/refresh", "");
				j.setClass(getApplicationContext(), CustomthemeActivity.class);
				startActivity(j);
				finish();
			}
		});
	}
	
	private void initializeLogic() {
		if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
			languag = new Gson().fromJson(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Language.welang"), new TypeToken<ArrayList<String>>(){}.getType());
		}
		bg.setText(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/bg.txt"));
		text.setText(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"));
		textfield.setText(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/textfield.txt"));
		additional.setText(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt"));
		hint.setText(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt"));
		button1.setText(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg.txt"));
		button2.setText(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg2.txt"));
		red1.setText(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg.txt"));
		red2.setText(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg2.txt"));
		buttontext.setText(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"));
		redbuttontext.setText(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"));
		corner.setText(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/roundness.txt"));
		temproarystd.performClick();
		style.setProgress((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/style.txt")) - 2);
		switch((int)style.getProgress()) {
			case ((int)0): {
				stl.setText("Android 1");
				break;
			}
			case ((int)1): {
				try{
					stl.setText("Holo ".concat(languag.get((int)(96))));
				}catch(Exception e){
					if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
						stl.setText("Holo Dark");
					}
					else {
						stl.setText("Holo Темний");
					}
				}
				break;
			}
			case ((int)2): {
				try{
					stl.setText("Holo ".concat(languag.get((int)(97))));
				}catch(Exception e){
					if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
						stl.setText("Holo Light");
					}
					else {
						stl.setText("Holo Світлий");
					}
				}
				break;
			}
			case ((int)3): {
				try{
					stl.setText("Material ".concat(languag.get((int)(96))));
				}catch(Exception e){
					if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
						stl.setText("Material Dark");
					}
					else {
						stl.setText("Material Темний");
					}
				}
				break;
			}
			case ((int)4): {
				try{
					stl.setText("Material ".concat(languag.get((int)(97))));
				}catch(Exception e){
					if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
						stl.setText("Material Light");
					}
					else {
						stl.setText("Material Світлий");
					}
				}
				break;
			}
			default: {
				stl.setText("???");
				break;
			}
		}
		if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.S) {
			
			monet.setVisibility(View.GONE);
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_F:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				j.setClass(getApplicationContext(), IntentActivity.class);
				j.setData(Uri.parse(_filePath.get((int)(0))));
				startActivity(j);
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	@Override
	public void onResume() {
		super.onResume();
		if (!FileUtil.readFile("/storage/emulated/0/ColorPicker/color.txt").isEmpty()) {
			red.setProgress((int)_fromHex(FileUtil.readFile("/storage/emulated/0/ColorPicker/color.txt").substring((int)(2), (int)(4))));
			green.setProgress((int)_fromHex(FileUtil.readFile("/storage/emulated/0/ColorPicker/color.txt").substring((int)(4), (int)(6))));
			blue.setProgress((int)_fromHex(FileUtil.readFile("/storage/emulated/0/ColorPicker/color.txt").substring((int)(6), (int)(8))));
			FileUtil.deleteFile("/storage/emulated/0/ColorPicker/intent.txt");
			FileUtil.deleteFile("/storage/emulated/0/ColorPicker/color.txt");
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/monofortextarea.txt").equals("1")) {
			bg.setTypeface(Typeface.MONOSPACE);
			button1.setTypeface(Typeface.MONOSPACE);
			button2.setTypeface(Typeface.MONOSPACE);
			red1.setTypeface(Typeface.MONOSPACE);
			red2.setTypeface(Typeface.MONOSPACE);
			text.setTypeface(Typeface.MONOSPACE);
			textfield.setTypeface(Typeface.MONOSPACE);
			additional.setTypeface(Typeface.MONOSPACE);
			hint.setTypeface(Typeface.MONOSPACE);
			buttontext.setTypeface(Typeface.MONOSPACE);
			redbuttontext.setTypeface(Typeface.MONOSPACE);
			corner.setTypeface(Typeface.MONOSPACE);
		}
		else {
			bg.setTypeface(Typeface.DEFAULT);
			button1.setTypeface(Typeface.DEFAULT);
			button2.setTypeface(Typeface.DEFAULT);
			red1.setTypeface(Typeface.DEFAULT);
			red2.setTypeface(Typeface.DEFAULT);
			text.setTypeface(Typeface.DEFAULT);
			textfield.setTypeface(Typeface.DEFAULT);
			additional.setTypeface(Typeface.DEFAULT);
			hint.setTypeface(Typeface.DEFAULT);
			buttontext.setTypeface(Typeface.DEFAULT);
			redbuttontext.setTypeface(Typeface.DEFAULT);
			corner.setTypeface(Typeface.DEFAULT);
		}
		if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/CustomTheme/refresh")) {
			FileUtil.deleteFile("/storage/emulated/0/WeekBrowser/CustomTheme/refresh");
						textview5.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt"),16));
			stdtxt.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
			checkbox1.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
			stl.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
			radiobutton1.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
			radiobutton2.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
			textview2.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt"),16));
			color.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt"),16));
			textview8.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt"),16));
			textview9.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt"),16));
						textview4.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt"),16));
			hintt.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt"),16));
			hinttt.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt"),16));
			hint2.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt"),16));
						refresh.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
						temproarystd.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						colorbutton.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
			export.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
			importt.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
						copy.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
			getWindow().getDecorView().setBackgroundColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/bg.txt"),16));
			
			bg.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/textfield.txt"),16));
			button1.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/textfield.txt"),16));
			button2.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/textfield.txt"),16));
			red1.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/textfield.txt"),16));
			red2.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/textfield.txt"),16));
			text.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/textfield.txt"),16));
			textfield.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/textfield.txt"),16));
			additional.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/textfield.txt"),16));
			hint.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/textfield.txt"),16));
			buttontext.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/textfield.txt"),16));
			redbuttontext.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/textfield.txt"),16));
			bg.setHintTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt"),16));
			button1.setHintTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt"),16));
			button2.setHintTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt"),16));
			red1.setHintTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt"),16));
			red2.setHintTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt"),16));
			text.setHintTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt"),16));
			hint.setHintTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt"),16));
			additional.setHintTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt"),16));
			hint.setHintTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt"),16));
			buttontext.setHintTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt"),16));
			redbuttontext.setHintTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt"),16));
			corner.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/textfield.txt"),16));
			corner.setHintTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt"),16));
			
			int color1 = (int) Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg.txt"), 16);
			int color2 = (int) Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg2.txt"), 16);
			final int roundness = Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/roundness.txt"));
			int rcolor1 = (int) Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg.txt"), 16);
			int rcolor2 = (int) Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg2.txt"), 16);
			
			copy.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
					    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
				}});
			export.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
					    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
				}});
			importt.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
					    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
				}});
			colorbutton.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
					    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
				}});
			temproarystd.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
					    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
				}});
			refresh.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
					    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
				}});
			
						
		}
		_language();
	}
	public String _toHexStr(final double _num) {
		if (_num < 16) {
			lol="0".concat(Integer.toHexString((int)_num));
		}
		else {
			lol=Integer.toHexString((int)_num);
		}
		return (lol);
	}
	
	
	public void _language() {
		try{
			textview2.setText(languag.get((int)(86)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				textview2.setText("THEME EDITOR");
			}
			else {
				textview2.setText("РЕДАКТОР ТЕМ");
			}
		}
		try{
			hintt.setText(languag.get((int)(87)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				hintt.setText("You are in theme editor. You need to type colors in hexadecimal format AARRGGBB, in which A — alpha/opacity, R — red, G — green and B — blue. Every color has 2 digits which from 0 to F (0123456789ABCDEF). Register of letters (but this are actually a digits) isn't necessary");
			}
			else {
				hintt.setText("Ви знаходитеся в редакторі тем. Вам потрібно вказати кольори у шістнадцятковому форматі у форматі AARRGGBB, де A — прозорість, R — червоний, G — зелений, а B — синій. На кожен колір виділено по 2 цифри, яка від 0 до F (0123456789ABCDEF). Регістр букв (які насправді рахуються як цифри) неважливий");
			}
		}
		try{
			hinttt.setText(languag.get((int)(93)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				hinttt.setText("If you change this value, it change design of radiobuttons, chechboxes and windows but you need to restart this browser");
			}
			else {
				hinttt.setText("Якщо Ви змінюєте це значення, у вас зміниться вигляд деяких кнопок та вікон, але це станеться лише після перезавантаження браузера");
			}
		}
		try{
			importt.setText(languag.get((int)(88)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				importt.setText("SKIN IMPORT (OPEN FROM SYSTEM FILE MANAGER)\n\nALSO SUPPORT JBAK2 KEYBOARD SKINS");
			}
			else {
				importt.setText("ІМПОРТ СКІНА (ВІДКРИТИ З СИСТЕМНОГО ФАЙЛОВОГО МЕНЕДЖЕРА)\n\nТАКОЖ СУМІСНИЙ ЗІ СКІНАМИ JBAK2 КЛАВІАТУРА");
			}
		}
		try{
			name.setHint(languag.get((int)(89)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				name.setHint("NAME OF THE SKIN");
			}
			else {
				name.setHint("НАЗВА СКІНА");
			}
		}
		try{
			export.setText(languag.get((int)(90)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				export.setText("SKIN EXPORT TO WEEKBROWSER/CUSTOMSKINLIBRARY");
			}
			else {
				export.setText("ЕКСПОРТ СКІНА У WEEKBROWSER/CUSTOMSKINLIBRARY");
			}
		}
		try{
			textview4.setText(languag.get((int)(92)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				textview4.setText("Background color\nInterface|General buttons|Delete buttons");
			}
			else {
				textview4.setText("Колір фону\nінтерфейсу|Звичайних кнопок|Кнопок видалення|Радіус заокруглення");
			}
		}
		try{
			textview5.setText(languag.get((int)(94)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				textview5.setText("Text color\nGeneral|Textarea|Additional|Hint|Button|Delete button");
			}
			else {
				textview5.setText("Колір тексту\nОсновний|Текстового поля|Допоміжний|Підказка|кнопки|кнопки видалення");
			}
		}
		try{
			copy.setText(languag.get((int)(9999)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				copy.setText("OPEN COLORPICKER");
			}
			else {
				copy.setText("ВІДКРИТИ COLORPICKER");
			}
		}
		try{
			temproarystd.setText(languag.get((int)(102)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				temproarystd.setText("TEMPROARY STANDARD");
			}
			else {
				temproarystd.setText("ТИМЧАСОВО СТАНДАРТНА");
			}
		}
		try{
			refresh.setText(languag.get((int)(103)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				refresh.setText("REFRESH");
			}
			else {
				refresh.setText("ОНОВИТИ");
			}
		}
		try{
			hint2.setText("════════\n".concat(languag.get((int)(104))));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				hint2.setText("════════\nAll of elements below dont do anything, this is only example of the skin you made. You may click on this text to call dialog.");
			}
			else {
				hint2.setText("════════\nВсі елементи інтерфейсу нижче нічого не роблять, вони лише є прикладом скіна, який у Вас вийшов. Можете натиснути на цей текст, щоб викликати діалог");
			}
		}
		try{
			colorbutton.setText(languag.get((int)(100)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				colorbutton.setText("AFTER CLICK HERE CLICK ON TEXTAREA FOR PASTE COLOR FROM COLORPICKER");
			}
			else {
				colorbutton.setText("ПІСЛЯ НАТИСКАННЯ СЮДИ НАТИСКАЙТЕ НА ТЕКСТОВЕ ПОЛЕ, І ТУДИ ВСТАВИТЬСЯ КОЛІР, ЯКИЙ ВИ НАКРУТИЛИ В ПАЛІТРІ");
			}
		}
	}
	
	
	public double _fromHex(final String _str) {
		        int decimalValue = Integer.parseInt(_str, 16);
		        return decimalValue;
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}