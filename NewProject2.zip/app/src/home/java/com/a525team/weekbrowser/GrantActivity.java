package com.a525team.weekbrowser;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import android.Manifest;

public class GrantActivity extends Activity {
	
	private Timer _timer = new Timer();
	
	private LinearLayout linear1;
	private Button switchlang;
	private Button done;
	private TextView name;
	private TextView hint;
	private TextView storage;
	private TextView location;
	
	private TimerTask t;
	private Intent i = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.grant);
		initialize(_savedInstanceState);
		
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			||checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
			} else {
				initializeLogic();
			}
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		switchlang = findViewById(R.id.switchlang);
		done = findViewById(R.id.done);
		name = findViewById(R.id.name);
		hint = findViewById(R.id.hint);
		storage = findViewById(R.id.storage);
		location = findViewById(R.id.location);
		
		switchlang.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (switchlang.getText().toString().equals("SWITCH TO ENGLISH")) {
					name.setText("YOU NEED TO GRANT A FEW PERMISSIONS!");
					hint.setText("Text with star sign is neccesary permissions. Tap on the text to grant permission. Green text is granted permission");
					storage.setText("STORAGE ACCESS*\nThis is very necessary because directly in your storage with other files will be saved settings of this browser.");
					location.setText("LOCATION ACCESS\nThis is need for websites for know your location. It's may be useful, for example, in web-navigators.");
					done.setText("DONE");
					switchlang.setText("ПЕРЕМИКНУТИСЯ НА УКРАЇНСЬКУ");
				}
				else {
					name.setText("ПОТРІБНО НАДАТИ КІЛЬКА ДОЗВОЛІВ!");
					hint.setText("Текстом із зірочкою позначено обов'язкові дозволи. Натискайте по тексту, щоб надати дозволи. Зеленим текстом позначені надані дозволи");
					storage.setText("ДОСТУП ДО ПАМ'ЯТІ*\nВін дуже потрібний, так як налаштування браузера зберігатимуться прямо у внутрішній пам'яті разом із файлами");
					location.setText("ДОСТУП ДО МІСЦЕЗНАХОДЖЕННЯ\nВін потрібен для того, щоб сайти знали Ваше точне місцезнаходження. Це може бути корисно, наприклад, у веб-навігаторах");
					done.setText("ГОТОВО");
					switchlang.setText("SWITCH TO ENGLISH");
				}
			}
		});
		
		done.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (!(checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_DENIED && checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_DENIED)) {
					i.setClass(getApplicationContext(), MainActivity.class);
					startActivity(i);
					if (switchlang.getText().toString().equals("ПЕРЕМИКНУТИСЯ НА УКРАЇНСЬКУ")) {
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Language.welang", "");
					}
				}
				else {
					if (switchlang.getText().toString().equals("ПЕРЕМИКНУТИСЯ НА УКРАЇНСЬКУ")) {
						SketchwareUtil.showMessage(getApplicationContext(), "You don't granted necessary permissions!");
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), "Ви не надали необхідних дозволів!");
					}
				}
			}
		});
		
		storage.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				requestPermissions(new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 1000);
			}
		});
		
		location.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				requestPermissions(new String[] {Manifest.permission.ACCESS_FINE_LOCATION}, 1000);
			}
		});
	}
	
	private void initializeLogic() {
		t = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						if (Build.VERSION.SDK_INT >= 23) {
										if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_DENIED) {
												storage.setTextColor(0xFFFFFFFF);
										}
										else {
								storage.setTextColor(0xFF00FF00);
										}
								}
								else {
							storage.setTextColor(0xFF00FF00);
								}
						if (Build.VERSION.SDK_INT >= 23) {
										if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_DENIED) {
												location.setTextColor(0xFFFFFFFF);
										}
										else {
								location.setTextColor(0xFF00FF00);
										}
								}
								else {
							location.setTextColor(0xFF00FF00);
								}
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(t, (int)(0), (int)(300));
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}