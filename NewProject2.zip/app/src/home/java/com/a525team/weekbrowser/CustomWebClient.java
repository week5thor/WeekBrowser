package com.a525team.weekbrowser;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebChromeClient.CustomViewCallback;
import android.widget.FrameLayout;

public class CustomWebClient extends WebChromeClient {
    private View mCustomView;
    private CustomViewCallback mCustomViewCallback;
    protected FrameLayout frame;
    private int mOriginalOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;
    private int mOriginalSystemUiVisibility;
    private Activity activity;

    public CustomWebClient(Activity activity) {
        this.activity = activity;
    }    

    @Override
    public Bitmap getDefaultVideoPoster() {
        // Your implementation here
        return null;
    }

    @Override
    public void onShowCustomView(View paramView, CustomViewCallback viewCallback) {
        if (this.mCustomView != null) {
            onHideCustomView();
            return;
        }

        this.mCustomView = paramView;
        this.mOriginalSystemUiVisibility = activity.getWindow().getDecorView().getSystemUiVisibility();
        ((FrameLayout) activity.getWindow().getDecorView()).addView(this.mCustomView, new FrameLayout.LayoutParams(-1, -1));
        this.mCustomViewCallback = viewCallback;

        activity.setRequestedOrientation(mOriginalOrientation);
        activity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
    }

    @Override
    public void onHideCustomView() {
        ((FrameLayout) activity.getWindow().getDecorView()).removeView(this.mCustomView);
        this.mCustomView = null;
        activity.getWindow().getDecorView().setSystemUiVisibility(this.mOriginalSystemUiVisibility);
        activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);

        if (this.mCustomViewCallback != null) {
            this.mCustomViewCallback.onCustomViewHidden();
            this.mCustomViewCallback = null;
        }
    }
}
