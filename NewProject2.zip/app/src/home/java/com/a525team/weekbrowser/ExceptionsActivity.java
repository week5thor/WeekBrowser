package com.a525team.weekbrowser;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class ExceptionsActivity extends Activity {
	
	private ArrayList<HashMap<String, Object>> except = new ArrayList<>();
	
	private LinearLayout bg;
	private ListView listview1;
	
	private AlertDialog.Builder del;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.exceptions);
		initialize(_savedInstanceState);
		
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			||checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
			} else {
				initializeLogic();
			}
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		if(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt"))==0)
		{if ( Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {setTheme(android.R.style.Theme_Holo_Light);}else {setTheme(android.R.style.Theme_Black);}}
		
		else if(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt"))==1||Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt"))==2)
		{if ( Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {setTheme(android.R.style.Theme_Holo);}else {setTheme(android.R.style.Theme_Black);}
		} else{String filePath = "/storage/emulated/0/WeekBrowser/CustomTheme/style.txt";
				        String themeValue = FileUtil.readFile(filePath);
				
				        if (themeValue.equals("1") || (themeValue.equals("3") || themeValue.equals("5")) && Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB) {
						            setTheme(android.R.style.Theme_Black);
						        } else if (themeValue.equals("2") || (themeValue.equals("4") || themeValue.equals("6")) && Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB) {
						            setTheme(android.R.style.Theme_Light);
						        } else if (themeValue.equals("3") || (themeValue.equals("5")) && Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
						            setTheme(android.R.style.Theme_Holo);
						        } else if (themeValue.equals("4") || (themeValue.equals("6")) && Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
						            setTheme(android.R.style.Theme_Holo_Light);
						        } else if (themeValue.equals("5")) {
						            setTheme(android.R.style.Theme_Material);
						        } else if (themeValue.equals("6")) {
						            setTheme(android.R.style.Theme_Material_Light);
						        }}
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.exceptions);
		bg = findViewById(R.id.bg);
		listview1 = findViewById(R.id.listview1);
		del = new AlertDialog.Builder(this);
		
		listview1.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				del.setTitle("ПІДТВЕРДЖЕННЯ");
				del.setMessage("Ви дійсно хочете видалити сайт зі списку винятків?");
				del.setPositiveButton("ТАК", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						if (except.get((int)_position).get("url").toString().equals("file://")) {
							SketchwareUtil.showMessage(getApplicationContext(), "Неможливо видалити");
						}
						else {
							except.remove((int)(_position));
							FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SitePermission.json", new Gson().toJson(except));
							((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
						}
					}
				});
				del.setNegativeButton("НІ", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				del.create().show();
				return true;
			}
		});
	}
	
	private void initializeLogic() {
		except = new Gson().fromJson(FileUtil.readFile("/storage/emulated/0/WeekBrowser/SitePermission.json"), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		listview1.setAdapter(new Listview1Adapter(except));
		if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
			bg.setBackgroundColor(0xFFFFFFFF);
		}
		else {
			if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
				bg.setBackgroundColor(0xFF111111);
			}
			else {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
					bg.setBackgroundColor(0xFF000000);
				}
				else {
					bg.setBackgroundColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/bg.txt"),16));	
				}
			}
		}
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.except, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final TextView url = _view.findViewById(R.id.url);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final TextView js = _view.findViewById(R.id.js);
			final TextView blockad = _view.findViewById(R.id.blockad);
			final TextView sr = _view.findViewById(R.id.sr);
			final TextView th = _view.findViewById(R.id.th);
			final TextView iframe = _view.findViewById(R.id.iframe);
			
			final int color1 = (int) Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg.txt"), 16);
			final int color2 = (int) Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg2.txt"), 16);
			final int roundness = Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/roundness.txt"));
			final int rcolor1 = (int) Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg.txt"), 16);
			final int rcolor2 = (int) Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg2.txt"), 16);
			url.setText(except.get((int)_position).get("url").toString());
			if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
				url.setTextColor(0xFF000000);
			}
			else {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
					url.setTextColor(0xFFFFFFFF);
				}
				else {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
						url.setTextColor(0xFF00FF00);
					}
					else {
						url.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					}
				}
			}
			try{
				switch(except.get((int)_position).get("ad").toString()) {
					case "1": {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
							blockad.setBackgroundColor(0xFF33B5E5);
							blockad.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
								blockad.setBackgroundColor(0xFF33B5E5);
								blockad.setTextColor(0xFF000000);
							}
							else {
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
									blockad.setBackgroundColor(0xFF00FF00);
									blockad.setTextColor(0xFF000000);
								}
								else {
												blockad.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
												blockad.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
											    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
										}});
								}
							}
						}
						break;
					}
					case "2": {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
							blockad.setBackgroundColor(Color.TRANSPARENT);
							blockad.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
								blockad.setBackgroundColor(Color.TRANSPARENT);
								blockad.setTextColor(0xFFFFFFFF);
							}
							else {
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
									blockad.setBackgroundColor(Color.TRANSPARENT);
									blockad.setTextColor(0xFF00FF00);
								}
								else {
												blockad.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
									blockad.setBackgroundColor(Color.TRANSPARENT);
								}
							}
						}
						break;
					}
					case "0": {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
							blockad.setBackgroundColor(0xFFB71C1C);
							blockad.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
								blockad.setBackgroundColor(0xFFB71C1C);
								blockad.setTextColor(0xFF000000);
							}
							else {
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
									blockad.setBackgroundColor(0xFFF00000);
									blockad.setTextColor(0xFF000000);
								}
								else {
												blockad.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
												blockad.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
											    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
										}});
								}
							}
						}
						break;
					}
				}
			}catch(Exception e){
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
					blockad.setBackgroundColor(Color.TRANSPARENT);
					blockad.setTextColor(0xFF000000);
				}
				else {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
						blockad.setBackgroundColor(Color.TRANSPARENT);
						blockad.setTextColor(0xFFFFFFFF);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
							blockad.setBackgroundColor(Color.TRANSPARENT);
							blockad.setTextColor(0xFF00FF00);
						}
						else {
							
										blockad.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
							blockad.setBackgroundColor(Color.TRANSPARENT);
						}
					}
				}
			}
			try{
				switch(except.get((int)_position).get("if").toString()) {
					case "1": {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
							iframe.setBackgroundColor(0xFF33B5E5);
							iframe.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
								iframe.setBackgroundColor(0xFF33B5E5);
								iframe.setTextColor(0xFF000000);
							}
							else {
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
									iframe.setBackgroundColor(0xFF00FF00);
									iframe.setTextColor(0xFF000000);
								}
								else {
												iframe.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
												iframe.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
											    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
										}});
								}
							}
						}
						break;
					}
					case "2": {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
							iframe.setBackgroundColor(Color.TRANSPARENT);
							iframe.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
								iframe.setBackgroundColor(Color.TRANSPARENT);
								iframe.setTextColor(0xFFFFFFFF);
							}
							else {
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
									iframe.setBackgroundColor(Color.TRANSPARENT);
									iframe.setTextColor(0xFF00FF00);
								}
								else {
												iframe.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
									iframe.setBackgroundColor(Color.TRANSPARENT);
								}
							}
						}
						break;
					}
					case "0": {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
							iframe.setBackgroundColor(0xFFB71C1C);
							iframe.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
								iframe.setBackgroundColor(0xFFB71C1C);
								iframe.setTextColor(0xFF000000);
							}
							else {
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
									iframe.setBackgroundColor(0xFFF00000);
									iframe.setTextColor(0xFF000000);
								}
								else {
												iframe.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
												iframe.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
											    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
										}});
								}
							}
						}
						break;
					}
				}
			}catch(Exception e){
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
					iframe.setBackgroundColor(Color.TRANSPARENT);
					iframe.setTextColor(0xFF000000);
				}
				else {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
						iframe.setBackgroundColor(Color.TRANSPARENT);
						iframe.setTextColor(0xFFFFFFFF);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
							iframe.setBackgroundColor(Color.TRANSPARENT);
							iframe.setTextColor(0xFF00FF00);
						}
						else {
							
										iframe.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
							iframe.setBackgroundColor(Color.TRANSPARENT);
						}
					}
				}
			}
			try{
				switch(except.get((int)_position).get("js").toString()) {
					case "1": {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
							js.setBackgroundColor(0xFF33B5E5);
							js.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
								js.setBackgroundColor(0xFF33B5E5);
								js.setTextColor(0xFF000000);
							}
							else {
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
									js.setBackgroundColor(0xFF00FF00);
									js.setTextColor(0xFF000000);
								}
								else {
												js.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
												js.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
											    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
										}});
								}
							}
						}
						break;
					}
					case "2": {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
							js.setBackgroundColor(Color.TRANSPARENT);
							js.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
								js.setBackgroundColor(Color.TRANSPARENT);
								js.setTextColor(0xFFFFFFFF);
							}
							else {
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
									js.setBackgroundColor(Color.TRANSPARENT);
									js.setTextColor(0xFF00FF00);
								}
								else {
												js.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
									js.setBackgroundColor(Color.TRANSPARENT);
								}
							}
						}
						break;
					}
					case "0": {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
							js.setBackgroundColor(0xFFB71C1C);
							js.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
								js.setBackgroundColor(0xFFB71C1C);
								js.setTextColor(0xFF000000);
							}
							else {
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
									js.setBackgroundColor(0xFFF00000);
									js.setTextColor(0xFF000000);
								}
								else {
												js.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
												js.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
											    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
										}});
								}
							}
						}
						break;
					}
				}
			}catch(Exception e){
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
					js.setBackgroundColor(Color.TRANSPARENT);
					js.setTextColor(0xFF000000);
				}
				else {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
						js.setBackgroundColor(Color.TRANSPARENT);
						js.setTextColor(0xFFFFFFFF);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
							js.setBackgroundColor(Color.TRANSPARENT);
							js.setTextColor(0xFF00FF00);
						}
						else {
							
										js.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
							js.setBackgroundColor(Color.TRANSPARENT);
						}
					}
				}
			}
			try{
				switch(except.get((int)_position).get("th").toString()) {
					case "1": {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
							th.setBackgroundColor(0xFF33B5E5);
							th.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
								th.setBackgroundColor(0xFF33B5E5);
								th.setTextColor(0xFF000000);
							}
							else {
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
									th.setBackgroundColor(0xFF00FF00);
									th.setTextColor(0xFF000000);
								}
								else {
												th.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
												th.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
											    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
										}});
								}
							}
						}
						break;
					}
					case "2": {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
							th.setBackgroundColor(Color.TRANSPARENT);
							th.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
								th.setBackgroundColor(Color.TRANSPARENT);
								th.setTextColor(0xFFFFFFFF);
							}
							else {
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
									th.setBackgroundColor(Color.TRANSPARENT);
									th.setTextColor(0xFF00FF00);
								}
								else {
												th.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
									th.setBackgroundColor(Color.TRANSPARENT);
								}
							}
						}
						break;
					}
					case "0": {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
							th.setBackgroundColor(0xFFB71C1C);
							th.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
								th.setBackgroundColor(0xFFB71C1C);
								th.setTextColor(0xFF000000);
							}
							else {
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
									th.setTextColor(0xFF000000);
									th.setBackgroundColor(0xFFF00000);
								}
								else {
												th.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
												th.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
											    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
										}});
								}
							}
						}
						break;
					}
				}
			}catch(Exception e){
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
					th.setBackgroundColor(Color.TRANSPARENT);
					th.setTextColor(0xFF000000);
				}
				else {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
						th.setBackgroundColor(Color.TRANSPARENT);
						th.setTextColor(0xFFFFFFFF);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
							th.setBackgroundColor(Color.TRANSPARENT);
							th.setTextColor(0xFF00FF00);
						}
						else {
							
										th.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
							th.setBackgroundColor(Color.TRANSPARENT);
						}
					}
				}
			}
			try{
				switch(except.get((int)_position).get("sr").toString()) {
					case "1": {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
							sr.setBackgroundColor(0xFF33B5E5);
							sr.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
								sr.setBackgroundColor(0xFF33B5E5);
								sr.setTextColor(0xFF000000);
							}
							else {
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
									sr.setBackgroundColor(0xFF00FF00);
									sr.setTextColor(0xFF000000);
								}
								else {
												sr.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
												sr.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
											    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
										}});
								}
							}
						}
						break;
					}
					case "2": {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
							sr.setBackgroundColor(Color.TRANSPARENT);
							sr.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
								sr.setBackgroundColor(Color.TRANSPARENT);
								sr.setTextColor(0xFFFFFFFF);
							}
							else {
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
									sr.setBackgroundColor(Color.TRANSPARENT);
									sr.setTextColor(0xFF00FF00);
								}
								else {
												sr.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
									sr.setBackgroundColor(Color.TRANSPARENT);
								}
							}
						}
						break;
					}
					case "0": {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
							sr.setBackgroundColor(0xFFB71C1C);
							sr.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
								sr.setBackgroundColor(0xFFB71C1C);
								sr.setTextColor(0xFF000000);
							}
							else {
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
									sr.setTextColor(0xFF000000);
									sr.setBackgroundColor(0xFFF00000);
								}
								else {
												sr.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
												sr.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
											    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
										}});
								}
							}
						}
						break;
					}
				}
			}catch(Exception e){
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
					sr.setBackgroundColor(Color.TRANSPARENT);
					sr.setTextColor(0xFF000000);
				}
				else {
					if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
						sr.setBackgroundColor(Color.TRANSPARENT);
						sr.setTextColor(0xFFFFFFFF);
					}
					else {
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
							sr.setBackgroundColor(Color.TRANSPARENT);
							sr.setTextColor(0xFF00FF00);
						}
						else {
							
										sr.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
							sr.setBackgroundColor(Color.TRANSPARENT);
						}
					}
				}
			}
			js.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					try{
						if (except.get((int)_position).get("js").toString().equals("2")) {
							except.get((int)_position).put("js", "0");
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
								js.setBackgroundColor(0xFFB71C1C);
								js.setTextColor(0xFF000000);
							}
							else {
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
									js.setBackgroundColor(0xFFB71C1C);
									js.setTextColor(0xFF000000);
								}
								else {
									if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
										js.setBackgroundColor(0xFFF00000);
										js.setTextColor(0xFF000000);
									}
									else {
													js.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
													js.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
												    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
											}});
									}
								}
							}
						}
						else {
							if (except.get((int)_position).get("js").toString().equals("0")) {
								except.get((int)_position).put("js", "1");
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
									js.setBackgroundColor(0xFF33B5E5);
									js.setTextColor(0xFF000000);
								}
								else {
									if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
										js.setBackgroundColor(0xFF33B5E5);
										js.setTextColor(0xFF000000);
									}
									else {
										if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
											js.setBackgroundColor(0xFF00FF00);
											js.setTextColor(0xFF000000);
										}
										else {
														js.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
														js.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
													    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
												}});
										}
									}
								}
							}
							else {
								except.get((int)_position).put("js", "2");
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
									js.setBackgroundColor(Color.TRANSPARENT);
									js.setTextColor(0xFF000000);
								}
								else {
									if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
										js.setBackgroundColor(Color.TRANSPARENT);
										js.setTextColor(0xFFFFFFFF);
									}
									else {
										if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
											js.setBackgroundColor(Color.TRANSPARENT);
											js.setTextColor(0xFF00FF00);
										}
										else {
														js.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
											js.setBackgroundColor(Color.TRANSPARENT);
										}
									}
								}
							}
						}
					}catch(Exception e){
						except.get((int)_position).put("js", "0");
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
							js.setBackgroundColor(0xFFB71C1C);
							js.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
								js.setBackgroundColor(0xFFB71C1C);
								js.setTextColor(0xFF000000);
							}
							else {
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
									js.setBackgroundColor(0xFFF00000);
									js.setTextColor(0xFF000000);
								}
								else {
												js.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
												js.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
											    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
										}});
								}
							}
						}
					}
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SitePermission.json", new Gson().toJson(except));
				}
			});
			blockad.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					try{
						if (except.get((int)_position).get("ad").toString().equals("2")) {
							except.get((int)_position).put("ad", "0");
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
								blockad.setBackgroundColor(0xFFB71C1C);
								blockad.setTextColor(0xFF000000);
							}
							else {
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
									blockad.setBackgroundColor(0xFFB71C1C);
									blockad.setTextColor(0xFF000000);
								}
								else {
									if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
										blockad.setBackgroundColor(0xFFF00000);
										blockad.setTextColor(0xFF000000);
									}
									else {
													blockad.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
													blockad.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
												    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
											}});
									}
								}
							}
						}
						else {
							if (except.get((int)_position).get("ad").toString().equals("0")) {
								except.get((int)_position).put("ad", "1");
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
									blockad.setBackgroundColor(0xFF33B5E5);
									blockad.setTextColor(0xFF000000);
								}
								else {
									if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
										blockad.setBackgroundColor(0xFF33B5E5);
										blockad.setTextColor(0xFF000000);
									}
									else {
										if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
											blockad.setBackgroundColor(0xFF00FF00);
											blockad.setTextColor(0xFF000000);
										}
										else {
														blockad.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
														blockad.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
													    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
												}});
										}
									}
								}
							}
							else {
								except.get((int)_position).put("ad", "2");
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
									blockad.setBackgroundColor(Color.TRANSPARENT);
									blockad.setTextColor(0xFF000000);
								}
								else {
									if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
										blockad.setBackgroundColor(Color.TRANSPARENT);
										blockad.setTextColor(0xFFFFFFFF);
									}
									else {
										if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
											blockad.setBackgroundColor(Color.TRANSPARENT);
											blockad.setTextColor(0xFF00FF00);
										}
										else {
														blockad.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
											blockad.setBackgroundColor(Color.TRANSPARENT);
										}
									}
								}
							}
						}
					}catch(Exception e){
						except.get((int)_position).put("ad", "0");
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
							blockad.setBackgroundColor(0xFFB71C1C);
							blockad.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
								blockad.setBackgroundColor(0xFFB71C1C);
								blockad.setTextColor(0xFF000000);
							}
							else {
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
									blockad.setBackgroundColor(0xFFF00000);
									blockad.setTextColor(0xFF000000);
								}
								else {
												blockad.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
												blockad.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
											    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
										}});
								}
							}
						}
					}
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SitePermission.json", new Gson().toJson(except));
				}
			});
			iframe.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					try{
						if (except.get((int)_position).get("if").toString().equals("2")) {
							except.get((int)_position).put("if", "0");
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
								iframe.setBackgroundColor(0xFFB71C1C);
								iframe.setTextColor(0xFF000000);
							}
							else {
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
									iframe.setBackgroundColor(0xFFB71C1C);
									iframe.setTextColor(0xFF000000);
								}
								else {
									if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
										iframe.setBackgroundColor(0xFFF00000);
										iframe.setTextColor(0xFF000000);
									}
									else {
													iframe.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
													iframe.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
												    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
											}});
									}
								}
							}
						}
						else {
							if (except.get((int)_position).get("if").toString().equals("0")) {
								except.get((int)_position).put("if", "1");
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
									iframe.setBackgroundColor(0xFF33B5E5);
									iframe.setTextColor(0xFF000000);
								}
								else {
									if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
										iframe.setBackgroundColor(0xFF33B5E5);
										iframe.setTextColor(0xFF000000);
									}
									else {
										if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
											iframe.setBackgroundColor(0xFF00FF00);
											iframe.setTextColor(0xFF000000);
										}
										else {
														iframe.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
														iframe.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
													    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
												}});
										}
									}
								}
							}
							else {
								except.get((int)_position).put("if", "2");
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
									iframe.setBackgroundColor(Color.TRANSPARENT);
									iframe.setTextColor(0xFF000000);
								}
								else {
									if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
										iframe.setBackgroundColor(Color.TRANSPARENT);
										iframe.setTextColor(0xFFFFFFFF);
									}
									else {
										if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
											iframe.setBackgroundColor(Color.TRANSPARENT);
											iframe.setTextColor(0xFF00FF00);
										}
										else {
														iframe.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
											iframe.setBackgroundColor(Color.TRANSPARENT);
										}
									}
								}
							}
						}
					}catch(Exception e){
						except.get((int)_position).put("if", "0");
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
							iframe.setBackgroundColor(0xFFB71C1C);
							iframe.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
								iframe.setBackgroundColor(0xFFB71C1C);
								iframe.setTextColor(0xFF000000);
							}
							else {
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
									iframe.setBackgroundColor(0xFFF00000);
									iframe.setTextColor(0xFF000000);
								}
								else {
												iframe.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
												iframe.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
											    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
										}});
								}
							}
						}
					}
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SitePermission.json", new Gson().toJson(except));
				}
			});
			th.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					try{
						if (except.get((int)_position).get("th").toString().equals("2")) {
							except.get((int)_position).put("th", "0");
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
								th.setBackgroundColor(0xFFB71C1C);
								th.setTextColor(0xFF000000);
							}
							else {
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
									th.setBackgroundColor(0xFFB71C1C);
									th.setTextColor(0xFF000000);
								}
								else {
									if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
										th.setBackgroundColor(0xFFF00000);
										th.setTextColor(0xFF000000);
									}
									else {
													th.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
													th.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
												    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
											}});
									}
								}
							}
						}
						else {
							if (except.get((int)_position).get("th").toString().equals("0")) {
								except.get((int)_position).put("th", "1");
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
									th.setBackgroundColor(0xFF33B5E5);
									th.setTextColor(0xFF000000);
								}
								else {
									if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
										th.setBackgroundColor(0xFF33B5E5);
										th.setTextColor(0xFF000000);
									}
									else {
										if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
											th.setBackgroundColor(0xFF00FF00);
											th.setTextColor(0xFF000000);
										}
										else {
														th.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
														th.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
													    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
												}});
										}
									}
								}
							}
							else {
								except.get((int)_position).put("th", "2");
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
									th.setBackgroundColor(Color.TRANSPARENT);
									th.setTextColor(0xFF000000);
								}
								else {
									if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
										th.setBackgroundColor(Color.TRANSPARENT);
										th.setTextColor(0xFFFFFFFF);
									}
									else {
										if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
											th.setBackgroundColor(Color.TRANSPARENT);
											th.setTextColor(0xFF00FF00);
										}
										else {
														th.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
											th.setBackgroundColor(Color.TRANSPARENT);
										}
									}
								}
							}
						}
					}catch(Exception e){
						except.get((int)_position).put("th", "0");
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
							th.setBackgroundColor(0xFFB71C1C);
							th.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
								th.setBackgroundColor(0xFFB71C1C);
								th.setTextColor(0xFF000000);
							}
							else {
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
									th.setBackgroundColor(0xFFF00000);
									th.setTextColor(0xFF000000);
								}
								else {
												th.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
												th.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
											    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
										}});
								}
							}
						}
					}
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SitePermission.json", new Gson().toJson(except));
				}
			});
			sr.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					try{
						if (except.get((int)_position).get("sr").toString().equals("2")) {
							except.get((int)_position).put("sr", "0");
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
								sr.setBackgroundColor(0xFFB71C1C);
								sr.setTextColor(0xFF000000);
							}
							else {
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
									sr.setBackgroundColor(0xFFB71C1C);
									sr.setTextColor(0xFF000000);
								}
								else {
									if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
										sr.setBackgroundColor(0xFFF00000);
										sr.setTextColor(0xFF000000);
									}
									else {
													sr.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
													sr.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
												    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
											}});
									}
								}
							}
						}
						else {
							if (except.get((int)_position).get("sr").toString().equals("0")) {
								except.get((int)_position).put("sr", "1");
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
									sr.setBackgroundColor(0xFF33B5E5);
									sr.setTextColor(0xFF000000);
								}
								else {
									if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
										sr.setBackgroundColor(0xFF33B5E5);
										sr.setTextColor(0xFF000000);
									}
									else {
										if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
											sr.setBackgroundColor(0xFF00FF00);
											sr.setTextColor(0xFF000000);
										}
										else {
														sr.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
														sr.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
													    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
												}});
										}
									}
								}
							}
							else {
								except.get((int)_position).put("sr", "2");
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
									sr.setBackgroundColor(Color.TRANSPARENT);
									sr.setTextColor(0xFF000000);
								}
								else {
									if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
										sr.setBackgroundColor(Color.TRANSPARENT);
										sr.setTextColor(0xFFFFFFFF);
									}
									else {
										if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
											sr.setBackgroundColor(Color.TRANSPARENT);
											sr.setTextColor(0xFF00FF00);
										}
										else {
														sr.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
											sr.setBackgroundColor(Color.TRANSPARENT);
										}
									}
								}
							}
						}
					}catch(Exception e){
						except.get((int)_position).put("sr", "0");
						if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
							sr.setBackgroundColor(0xFFB71C1C);
							sr.setTextColor(0xFF000000);
						}
						else {
							if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
								sr.setBackgroundColor(0xFFB71C1C);
								sr.setTextColor(0xFF000000);
							}
							else {
								if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
									sr.setBackgroundColor(0xFFF00000);
									sr.setTextColor(0xFF000000);
								}
								else {
												sr.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
												sr.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
											    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
										}});
								}
							}
						}
					}
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SitePermission.json", new Gson().toJson(except));
				}
			});
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}