package com.a525team.weekbrowser;

import android.content.Context;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.DisplayCutout;
import android.view.WindowInsets;
import android.view.WindowManager;

public class NotchUtils {

    public static int getNotchHeightDp(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
            if (windowManager != null) {
                WindowInsets windowInsets = windowManager.getCurrentWindowMetrics().getWindowInsets();
                DisplayCutout displayCutout = windowInsets.getDisplayCutout();
                if (displayCutout != null) {
                    int notchHeightPixels = displayCutout.getSafeInsetTop();
                    return pxToDp(context, notchHeightPixels);
                }
            }
        }
        return 0; // Немає вирізу або Android версія нижче P
    }

    private static int pxToDp(Context context, int px) {
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        return Math.round(px / (displayMetrics.densityDpi / DisplayMetrics.DENSITY_DEFAULT));
    }
}
