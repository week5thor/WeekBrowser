package com.a525team.weekbrowser;

import android.Manifest;
import android.animation.*;
import android.animation.ObjectAnimator;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.webkit.*;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.*;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.regex.*;
import org.json.*;

public class SettingsActivity extends Activity {
	
	public final int REQ_CD_FP = 101;
	
	private String alarm = "";
	private String douwant = "";
	private String yes = "";
	private String no = "";
	private String cacheisclear = "";
	
	private ArrayList<String> languag = new ArrayList<>();
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private WebView webview1;
	private TextView name;
	private TextView textview9;
	private HorizontalScrollView hscroll2;
	private LinearLayout linear7;
	private HorizontalScrollView hscroll1;
	private TextView textview3;
	private CheckBox navpan;
	private CheckBox pnup;
	private CheckBox srup;
	private LinearLayout linear5;
	private CheckBox zoombtns;
	private CheckBox screen;
	private LinearLayout linear21;
	private CheckBox mono;
	private Button button4;
	private Button useragent;
	private Button replacer;
	private Button except;
	private LinearLayout linear9;
	private SeekBar seekbar1;
	private LinearLayout linear6;
	private RadioGroup radiogroup2;
	private CheckBox onnointernet;
	private TextView textview6;
	private RadioGroup radiogroup3;
	private Button opentheme;
	private TextView loadstyle;
	private RadioGroup radiogroup4;
	private CheckBox infogravity;
	private TextView textview8;
	private CheckBox auto;
	private LinearLayout linear4;
	private LinearLayout linear16;
	private LinearLayout linear13;
	private Button history;
	private LinearLayout linear15;
	private LinearLayout linear17;
	private LinearLayout linear18;
	private TextView bladtxt;
	private CheckBox setaccess;
	private CheckBox videoad;
	private TextView textview12;
	private EditText keywords;
	private TextView about;
	private TextView developerinfo;
	private LinearLayout linear20;
	private LinearLayout linear19;
	private Button privat;
	private RadioGroup radiogroup6;
	private RadioButton uk;
	private RadioButton en;
	private RadioButton custom;
	private Button loadcus;
	private TextView td1;
	private Button srhalm;
	private RadioGroup radiogroup5;
	private RadioButton google;
	private RadioButton bing;
	private RadioButton yahoo;
	private RadioButton duck;
	private CheckBox hide;
	private Button panhint;
	private CheckBox preview;
	private Button hidehint;
	private TextView hintt;
	private Button e1;
	private Button e2;
	private TextView textview2;
	private Button cachehint;
	private RadioButton std;
	private RadioButton dts;
	private RadioButton ionl;
	private RadioButton conl;
	private RadioButton light;
	private RadioButton dark;
	private RadioButton highcontrast;
	private RadioButton customtheme;
	private RadioButton loadingslash;
	private RadioButton percent;
	private RadioButton loadingpercent;
	private RadioButton slash;
	private RadioButton slpercentash;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private AutoCompleteTextView startpage;
	private Button bookmarks;
	private Button googl;
	private Button bng;
	private Button yaho;
	private Button duckgo;
	private TextView textview7;
	private TextView textview11;
	private Button srccln;
	private CheckBox srha;
	private Button clrcache;
	private CheckBox cachea;
	private Button cookieclr;
	private CheckBox cookiea;
	private Button formclr;
	private CheckBox forma;
	private Button tgk;
	private Button tgkc;
	private Button tgc;
	private Button tgcc;
	
	private Intent intent = new Intent();
	private AlertDialog.Builder dlg;
	private Intent fp = new Intent(Intent.ACTION_GET_CONTENT);
	private ObjectAnimator anim = new ObjectAnimator();
	private ObjectAnimator prevcheckbox = new ObjectAnimator();
	private AlertDialog.Builder hints;
	private ObjectAnimator pnupanim = new ObjectAnimator();
	private AlertDialog.Builder scr;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.settings);
		initialize(_savedInstanceState);
		
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			||checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
			} else {
				initializeLogic();
			}
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		if(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt"))==0)
		{if ( Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {setTheme(android.R.style.Theme_Holo_Light);}else {setTheme(android.R.style.Theme_Black);}}
		
		else if(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt"))==1||Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt"))==2)
		{if ( Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {setTheme(android.R.style.Theme_Holo);}else {setTheme(android.R.style.Theme_Black);}
		} else{String filePath = "/storage/emulated/0/WeekBrowser/CustomTheme/style.txt";
				        String themeValue = FileUtil.readFile(filePath);
				
				        if (themeValue.equals("1") || (themeValue.equals("3") || themeValue.equals("5")) && Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB) {
						            setTheme(android.R.style.Theme_Black);
						        } else if (themeValue.equals("2") || (themeValue.equals("4") || themeValue.equals("6")) && Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB) {
						            setTheme(android.R.style.Theme_Light);
						        } else if (themeValue.equals("3") || (themeValue.equals("5")) && Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
						            setTheme(android.R.style.Theme_Holo);
						        } else if (themeValue.equals("4") || (themeValue.equals("6")) && Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
						            setTheme(android.R.style.Theme_Holo_Light);
						        } else if (themeValue.equals("5")) {
						            setTheme(android.R.style.Theme_Material);
						        } else if (themeValue.equals("6")) {
						            setTheme(android.R.style.Theme_Material_Light);
						        }}
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.settings);
		vscroll1 = findViewById(R.id.vscroll1);
		linear1 = findViewById(R.id.linear1);
		webview1 = findViewById(R.id.webview1);
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.getSettings().setSupportZoom(true);
		name = findViewById(R.id.name);
		textview9 = findViewById(R.id.textview9);
		hscroll2 = findViewById(R.id.hscroll2);
		linear7 = findViewById(R.id.linear7);
		hscroll1 = findViewById(R.id.hscroll1);
		textview3 = findViewById(R.id.textview3);
		navpan = findViewById(R.id.navpan);
		pnup = findViewById(R.id.pnup);
		srup = findViewById(R.id.srup);
		linear5 = findViewById(R.id.linear5);
		zoombtns = findViewById(R.id.zoombtns);
		screen = findViewById(R.id.screen);
		linear21 = findViewById(R.id.linear21);
		mono = findViewById(R.id.mono);
		button4 = findViewById(R.id.button4);
		useragent = findViewById(R.id.useragent);
		replacer = findViewById(R.id.replacer);
		except = findViewById(R.id.except);
		linear9 = findViewById(R.id.linear9);
		seekbar1 = findViewById(R.id.seekbar1);
		linear6 = findViewById(R.id.linear6);
		radiogroup2 = findViewById(R.id.radiogroup2);
		onnointernet = findViewById(R.id.onnointernet);
		textview6 = findViewById(R.id.textview6);
		radiogroup3 = findViewById(R.id.radiogroup3);
		opentheme = findViewById(R.id.opentheme);
		loadstyle = findViewById(R.id.loadstyle);
		radiogroup4 = findViewById(R.id.radiogroup4);
		infogravity = findViewById(R.id.infogravity);
		textview8 = findViewById(R.id.textview8);
		auto = findViewById(R.id.auto);
		linear4 = findViewById(R.id.linear4);
		linear16 = findViewById(R.id.linear16);
		linear13 = findViewById(R.id.linear13);
		history = findViewById(R.id.history);
		linear15 = findViewById(R.id.linear15);
		linear17 = findViewById(R.id.linear17);
		linear18 = findViewById(R.id.linear18);
		bladtxt = findViewById(R.id.bladtxt);
		setaccess = findViewById(R.id.setaccess);
		videoad = findViewById(R.id.videoad);
		textview12 = findViewById(R.id.textview12);
		keywords = findViewById(R.id.keywords);
		about = findViewById(R.id.about);
		developerinfo = findViewById(R.id.developerinfo);
		linear20 = findViewById(R.id.linear20);
		linear19 = findViewById(R.id.linear19);
		privat = findViewById(R.id.privat);
		radiogroup6 = findViewById(R.id.radiogroup6);
		uk = findViewById(R.id.uk);
		en = findViewById(R.id.en);
		custom = findViewById(R.id.custom);
		loadcus = findViewById(R.id.loadcus);
		td1 = findViewById(R.id.td1);
		srhalm = findViewById(R.id.srhalm);
		radiogroup5 = findViewById(R.id.radiogroup5);
		google = findViewById(R.id.google);
		bing = findViewById(R.id.bing);
		yahoo = findViewById(R.id.yahoo);
		duck = findViewById(R.id.duck);
		hide = findViewById(R.id.hide);
		panhint = findViewById(R.id.panhint);
		preview = findViewById(R.id.preview);
		hidehint = findViewById(R.id.hidehint);
		hintt = findViewById(R.id.hintt);
		e1 = findViewById(R.id.e1);
		e2 = findViewById(R.id.e2);
		textview2 = findViewById(R.id.textview2);
		cachehint = findViewById(R.id.cachehint);
		std = findViewById(R.id.std);
		dts = findViewById(R.id.dts);
		ionl = findViewById(R.id.ionl);
		conl = findViewById(R.id.conl);
		light = findViewById(R.id.light);
		dark = findViewById(R.id.dark);
		highcontrast = findViewById(R.id.highcontrast);
		customtheme = findViewById(R.id.customtheme);
		loadingslash = findViewById(R.id.loadingslash);
		percent = findViewById(R.id.percent);
		loadingpercent = findViewById(R.id.loadingpercent);
		slash = findViewById(R.id.slash);
		slpercentash = findViewById(R.id.slpercentash);
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		startpage = findViewById(R.id.startpage);
		bookmarks = findViewById(R.id.bookmarks);
		googl = findViewById(R.id.googl);
		bng = findViewById(R.id.bng);
		yaho = findViewById(R.id.yaho);
		duckgo = findViewById(R.id.duckgo);
		textview7 = findViewById(R.id.textview7);
		textview11 = findViewById(R.id.textview11);
		srccln = findViewById(R.id.srccln);
		srha = findViewById(R.id.srha);
		clrcache = findViewById(R.id.clrcache);
		cachea = findViewById(R.id.cachea);
		cookieclr = findViewById(R.id.cookieclr);
		cookiea = findViewById(R.id.cookiea);
		formclr = findViewById(R.id.formclr);
		forma = findViewById(R.id.forma);
		tgk = findViewById(R.id.tgk);
		tgkc = findViewById(R.id.tgkc);
		tgc = findViewById(R.id.tgc);
		tgcc = findViewById(R.id.tgcc);
		dlg = new AlertDialog.Builder(this);
		fp.setType("*/*");
		fp.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		hints = new AlertDialog.Builder(this);
		scr = new AlertDialog.Builder(this);
		
		//webviewOnProgressChanged
		webview1.setWebChromeClient(new WebChromeClient() {
				@Override public void onProgressChanged(WebView view, int _newProgress) {
					
				}
		});
		
		//OnDownloadStarted
		webview1.setDownloadListener(new DownloadListener() {
			public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
				DownloadManager.Request webview1a = new DownloadManager.Request(Uri.parse(url));
				String webview1b = CookieManager.getInstance().getCookie(url);
				webview1a.addRequestHeader("cookie", webview1b);
				webview1a.addRequestHeader("User-Agent", userAgent);
				webview1a.setDescription("Downloading file...");
				webview1a.setTitle(URLUtil.guessFileName(url, contentDisposition, mimetype));
				webview1a.allowScanningByMediaScanner(); webview1a.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED); webview1a.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimetype));
				
				DownloadManager webview1c = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
				webview1c.enqueue(webview1a);
				showMessage("Downloading File....");
				BroadcastReceiver onComplete = new BroadcastReceiver() {
					public void onReceive(Context ctxt, Intent intent) {
						showMessage("Download Complete!");
						unregisterReceiver(this);
						
					}};
				registerReceiver(onComplete, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
			}
		});
		
		webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		navpan.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/NavPan.txt")) == 0) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/NavPan.txt", "1");
					navpan.setChecked(true);
					pnup.setVisibility(View.VISIBLE);
					pnupanim.setTarget(pnup);
					pnupanim.setPropertyName("scaleX");
					pnupanim.setFloatValues((float)(0), (float)(1));
					pnupanim.setDuration((int)(500));
					pnupanim.start();
				}
				else {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/NavPan.txt", "0");
					navpan.setChecked(false);
					pnup.setVisibility(View.GONE);
				}
			}
		});
		
		pnup.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Navpanelpos.txt")) == 0) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Navpanelpos.txt", "1");
					pnup.setChecked(true);
				}
				else {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Navpanelpos.txt", "0");
					pnup.setChecked(false);
				}
			}
		});
		
		srup.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Searchpanelpos.txt")) == 0) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Searchpanelpos.txt", "1");
				}
				else {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Searchpanelpos.txt", "0");
				}
			}
		});
		
		zoombtns.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/ZoomButton.txt")) == 0) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/ZoomButton.txt", "1");
					auto.setChecked(true);
				}
				else {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/ZoomButton.txt", "0");
					auto.setChecked(false);
				}
			}
		});
		
		screen.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/NoScreen.txt")) == 0) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/NoScreen.txt", "1");
					screen.setChecked(true);
					linear21.setVisibility(View.GONE);
				}
				else {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/NoScreen.txt", "0");
					screen.setChecked(false);
					linear21.setVisibility(View.VISIBLE);
					prevcheckbox.setTarget(linear21);
					prevcheckbox.setPropertyName("scaleX");
					prevcheckbox.setFloatValues((float)(0), (float)(1));
					prevcheckbox.setDuration((int)(500));
					prevcheckbox.start();
				}
			}
		});
		
		mono.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/monofortextarea.txt")) == 0) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/monofortextarea.txt", "1");
					startpage.setTypeface(Typeface.MONOSPACE);
				}
				else {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/monofortextarea.txt", "0");
					startpage.setTypeface(Typeface.DEFAULT);
				}
			}
		});
		
		button4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), BookmarkletsActivity.class);
				startActivity(intent);
			}
		});
		
		useragent.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), UseragentActivity.class);
				startActivity(intent);
			}
		});
		
		replacer.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), ReplaceActivity.class);
				startActivity(intent);
			}
		});
		
		except.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), ExceptionsActivity.class);
				startActivity(intent);
			}
		});
		
		seekbar1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged(SeekBar _param1, int _param2, boolean _param3) {
				final int _progressValue = _param2;
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt", String.valueOf((long)(_progressValue + 20)));
				hintt.setText("Розмір кнопок в панелях (".concat(String.valueOf((long)(_progressValue + 20)).concat(" dp)")));
				e1.getLayoutParams().width = (int) ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density * 1.27));
				e1.getLayoutParams().height = (int) (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density);
				e1.setTextSize( Float.parseFloat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) / 2.5f);
				e1.requestLayout();
				
				e2.getLayoutParams().width = (int) ((Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density * 1.27));
				e2.getLayoutParams().height = (int) (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) * getResources().getDisplayMetrics().density);
				e2.setTextSize( Float.parseFloat(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) / 2.5f);
				e2.requestLayout();
				
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar _param1) {
				
			}
			
			@Override
			public void onStopTrackingTouch(SeekBar _param2) {
				
			}
		});
		
		onnointernet.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/onNoInternet.txt")) == 0) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/onNoInternet.txt", "1");
					onnointernet.setChecked(true);
				}
				else {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/onNoInternet.txt", "0");
					onnointernet.setChecked(false);
				}
			}
		});
		
		opentheme.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), CustomthemeActivity.class);
				startActivity(intent);
			}
		});
		
		infogravity.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/InfoText.txt")) == 0) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/InfoText.txt", "1");
					infogravity.setChecked(true);
				}
				else {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/InfoText.txt", "0");
					infogravity.setChecked(false);
				}
			}
		});
		
		auto.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/autofirstpage.txt")) == 0) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/autofirstpage.txt", "1");
					auto.setChecked(true);
					linear4.setVisibility(View.GONE);
				}
				else {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/autofirstpage.txt", "0");
					auto.setChecked(false);
					linear4.setVisibility(View.VISIBLE);
					linear4.requestFocus();
					anim.setTarget(linear4);
					anim.setPropertyName("scaleX");
					anim.setFloatValues((float)(0), (float)(1));
					anim.setDuration((int)(1000));
					anim.start();
				}
			}
		});
		
		history.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), HistoryActivity.class);
				startActivity(intent);
			}
		});
		
		setaccess.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Blockad/blockredir.txt").equals("1")) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Blockad/blockredir.txt", "0");
					setaccess.setChecked(false);
				}
				else {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Blockad/blockredir.txt", "1");
					setaccess.setChecked(true);
				}
			}
		});
		
		videoad.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/Blockad/skipvideoad.txt").equals("1")) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Blockad/skipvideoad.txt", "0");
					videoad.setChecked(false);
				}
				else {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Blockad/skipvideoad.txt", "1");
					videoad.setChecked(true);
				}
			}
		});
		
		privat.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", "4149499996845630"));
			}
		});
		
		uk.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (FileUtil.getFileLength("/storage/emulated/0/WeekBrowser/Language.welang") < 3) {
					FileUtil.deleteFile("/storage/emulated/0/WeekBrowser/Language.welang");
				}
				else {
					new java.io.File("/storage/emulated/0/WeekBrowser/Language.welang").renameTo(new java.io.File("/storage/emulated/0/WeekBrowser/noLanguage.welang"));
				}
			}
		});
		
		en.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				new java.io.File("/storage/emulated/0/WeekBrowser/Language.welang").renameTo(new java.io.File("/storage/emulated/0/WeekBrowser/noLanguage.welang"));
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Language.welang", "");
			}
		});
		
		custom.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (FileUtil.getFileLength("/storage/emulated/0/WeekBrowser/noLanguage.welang") > 2) {
					new java.io.File(" /storage/emulated/0/WeekBrowser/noLanguage.welang").renameTo(new java.io.File("/storage/emulated/0/WeekBrowser/Language.welang"));
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "Custom language don't exist");
				}
			}
		});
		
		loadcus.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(fp, REQ_CD_FP);
			}
		});
		
		srhalm.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				hints.setTitle("!!!");
				try{
					hints.setMessage(languag.get((int)(41)));
				}catch(Exception e){
					if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
						hints.setMessage("While incognito is turned on, DuckDuckGo is forced on because only this engine won't collect your data");
					}
					else {
						hints.setMessage("При увімкненому режимі інкогніто буде примусово увімкнено DuckDuckGo, оскільки це єдина пошукова система з вище перерахованих, яка не зберігає жодних даних");
					}
				}
				hints.setPositiveButton("OK", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				hints.create().show();
			}
		});
		
		google.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SearchEngine.txt", "0");
			}
		});
		
		bing.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SearchEngine.txt", "1");
			}
		});
		
		yahoo.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SearchEngine.txt", "2");
			}
		});
		
		duck.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/SearchEngine.txt", "3");
			}
		});
		
		hide.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/HidePanels.txt")) == 0) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/HidePanels.txt", "1");
					onnointernet.setChecked(true);
				}
				else {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/HidePanels.txt", "0");
					onnointernet.setChecked(false);
				}
			}
		});
		
		panhint.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				hints.setTitle("?");
				try{
					hints.setMessage(languag.get((int)(47)));
				}catch(Exception e){
					if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
						hints.setMessage("If you can't show panels, close and open this browser, easiest way — touch button (or do gesture) \"Recent apps □\" and open WeekBrowser");
					}
					else {
						hints.setMessage("Якщо з якихось причин не виходить проявити панелі, вийдіть з браузера та зайдіть, найпростіший спосіб — натиснути кнопку (або здійснити жест) \"Недавні програми □\", та відкрити WeekBrowser");
					}
				}
				hints.setPositiveButton("OK", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				hints.create().show();
			}
		});
		
		preview.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/NoPreview.txt")) == 0) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/NoPreview.txt", "1");
					auto.setChecked(true);
				}
				else {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/NoPreview.txt", "0");
					auto.setChecked(false);
				}
			}
		});
		
		hidehint.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				scr.setTitle("!!!");
				scr.setMessage("Працює не на всіх пристроях, якщо все-таки це потрібно, забороніть скріншоти");
				scr.setPositiveButton("Заборонити скріншоти в режимі інкогніто", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						screen.performClick();
					}
				});
				scr.setNegativeButton("Ні, дякую", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				scr.create().show();
			}
		});
		
		e1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		cachehint.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				hints.setTitle("?");
				try{
					hints.setMessage(languag.get((int)(56)));
				}catch(Exception e){
					if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
						hints.setMessage("\"Standard\" mode is most applied. \"Cache else network\" may economy network traffic, but on some sites with dynamically refreshing information data may not refresh. \"Only network\" will economy ROM of your device (cache won't save) but it will raise network traffic. \"Only cache\" — mode which network don't uses, this option is mostly useless.");
					}
					else {
						hints.setMessage("Режим \"Стандарт\" часто є найоптимальнішим варіантом. \"Спочатку кеш, потім мережа\" може зекономити Ваш інтернет-трафік, але на деяких сайтах з динамічно оновлюваною інформацією може не оновлюватися інформація. \"Лише мережа\" зекономить Вашу пам'ять телефону (кеш не буде зберігатися), але буде більший інтернет-трафік. \"Лише кеш\" — це режим, у якій мережа зовсім не використовується, через що це найменш корисна опція.");
					}
				}
				hints.setPositiveButton("OK", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				hints.create().show();
			}
		});
		
		std.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/cache.txt", "0");
			}
		});
		
		dts.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/cache.txt", "1");
			}
		});
		
		ionl.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/cache.txt", "2");
			}
		});
		
		conl.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/cache.txt", "3");
			}
		});
		
		light.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt", "0");
				_theme();
			}
		});
		
		dark.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt", "1");
				_theme();
			}
		});
		
		highcontrast.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt", "2");
				_theme();
			}
		});
		
		customtheme.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt", "3");
				_theme();
			}
		});
		
		loadingslash.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt", "0");
			}
		});
		
		percent.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt", "3");
			}
		});
		
		loadingpercent.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt", "1");
			}
		});
		
		slash.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt", "2");
			}
		});
		
		slpercentash.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt", "4");
			}
		});
		
		startpage.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				FileUtil.writeFile("/storage/emulated/0/WeekBrowser/firstpage.txt", _charSeq);
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		bookmarks.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startpage.setText("file:///storage/emulated/0/WeekBrowser/bookmark.html");
			}
		});
		
		googl.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startpage.setText("https://www.google.com");
			}
		});
		
		bng.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startpage.setText("https://www.bing.com");
			}
		});
		
		yaho.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startpage.setText("https://www.yahoo.com");
			}
		});
		
		duckgo.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startpage.setText("https://www.duckduckgo.com");
			}
		});
		
		srccln.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				try{
					alarm = languag.get((int)(109));
				}catch(Exception e){
					if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
						alarm = "ALARM";
					}
					else {
						alarm = "ПОПЕРЕДЖЕННЯ";
					}
				}
				try{
					douwant = languag.get((int)(148));
				}catch(Exception e){
					if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
						douwant = "Afer clicking \"Yes\" button, you will clear history of search. This is not undoable, but you can write search prompt on keyboard again. Do you want this? Think 2 times ;)";
					}
					else {
						douwant = "Після натискання кнопки \"Так\", Ви очистите історію пошуку. Це неможливо відновити, але Ви можете знову набрати пошуковий запит на клавіатурі. Ви хочете цього? Подумайте двічі ;)";
					}
				}
				try{
					yes = languag.get((int)(108));
				}catch(Exception e){
					if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
						yes = "YES";
					}
					else {
						yes = "ТАК";
					}
				}
				try{
					no = languag.get((int)(107));
				}catch(Exception e){
					if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
						no = "NO";
					}
					else {
						no = "НІ";
					}
				}
				dlg.setTitle(alarm);
				dlg.setMessage(douwant);
				dlg.setPositiveButton(yes, new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						FileUtil.writeFile("/storage/emulated/0/WeekBrowser/search.txt", "[weekbrowser]");
						SketchwareUtil.showMessage(getApplicationContext(), "Історію пошуку очищено!");
					}
				});
				dlg.setNegativeButton(no, new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dlg.create().show();
			}
		});
		
		srha.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Autoclean/search.txt")) == 0) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Autoclean/search.txt", "1");
					srha.setChecked(true);
				}
				else {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Autoclean/search.txt", "0");
					srha.setChecked(false);
				}
			}
		});
		
		clrcache.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				webview1.clearCache(true);
				try{
					cacheisclear = languag.get((int)(150));
				}catch(Exception e){
					if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
						cacheisclear = "Cache is clean!";
					}
					else {
						cacheisclear = "Кеш очищено!";
					}
				}
				SketchwareUtil.showMessage(getApplicationContext(), cacheisclear);
			}
		});
		
		cachea.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Autoclean/cache.txt")) == 0) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Autoclean/cache.txt", "1");
					cachea.setChecked(true);
				}
				else {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Autoclean/cache.txt", "0");
					cachea.setChecked(false);
				}
			}
		});
		
		cookieclr.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				CookieManager.getInstance().removeAllCookies(null);
				SketchwareUtil.showMessage(getApplicationContext(), "Кукі очищено!");
			}
		});
		
		cookiea.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Autoclean/cookie.txt")) == 0) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Autoclean/cookie.txt", "1");
					cookiea.setChecked(true);
				}
				else {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Autoclean/cookie.txt", "0");
					cookiea.setChecked(false);
				}
			}
		});
		
		formclr.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				webview1.clearFormData();
				SketchwareUtil.showMessage(getApplicationContext(), "Дані автозаповнення очищено!");
			}
		});
		
		forma.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Autoclean/form.txt")) == 0) {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Autoclean/form.txt", "1");
					forma.setChecked(true);
				}
				else {
					FileUtil.writeFile("/storage/emulated/0/WeekBrowser/Autoclean/form.txt", "0");
					forma.setChecked(false);
				}
			}
		});
		
		tgk.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setAction(Intent.ACTION_VIEW);
				intent.setData(Uri.parse("https://t.me/a525team/"));
				startActivity(Intent.createChooser(intent, "Передача даних СБУ, не вимикайте пристрій..."));
			}
		});
		
		tgkc.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", "https://t.me/a525team/"));
			}
		});
		
		tgc.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setAction(Intent.ACTION_VIEW);
				intent.setData(Uri.parse("https://t.me/week_thor/"));
				startActivity(Intent.createChooser(intent, "Інтім не предлагать, могу ні отказаца"));
			}
		});
		
		tgcc.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", "https://t.me/week_thor/"));
			}
		});
	}
	
	private void initializeLogic() {
		navpan.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/NavPan.txt")) == 1);
		std.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 0);
		dts.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 1);
		ionl.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 2);
		srha.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Autoclean/search.txt")) == 1);
		cachea.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Autoclean/cache.txt")) == 1);
		cookiea.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Autoclean/cookie.txt")) == 1);
		forma.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Autoclean/form.txt")) == 1);
		conl.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/cache.txt")) == 3);
		light.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0);
		dark.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1);
		highcontrast.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2);
		customtheme.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 3);
		loadingslash.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) == 0);
		loadingpercent.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) == 1);
		slash.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) == 2);
		percent.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) == 3);
		slpercentash.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/loadingstyle.txt")) == 4);
		infogravity.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/InfoText.txt")) == 1);
		onnointernet.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/onNoInternet.txt")) == 1);
		google.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/SearchEngine.txt")) == 0);
		bing.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/SearchEngine.txt")) == 1);
		yahoo.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/SearchEngine.txt")) == 2);
		duck.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/SearchEngine.txt")) == 3);
		hide.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/HidePanels.txt")) == 1);
		srup.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Searchpanelpos.txt")) == 1);
		pnup.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Navpanelpos.txt")) == 1);
		auto.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/autofirstpage.txt")) == 1);
		zoombtns.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/ZoomButton.txt")) == 1);
		screen.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/NoScreen.txt")) == 1);
		preview.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/NoPreview.txt")) == 1);
		mono.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/monofortextarea.txt")) == 1);
		setaccess.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Blockad/blockredir.txt")) == 1);
		videoad.setChecked(Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Blockad/skipvideoad.txt")) == 1);
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/autofirstpage.txt").equals("1")) {
			linear4.setVisibility(View.GONE);
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/NoScreen.txt").equals("1")) {
			linear21.setVisibility(View.GONE);
		}
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/NavPan.txt").equals("0")) {
			pnup.setVisibility(View.GONE);
		}
		startpage.setText(FileUtil.readFile("/storage/emulated/0/WeekBrowser/firstpage.txt"));
		keywords.setText(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Blockad/videopatterns.txt"));
		uk.setChecked(!FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang"));
		en.setChecked(FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang") && (FileUtil.getFileLength("/storage/emulated/0/WeekBrowser/Language.welang") < 3));
		custom.setChecked(FileUtil.getFileLength("/storage/emulated/0/WeekBrowser/Language.welang") > 2);
		
		seekbar1.setProgress((int)Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Sizes/button.txt")) - 20);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_FP:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				if (_filePath.get((int)(0)).contains(".welang")) {
					FileUtil.copyFile(_filePath.get((int)(0)), "/storage/emulated/0/WeekBrowser/Language.welang");
					intent.setClass(getApplicationContext(), SettingsActivity.class);
					startActivity(intent);
					finishAffinity();
				}
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		finish();
	}
	
	@Override
	public void onResume() {
		super.onResume();
		if (FileUtil.readFile("/storage/emulated/0/WeekBrowser/monofortextarea.txt").equals("1")) {
			startpage.setTypeface(Typeface.MONOSPACE);
		}
		else {
			startpage.setTypeface(Typeface.DEFAULT);
		}
		_Languag();
		_theme();
	}
	public void _Languag() {
		if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
			languag = new Gson().fromJson(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Language.welang"), new TypeToken<ArrayList<String>>(){}.getType());
		}
		try{
			name.setText(languag.get((int)(39)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				name.setText("GENERAL SETTINGS");
			}
			else {
				name.setText("ЗАГАЛЬНІ НАЛАШТУВАННЯ");
			}
		}
		try{
			td1.setText(languag.get((int)(40)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				td1.setText("Default search engine");
			}
			else {
				td1.setText("Пошукова система за замовчуванням");
			}
		}
		try{
			textview3.setText(languag.get((int)(42)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				textview3.setText("Content appearance");
			}
			else {
				textview3.setText("Відображення вмісту");
			}
		}
		try{
			navpan.setText(languag.get((int)(43)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				navpan.setText("Show navigation panel");
			}
			else {
				navpan.setText("Показати панель навігації");
			}
		}
		try{
			srup.setText(languag.get((int)(44)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				srup.setText("Search panel to header");
			}
			else {
				srup.setText("Панель пошуку зверху");
			}
		}
		try{
			hide.setText(languag.get((int)(45)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				hide.setText("Hide panels when scroll down");
			}
			else {
				hide.setText("Приховувати панелі при прогортуванні вниз");
			}
		}
		try{
			zoombtns.setText(languag.get((int)(46)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				zoombtns.setText("Show zoom buttons");
			}
			else {
				zoombtns.setText("Показати кнопки масштабування");
			}
		}
		try{
			button4.setText(languag.get((int)(48)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				button4.setText("OPEN BOOKMARKLET SETTINGS");
			}
			else {
				button4.setText("ВІДКРИТИ НАЛАШТУВАННЯ БУКМАРКЛЕТІВ");
			}
		}
		try{
			useragent.setText(languag.get((int)(49)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				useragent.setText("OPEN USERAGENT SETTINGS");
			}
			else {
				useragent.setText("ВІДКРИТИ НАЛАШТУВАННЯ АГЕНТУ КОРИСТУВАЧА");
			}
		}
		try{
			replacer.setText(languag.get((int)(50)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				replacer.setText("SEARCH AND REPLACE IN LINKS MANAGER");
			}
			else {
				replacer.setText("МЕНЕДЖЕР ПОШУКУ ТА ЗАМІН У ПОСИЛАННЯХ");
			}
		}
		try{
			textview2.setText(languag.get((int)(51)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				textview2.setText("Cache settings");
			}
			else {
				textview2.setText("Налаштування кешу");
			}
		}
		try{
			std.setText(languag.get((int)(52)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				std.setText("Standard");
			}
			else {
				std.setText("Стандарт");
			}
		}
		try{
			dts.setText(languag.get((int)(53)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				dts.setText("Load cache else network");
			}
			else {
				dts.setText("Кеш, інакше мережа");
			}
		}
		try{
			ionl.setText(languag.get((int)(54)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				ionl.setText("Network only");
			}
			else {
				ionl.setText("Лише мережа");
			}
		}
		try{
			conl.setText(languag.get((int)(55)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				conl.setText("Cache only (offline)");
			}
			else {
				conl.setText("Лише кеш (офлайн)");
			}
		}
		try{
			onnointernet.setText(languag.get((int)(57)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				onnointernet.setText("Offline mode when no internet connection");
			}
			else {
				onnointernet.setText("Офлайн-режим, якщо немає інтернет-з'єднання");
			}
		}
		try{
			textview6.setText(languag.get((int)(58)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				textview6.setText("Interface theme");
			}
			else {
				textview6.setText("Тема оформлення");
			}
		}
		try{
			light.setText(languag.get((int)(59)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				light.setText("Light");
			}
			else {
				light.setText("Світла");
			}
		}
		try{
			dark.setText(languag.get((int)(60)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				dark.setText("Dark");
			}
			else {
				dark.setText("Темна");
			}
		}
		try{
			highcontrast.setText(languag.get((int)(61)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				highcontrast.setText("High contrast");
			}
			else {
				highcontrast.setText("Висококонтрастна");
			}
		}
		try{
			customtheme.setText(languag.get((int)(62)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				customtheme.setText("Custom");
			}
			else {
				customtheme.setText("Користувацька");
			}
		}
		try{
			opentheme.setText(languag.get((int)(63)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				opentheme.setText("OPEN THEME EDITOR (YOU MAY ALSO OPEN SKIN FILE)");
			}
			else {
				opentheme.setText("ВІДКРИТИ РЕДАКТОР ТЕМ (ТАКОЖ ВИ МОЖЕТЕ ВІДКРИТИ ФАЙЛ СКІНА)");
			}
		}
		try{
			loadstyle.setText(languag.get((int)(64)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				loadstyle.setText("Loading indicator style");
			}
			else {
				loadstyle.setText("Стиль індикатора завантаження");
			}
		}
		try{
			loadingslash.setText(languag.get((int)(65)).concat(" /////////////////"));
			loadingpercent.setText(languag.get((int)(65)).concat(" 35%"));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				loadingslash.setText("Loading  /////////////////");
				loadingpercent.setText("Loading 35%");
			}
			else {
				loadingslash.setText("Завантаження  /////////////////");
				loadingpercent.setText("Завантаження 35%");
			}
		}
		try{
			infogravity.setText(languag.get((int)(66)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				infogravity.setText("Fit to center");
			}
			else {
				infogravity.setText("Вирівнювання по центру");
			}
		}
		try{
			textview7.setText(languag.get((int)(67)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				textview7.setText("Clean");
			}
			else {
				textview7.setText("Очищення");
			}
		}
		try{
			srccln.setText(languag.get((int)(68)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				srccln.setText("CLEAR SEARCH HISTORY");
			}
			else {
				srccln.setText("ОЧИСТИТИ ІСТОРІЮ ПОШУКУ");
			}
		}
		try{
			history.setText(languag.get((int)(69)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				history.setText("⤤⿴ JOINED WEBSITE HISTORY (YOU MAY CLEAN IT HERE)");
			}
			else {
				history.setText("⤤⿴ ІСТОРІЯ ВІДВІДАНИХ ВЕБСАЙТІВ (ВИ МОЖЕТЕ ЦЕ ОЧИСТИТИ ТУТ)");
			}
		}
		try{
			clrcache.setText(languag.get((int)(70)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				clrcache.setText("CLEAR CACHE");
			}
			else {
				clrcache.setText("ОЧИСТИТИ КЕШ");
			}
		}
		try{
			textview8.setText(languag.get((int)(71)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				textview8.setText("Start page");
			}
			else {
				textview8.setText("Стартова сторінка");
			}
		}
		try{
			auto.setText(languag.get((int)(72)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				auto.setText("Automaticaly set last joined webpage");
			}
			else {
				auto.setText("Автоматично обрати останню відвідану веб-сторінку");
			}
		}
		try{
			bookmarks.setText(languag.get((int)(112)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				bookmarks.setText("BOOKMARKS");
			}
			else {
				bookmarks.setText("ЗАКЛАДКИ");
			}
		}
		try{
			startpage.setHint(languag.get((int)(73)));
		}catch(Exception e){
			if (FileUtil.isExistFile("/storage/emulated/0/WeekBrowser/Language.welang")) {
				startpage.setHint("Start page link");
			}
			else {
				startpage.setHint("Посилання на стартову сторінку");
			}
		}
	}
	
	
	public void _theme() {
		if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 0) {
			textview2.setTextColor(0xFF33B5E5);
			textview3.setTextColor(0xFF33B5E5);
			textview6.setTextColor(0xFF33B5E5);
			
			std.setTextColor(0xFF000000);
			dts.setTextColor(0xFF000000);
			ionl.setTextColor(0xFF000000);
			conl.setTextColor(0xFF000000);
			light.setTextColor(0xFF000000);
			dark.setTextColor(0xFF000000);
			customtheme.setTextColor(0xFF000000);
			useragent.setTextColor(0xFF000000);
			highcontrast.setTextColor(0xFF000000);
			getWindow().getDecorView().setBackgroundColor(Color.parseColor("#ffffff"));
			infogravity.setTextColor(0xFF000000);
			button4.setBackgroundColor(0xFF33B5E5);
			button4.setTextColor(0xFF000000);
			navpan.setTextColor(0xFF000000);
			loadingslash.setTextColor(0xFF000000);
			percent.setTextColor(0xFF000000);
			loadingpercent.setTextColor(0xFF000000);
			slash.setTextColor(0xFF000000);
			onnointernet.setTextColor(0xFF000000);
			loadstyle.setTextColor(0xFF33B5E5);
			opentheme.setBackgroundColor(0xFF33B5E5);
			useragent.setBackgroundColor(0xFF33B5E5);
			google.setTextColor(0xFF000000);
			bing.setTextColor(0xFF000000);
			duck.setTextColor(0xFF000000);
			yahoo.setTextColor(0xFF000000);
			srhalm.setTextColor(0xFFFFFFFF);
			td1.setTextColor(0xFF33B5E5);
			hide.setTextColor(0xFF000000);
			hintt.setTextColor(0xFF000000);
			srup.setTextColor(0xFF000000);
			opentheme.setTextColor(0xFF000000);
			replacer.setBackgroundColor(0xFF33B5E5);
			replacer.setTextColor(0xFF000000);
			textview7.setTextColor(0xFF33B5E5);
			srccln.setTextColor(0xFF000000);
			srccln.setBackgroundColor(0xFF33B5E5);
			name.setTextColor(0xFF000000);
			textview8.setTextColor(0xFF33B5E5);
			startpage.setTextColor(0xFF000000);
			startpage.setHintTextColor(0xFF757575);
			bookmarks.setTextColor(0xFF000000);
			bookmarks.setBackgroundColor(0xFF33B5E5);
			googl.setTextColor(0xFF000000);
			googl.setBackgroundColor(0xFF33B5E5);
			bng.setTextColor(0xFF000000);
			bng.setBackgroundColor(0xFF33B5E5);
			yaho.setTextColor(0xFF000000);
			yaho.setBackgroundColor(0xFF33B5E5);
			duckgo.setTextColor(0xFF000000);
			duckgo.setBackgroundColor(0xFF33B5E5);
			history.setTextColor(0xFF000000);
			history.setBackgroundColor(0xFF33B5E5);
			auto.setTextColor(0xFF000000);
			clrcache.setTextColor(0xFF000000);
			clrcache.setBackgroundColor(0xFF33B5E5);
			zoombtns.setTextColor(0xFF000000);
			slpercentash.setTextColor(0xFF000000);
			textview9.setTextColor(0xFF33B5E5);
			uk.setTextColor(0xFF000000);
			en.setTextColor(0xFF000000);
			loadcus.setBackgroundColor(0xFF33B5E5);
			custom.setTextColor(0xFF000000);
			loadcus.setTextColor(0xFF000000);
			screen.setTextColor(0xFF000000);
			preview.setTextColor(0xFF000000);
			mono.setTextColor(0xFF000000);
			except.setTextColor(0xFF000000);
			except.setBackgroundColor(0xFF33B5E5);
			bladtxt.setTextColor(0xFF33B5E5);
			
			
			
			setaccess.setTextColor(0xFF000000);
			
			
			
			
			
			panhint.setTextColor(0xFF000000);
			cachehint.setBackgroundColor(0xFF33B5E5);
			cachehint.setTextColor(0xFF000000);
			panhint.setBackgroundColor(0xFF33B5E5);
			srhalm.setBackgroundColor(0xFFB71C1C);
			e1.setTextColor(0xFF000000);
			e1.setBackgroundColor(0xFF33B5E5);
			e2.setTextColor(0xFF000000);
			e2.setBackgroundColor(0xFF33B5E5);
			pnup.setTextColor(0xFF000000);
			textview11.setTextColor(0xFF33B5E5);
			cookieclr.setBackgroundColor(0xFF33B5E5);
			cookieclr.setTextColor(0xFF000000);
			formclr.setBackgroundColor(0xFF33B5E5);
			formclr.setTextColor(0xFF000000);
			about.setTextColor(0xFF33B5E5);
			developerinfo.setTextColor(0xFF000000);
			tgk.setBackgroundColor(0xFF33B5E5);
			tgk.setTextColor(0xFF000000);
			tgkc.setBackgroundColor(0xFF33B5E5);
			tgkc.setTextColor(0xFF000000);
			tgc.setBackgroundColor(0xFF33B5E5);
			tgc.setTextColor(0xFF000000);
			tgcc.setBackgroundColor(0xFF33B5E5);
			tgcc.setTextColor(0xFF000000);
			privat.setBackgroundColor(0xFF33B5E5);
			privat.setTextColor(0xFF000000);
			hidehint.setBackgroundColor(0xFFB71C1C);
			hidehint.setTextColor(0xFF000000);
			videoad.setTextColor(0xFF000000);
			textview12.setTextColor(0xFF33B5E5);
			keywords.setTextColor(0xFF000000);
			keywords.setHintTextColor(0xFF757575);
		}
		else {
			if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 1) {
				textview2.setTextColor(0xFF33B5E5);
				infogravity.setTextColor(0xFFFFFFFF);
				textview3.setTextColor(0xFF33B5E5);
				loadstyle.setTextColor(0xFF33B5E5);
				textview6.setTextColor(0xFF33B5E5);
				hintt.setTextColor(0xFFFFFFFF);
				std.setTextColor(0xFFFFFFFF);
				dts.setTextColor(0xFFFFFFFF);
				ionl.setTextColor(0xFFFFFFFF);
				conl.setTextColor(0xFFFFFFFF);
				light.setTextColor(0xFFFFFFFF);
				dark.setTextColor(0xFFFFFFFF);
				getWindow().getDecorView().setBackgroundColor(Color.parseColor("#111111"));
				highcontrast.setTextColor(0xFFFFFFFF);
				button4.setBackgroundColor(0xFF33B5E5);
				button4.setTextColor(0xFF000000);
				navpan.setTextColor(0xFFFFFFFF);
				loadingslash.setTextColor(0xFFFFFFFF);
				percent.setTextColor(0xFFFFFFFF);
				loadingpercent.setTextColor(0xFFFFFFFF);
				slash.setTextColor(0xFFFFFFFF);
				onnointernet.setTextColor(0xFFFFFFFF);
				bing.setTextColor(0xFFFFFFFF);
				duck.setTextColor(0xFFFFFFFF);
				srhalm.setTextColor(0xFFFFFFFF);
				td1.setTextColor(0xFF33B5E5);
				google.setTextColor(0xFFFFFFFF);
				customtheme.setTextColor(0xFFFFFFFF);
				opentheme.setTextColor(0xFF000000);
				opentheme.setBackgroundColor(0xFF33B5E5);
				useragent.setBackgroundColor(0xFF33B5E5);
				hide.setTextColor(0xFFFFFFFF);
				
				srup.setTextColor(0xFFFFFFFF);
				replacer.setBackgroundColor(0xFF33B5E5);
				replacer.setTextColor(0xFF000000);
				textview7.setTextColor(0xFF33B5E5);
				srccln.setTextColor(0xFF000000);
				srccln.setBackgroundColor(0xFF33B5E5);
				name.setTextColor(0xFFFFFFFF);
				textview8.setTextColor(0xFF33B5E5);
				startpage.setTextColor(0xFFFFFFFF);
				startpage.setHintTextColor(0xFFBDBDBD);
				bookmarks.setTextColor(0xFF000000);
				bookmarks.setBackgroundColor(0xFF33B5E5);
				googl.setTextColor(0xFF000000);
				googl.setBackgroundColor(0xFF33B5E5);
				bng.setTextColor(0xFF000000);
				bng.setBackgroundColor(0xFF33B5E5);
				yaho.setTextColor(0xFF000000);
				yaho.setBackgroundColor(0xFF33B5E5);
				duckgo.setTextColor(0xFF000000);
				duckgo.setBackgroundColor(0xFF33B5E5);
				history.setTextColor(0xFF000000);
				history.setBackgroundColor(0xFF33B5E5);
				auto.setTextColor(0xFFFFFFFF);
				clrcache.setTextColor(0xFF000000);
				clrcache.setBackgroundColor(0xFF33B5E5);
				zoombtns.setTextColor(0xFFFFFFFF);
				slpercentash.setTextColor(0xFFFFFFFF);
				textview9.setTextColor(0xFF33B5E5);
				uk.setTextColor(0xFFFFFFFF);
				en.setTextColor(0xFFFFFFFF);
				loadcus.setBackgroundColor(0xFF33B5E5);
				custom.setTextColor(0xFFFFFFFF);
				loadcus.setTextColor(0xFF000000);
				screen.setTextColor(0xFFFFFFFF);
				preview.setTextColor(0xFFFFFFFF);
				mono.setTextColor(0xFFFFFFFF);
				except.setTextColor(0xFF000000);
				except.setBackgroundColor(0xFF33B5E5);
				bladtxt.setTextColor(0xFF33B5E5);
				
				
				
				setaccess.setTextColor(0xFFFFFFFF);
				
				
				
				
				
				panhint.setTextColor(0xFF000000);
				cachehint.setBackgroundColor(0xFF33B5E5);
				cachehint.setTextColor(0xFF000000);
				panhint.setBackgroundColor(0xFF33B5E5);
				yahoo.setTextColor(0xFFFFFFFF);
				srhalm.setBackgroundColor(0xFFB71C1C);
				e1.setTextColor(0xFF000000);
				e1.setBackgroundColor(0xFF33B5E5);
				e2.setTextColor(0xFF000000);
				e2.setBackgroundColor(0xFF33B5E5);
				pnup.setTextColor(0xFFFFFFFF);
				textview11.setTextColor(0xFF33B5E5);
				cookieclr.setBackgroundColor(0xFF33B5E5);
				cookieclr.setTextColor(0xFF000000);
				formclr.setBackgroundColor(0xFF33B5E5);
				formclr.setTextColor(0xFF000000);
				about.setTextColor(0xFF33B5E5);
				developerinfo.setTextColor(0xFFFFFFFF);
				tgk.setBackgroundColor(0xFF33B5E5);
				tgk.setTextColor(0xFF000000);
				tgkc.setBackgroundColor(0xFF33B5E5);
				tgkc.setTextColor(0xFF000000);
				tgc.setBackgroundColor(0xFF33B5E5);
				tgc.setTextColor(0xFF000000);
				tgcc.setBackgroundColor(0xFF33B5E5);
				tgcc.setTextColor(0xFF000000);
				privat.setBackgroundColor(0xFF33B5E5);
				privat.setTextColor(0xFF000000);
				hidehint.setBackgroundColor(0xFFB71C1C);
				hidehint.setTextColor(0xFF000000);
				videoad.setTextColor(0xFFFFFFFF);
				textview12.setTextColor(0xFF33B5E5);
				keywords.setTextColor(0xFFFFFFFF);
				keywords.setHintTextColor(0xFFBDBDBD);
			}
			else {
				if (Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/Themes/theme.txt")) == 2) {
					clrcache.setTextColor(0xFF000000);
					clrcache.setBackgroundColor(0xFF00FF00);
					hide.setTextColor(0xFF00FF00);
					hintt.setTextColor(0xFF00FF00);
					textview2.setTextColor(0xFFFF0070);
					textview3.setTextColor(0xFFFF0070);
					infogravity.setTextColor(0xFF00FF00);
					textview6.setTextColor(0xFFFF0070);
					textview11.setTextColor(0xFFFF0070);
					std.setTextColor(0xFF00FF00);
					dts.setTextColor(0xFF00FF00);
					ionl.setTextColor(0xFF00FF00);
					conl.setTextColor(0xFF00FF00);
					light.setTextColor(0xFF00FF00);
					dark.setTextColor(0xFF00FF00);
					loadstyle.setTextColor(0xFFFF0070);
					highcontrast.setTextColor(0xFF00FF00);
					button4.setBackgroundColor(0xFF00FF00);
					customtheme.setTextColor(0xFF00FF00);
					useragent.setTextColor(0xFF000000);
					button4.setTextColor(0xFF000000);
					navpan.setTextColor(0xFF00FF00);
					loadingslash.setTextColor(0xFF00FF00);
					percent.setTextColor(0xFF00FF00);
					loadingpercent.setTextColor(0xFF00FF00);
					opentheme.setBackgroundColor(0xFF00FF00);
					opentheme.setTextColor(0xFF000000);
					slash.setTextColor(0xFF00FF00);
					getWindow().getDecorView().setBackgroundColor(Color.parseColor("#000000"));
					onnointernet.setTextColor(0xFF00FF00);
					useragent.setBackgroundColor(0xFF00FF00);
					google.setTextColor(0xFF00FF00);
					bing.setTextColor(0xFF00FF00);
					duck.setTextColor(0xFF00FF00);
					yahoo.setTextColor(0xFF00FF00);
					srhalm.setTextColor(0xFF000000);
					td1.setTextColor(0xFFFF0070);
					srup.setTextColor(0xFF00FF00);
					replacer.setBackgroundColor(0xFF00FF00);
					replacer.setTextColor(0xFF000000);
					textview7.setTextColor(0xFFFF0070);
					srccln.setTextColor(0xFF000000);
					srccln.setBackgroundColor(0xFF00FF00);
					name.setTextColor(0xFF00FF00);
					textview8.setTextColor(0xFFFF0070);
					startpage.setTextColor(0xFF00FFFF);
					startpage.setHintTextColor(0xFF7000FF);
					bookmarks.setTextColor(0xFF000000);
					bookmarks.setBackgroundColor(0xFF00FF00);
					googl.setTextColor(0xFF000000);
					googl.setBackgroundColor(0xFF00FF00);
					bng.setTextColor(0xFF000000);
					bng.setBackgroundColor(0xFF00FF00);
					yaho.setTextColor(0xFF000000);
					yaho.setBackgroundColor(0xFF00FF00);
					duckgo.setTextColor(0xFF000000);
					duckgo.setBackgroundColor(0xFF00FF00);
					history.setTextColor(0xFF000000);
					history.setBackgroundColor(0xFF00FF00);
					auto.setTextColor(0xFF00FF00);
					zoombtns.setTextColor(0xFF00FF00);
					slpercentash.setTextColor(0xFF00FF00);
					textview9.setTextColor(0xFFFF0070);
					uk.setTextColor(0xFF00FF00);
					en.setTextColor(0xFF00FF00);
					loadcus.setBackgroundColor(0xFF00FF00);
					custom.setTextColor(0xFF00FF00);
					loadcus.setTextColor(0xFF000000);
					screen.setTextColor(0xFF00FF00);
					preview.setTextColor(0xFF00FF00);
					mono.setTextColor(0xFF00FF00);
					except.setTextColor(0xFF000000);
					except.setBackgroundColor(0xFF00FF00);
					bladtxt.setTextColor(0xFFFF0070);
					
					
					
					
					setaccess.setTextColor(0xFF00FF00);
					
					
					
					
					panhint.setTextColor(0xFF000000);
					cachehint.setBackgroundColor(0xFF00FF00);
					cachehint.setTextColor(0xFF000000);
					panhint.setBackgroundColor(0xFF00FF00);
					srhalm.setBackgroundColor(0xFFF00000);
					e1.setTextColor(0xFF000000);
					e1.setBackgroundColor(0xFF00FF00);
					e2.setTextColor(0xFF000000);
					e2.setBackgroundColor(0xFF00FF00);
					pnup.setTextColor(0xFF00FF00);
					cookieclr.setBackgroundColor(0xFF00FF00);
					cookieclr.setTextColor(0xFF000000);
					formclr.setBackgroundColor(0xFF00FF00);
					formclr.setTextColor(0xFF000000);
					about.setTextColor(0xFFFF0070);
					developerinfo.setTextColor(0xFF00FF00);
					tgk.setBackgroundColor(0xFF00FF00);
					tgk.setTextColor(0xFF000000);
					tgkc.setBackgroundColor(0xFF00FF00);
					tgkc.setTextColor(0xFF000000);
					tgc.setBackgroundColor(0xFF00FF00);
					tgc.setTextColor(0xFF000000);
					tgcc.setBackgroundColor(0xFF00FF00);
					tgcc.setTextColor(0xFF000000);
					privat.setBackgroundColor(0xFF00FF00);
					privat.setTextColor(0xFF000000);
					hidehint.setBackgroundColor(0xFFFF0000);
					hidehint.setTextColor(0xFFFF0000);
					videoad.setTextColor(0xFF00FF00);
					textview12.setTextColor(0xFFFF0070);
					keywords.setTextColor(0xFF00FFFF);
					keywords.setHintTextColor(0xFF7000FF);
				}
				else {
					int color1 = (int) Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg.txt"), 16);
					int color2 = (int) Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttonbg2.txt"), 16);
					final int roundness = Integer.parseInt(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/roundness.txt"));
					int rcolor1 = (int) Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg.txt"), 16);
					int rcolor2 = (int) Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttonbg2.txt"), 16);
					button4.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
					hidehint.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
					cookieclr.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
					formclr.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
					e1.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
					e2.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
					
					tgc.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
					tgcc.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
					tgk.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
					tgkc.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
					privat.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
					videoad.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					
					panhint.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
					cachehint.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
					textview2.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt"),16));
					textview7.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt"),16));
					textview12.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt"),16));
					td1.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt"),16));
					bladtxt.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt"),16));
					textview3.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt"),16));
					textview6.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt"),16));
					textview9.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt"),16));
					textview11.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt"),16));
					startpage.setHintTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt"),16));
					keywords.setHintTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/hint.txt"),16));
					setaccess.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					
					startpage.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/textfield.txt"),16));
					srhalm.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/redbuttontext.txt"),16));
					std.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					pnup.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					screen.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					preview.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					developerinfo.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					zoombtns.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					slpercentash.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					onnointernet.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					customtheme.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					mono.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					textview8.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt"),16));
					about.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt"),16));
					keywords.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					srup.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					dts.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					hide.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					hintt.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					google.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					bing.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					yahoo.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					duck.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					auto.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					infogravity.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					ionl.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					conl.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					light.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					dark.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					name.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					uk.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					en.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					custom.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					loadcus.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
					loadstyle.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/additional.txt"),16));
					highcontrast.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					
					
					clrcache.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
					replacer.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
					useragent.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
					opentheme.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
					srccln.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
					bookmarks.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
					googl.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
					bng.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
					yaho.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
					duckgo.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
					history.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
					except.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/buttontext.txt"),16));
					navpan.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					loadingslash.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					percent.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					loadingpercent.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					slash.setTextColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/text.txt"),16));
					getWindow().getDecorView().setBackgroundColor((int)Long.parseLong(FileUtil.readFile("/storage/emulated/0/WeekBrowser/CustomTheme/bg.txt"),16));
					button4.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					hidehint.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					tgk.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					tgkc.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					tgc.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					tgcc.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					privat.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					cookieclr.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					formclr.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					e1.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					e2.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					panhint.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					cachehint.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					clrcache.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					bookmarks.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					googl.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					bng.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					yaho.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					duckgo.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					srccln.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					replacer.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					useragent.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					history.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					except.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					loadcus.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					opentheme.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					button4.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					clrcache.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					bookmarks.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					googl.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					bng.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					yaho.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					duckgo.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					srccln.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					replacer.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					useragent.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					history.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					except.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					loadcus.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					opentheme.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{color1, color2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
					srhalm.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL, new int[]{rcolor1, rcolor2}) {{
							    setCornerRadius(roundness * getResources().getDisplayMetrics().density);
						}});
				}
			}
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}